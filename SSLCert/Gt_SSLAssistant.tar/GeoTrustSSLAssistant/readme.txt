Geotrust SSL Certificate Assistant 4.0 for Red Hat Linux Servers

This readme describes how to use the Geotrust SSL Certificate Assistant to generate certificate signing requests (CSRs) and then how to install and configure SSL certificates.


- REQUIRED OPERATING SYSTEMS AND WEB SERVERS
- OTHER REQUIREMENTS
- NOTES
- GENERATE AND SUBMIT CSR
- GET THE SSL CERTIFICATE
- INSTALL THE SSL CERTIFICATE
	- AUTOMATIC SSL CERTIFICATE DOWNLOAD AND INSTALLATION
	- MANUAL SSL CERTIFICATE INSTALLATION
- TEST THE SSL CERTIFICATE INSTALLATION
- ADD GEOTRUST SECURED SEAL TO YOUR WEBSITE
- CSR GENERATION AND CERTIFICATE INSTALLATION WITHOUT USING THE ASSISTANT

REQUIRED OPERATING SYSTEMS AND WEB SERVERS

- CentOS 6.5 with Apache 2.2.29 or 2.4.12
- Red Hat Enterprise Linux 6.6 with Apache 2.2.29 or 2.4.12

OTHER REQUIREMENTS

- Root access on the server where you want to install the certificate
- An Apache restart after you install the certificate
- OpenSSL
- mod_ssl module
- cURL 7.46+ (Get the latest version at http://curl.haxx.se/download.html)

NOTES

- The generated private and public key pair uses an RSA 2048-bit or DSA 2048-256 bit key length.
- The Assistant needs to disable certain existing certificates to perform installation. These are re-enabled after installation is complete.

The SSL Assistant supports:
- RSA encryption algorithm, which is recommended for most cases.
- DSA encryption algorithm, which is a requirement for some U.S. government agencies.

- This script backs up the CSR and private key before making any changes to them. The script appends a time stamp (MonthDayYear24HourMinSec) to the file name. For example mycsr.txt becomes mycsr.12202011184932.txt.

GENERATE AND SUBMIT THE CSR

1. Move the sslassistant.sh, the eula.txt, and the readme.txt to the server where you will install the certificate.
2. Make sure that the Apache 2 executable is in the system PATH (usually /usr/sbin/httpd).
3. Log in as root and start the script.
   # ./sslassistant.sh
4. Follow the on-screen instructions.
5. The private key is put in the same directory as the CSR.
6. Sign in to your account in the GeoTrust Security Center:
   https://security-center.geotrust.com/process/retail/console_login?application_locale=GEOTRUST_US
7. Copy the CSR text into the appropriate field.

INSTALL YOUR SSL CERTIFICATE

After you submit your CSR, you can download and install your SSL certificate. SSL Assistant offers manual and automatic options for installing your certificate.

AUTOMATIC SSL CERTIFICATE DOWNLOAD AND INSTALLATION

Once your order has been processed, you can use SSL Assistant to automatically download and install your certificate.

To automatically download and install your SSL certificate with SSL Assistant
1. Move the sslassistant.sh, the eula.txt, and the apache_Thawte_readme.txt to the server where you will install the certificate.
2. Make sure that the Apache 2 executable is in the system PATH (usually /usr/sbin/httpd).
3. Log in as root and start the script.
   # ./sslassistant.sh
4. On the Install your certificate step, select Automatically download and install my certificate and click Continue.
5. On the Bind HTTPS step, select the site and port for binding HTTPS. Click Continue. SSL Assistant will install your certificate.
6. Restart Apache.
   # service httpd restart
   
MANUAL SSL CERTIFICATE INSTALLATION

After your order has been processed, you receive an email that contains the SSL certificate or the instructions to download the SSL certificate. Use this SSL certificate when the SSL Assistant requests it.

To use the attached SSL certificate in the email
1. Open the email that contains the SSL certificate as an attachment.
2. Use this attachment when the SSL Assistant asks for the SSL certificate.

To copy the SSL certificate from the body of the email
1. From the body of the email, copy the SSL certificate. Make sure to copy the BEGIN CERTIFICATE and END CERTIFICATE lines including all dashes.
2. Paste the copied SSL certificate into a text editor like Vi.
3. Save the file with a .crt extension to a location that you can remember.
4. Use this file when the SSL Assistant asks for the SSL certificate.

To check that you copied the SSL certificate correctly
1. Make sure that no white space, extra spaces, extra line breaks, or additional characters have been inadvertently added.
2. Make sure five dashes appear to either side of the BEGIN CERTIFICATE and END CERTIFICATE lines.

To manually install your SSL certificate with SSL Assistant
1. Move the sslassistant.sh, the eula.txt, and the apache_Thawte_readme.txt to the server where you will install the certificate.
2. Make sure that the Apache 2 executable is in the system PATH (usually /usr/sbin/httpd).
3. Log in as root and start the script.
   # ./sslassistant.sh
4. On the Install your certificate step, select Install a certificate I already downloaded. Browse to and select the certificate on your computer and click Continue.
5. On the Bind HTTPS step, select the site and port for binding HTTPS. Click Continue. SSL Assistant will install your certificate.
6. Restart Apache.
   # service httpd restart

TEST THE SSL CERTIFICATE INSTALLATION

1. Go to:
   https://ssltools.geotrust.com/checker/views/certCheck.jsp
2. On the SSL Certificate Checker page, paste the URL that you want to test into the field.
3. Click Validate.

ADD GEOTRUST SECURED SEAL TO YOUR WEBSITE

1. Go to:
   http://www.geotrust.com/support/true-businessid/true-site-seal/
2. Follow the on-screen instructions.

CSR GENERATION AND CERTIFICATE INSTALLATION WITHOUT USING THE ASSISTANT

- Visit our support site:
  https://knowledge.geotrust.com/support/knowledge-base/index.html
- For CSR generation instructions, see:
  https://knowledge.geotrust.com/support/knowledge-base/index?page=content&id=AR235
- For SSL certificate installation instructions, see:
  https://knowledge.geotrust.com/support/knowledge-base/index?page=content&id=AR212