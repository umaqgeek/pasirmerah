#!/bin/bash
# ex30a.sh: "Colorized version of ex30.sh

Escape="\033";

BlackF="${Escape}[30m"; RedF="${Escape}[31m"; GreenF="${Escape}[32m";
YellowF="${Escape}[33m"; BlueF="${Escape}[34m"; Purplef="${Escape}[35m";
CyanF="${Escape}[36m"; WhiteF="${Escape}[37m";

BlackB="${Escape}[40m"; RedB="${Escape}[41m"; GreenB="${Escape}[42m";
YellowB="${Escape}[43m"; BlueB="${Escape}[44m"; PurpleB="${Escape}[45m";
CyanB="${Escape}[46m"; WhiteB="${Escape}[47m";

BoldOn="${Escape}[1m"; BoldOff="${Escape}[22m";
ItalicsOn="${Escape}[3m"; ItalicsOff="${Escape}[23m";
UnderlineOn="${Escape}[4m"; UnderlineOff="${Escape}[24m";
BlinkOn="${Escape}[5m"; BlinkOff="${Escape}[25m";
InvertOn="${Escape}[7m"; InvertOff="${Escape}[27m";

Reset="${Escape}[0m";

backupDateTime="%m%d%Y%H%M%S"
timestamp=`date +"$backupDateTime"`

#Change terminal to display UTF-8
LANG=en_US.UTF-8

#=========================================HEADER END=======================================================
#=========================================BRAND START=====================================================
brand="GeoTrust"
#=========================================BRAND END=======================================================



#Create SSL directory if it does not exist
symantecDir="${HOME}/${brand}/ssl"
mkdir -p ${symantecDir} >/dev/null 2>&1
if [ "$?" = 1 ]
then
    echo "Unable to create the directory '$HOME/${brand}/ssl'"
	exit 1
fi

logFile=${symantecDir}/sslassistant_${timestamp}.log
log()
{
	time=`date +"%t %x %k:%M:%S%t"`
        logentry="INFO "$time$1
	echo -e $logentry >> $logFile
}

logError()
{

	time=`date +"%t %x %k:%M:%S%t"`
	logerror="ERROR"$time$1
	echo -e $logerror >>$logFile
}
# Check to see if openssl is available
checkOpenSSLInstalled()
{
	command -v openssl &>/dev/null || { echo "Cannot locate openssl." >&2; exit 1; }
	if [ "$(id -u)" != "0" ]; then
	   echo "Please run the SSL Assitant Tool as root" 1>&2
           exit 1
         fi
}

# Check to see if curl is available
checkCurlInstalled()
{
     command -v curl &>/dev/null || { echo "Cannot locate curl.To auto download and install certificate please install curl." >&2; exit 1; }
}

# Check apache version greater than 2.2
checkApacheVersionGreaterThan_2_2()
{
   version="2.2.0"

    IFS=$'.'
    arr1=($fullVersion)
    arr2=($version)
    unset IFS

    for ((i=0;i<${#arr1[@]};++i)); do

	   if (( ${arr1[i]} == ${arr2[i]} )); then
     		apacheVersionGreaterThan_2_2="equal"
     		continue
       elif (( ${arr1[i]} < ${arr2[i]} )); then
            apacheVersionGreaterThan_2_2="false"
            break
       elif (( ${arr1[i]} > ${arr2[i]} )); then
            apacheVersionGreaterThan_2_2="true"
            break
           fi
    done
}



# Check apache version smaller than 2.4.8
checkApacheVersionGreaterThan_2_4_8()
{
    version="2.4.8"

    IFS=$'.'
    arr1=($fullVersion)
    arr2=($version)
    unset IFS

    for ((i=0;i<${#arr1[@]};++i)); do

          if (( ${arr1[i]} == ${arr2[i]} )); then
             apacheVersionGreaterThan_2_4_8="equal"
             continue
          elif (( ${arr1[i]} < ${arr2[i]} )); then
             apacheVersionGreaterThan_2_4_8="false"
             break
          elif (( ${arr1[i]} > ${arr2[i]} )); then
             apacheVersionGreaterThan_2_4_8="true"
             break
          fi
     done
}

jsonValue()
{
  KEY=$1
  num=$2
  awk -F"[,:}]" '{for(i=1;i<=NF;i++){if($i~/'$KEY'\042/){print $(i+1)}}}' | tr -d '"' | sed -n ${num}p
}



requiredPrompt()
{
	echo -e -n "$1"
	read result;
        log "Value entered for $1 $result"

	while [ -z "$result" ]; do
		echo "The value entered is invalid. Re-enter the information."
		logError "Invalid value entered for $1 $result"
                echo -e -n "$1"
		read result;
		log "Value entered for $1 $result"
    done
}

requiredFilePrompt()
{
	read -e -p "$1" result
        log "Filename entered for $1 $result"

	while [ -z "$result" ]; do
		echo "The value entered is invalid. Re-enter the information."
		logError "Invalid filename entered for $1 $result"
                read -e -p "$1" result
		log "Filename entered for $1 $result"
	done
}

requiredTwoCharPrompt()
{
	echo -e -n "$1"
	read result;
        log "Value entered for $1 $result"

	while [ "${#result}" -ne "2" ]; do
		echo "The value entered is invalid. Re-enter the information."
		logError "Invalid value entered for $1 $result"
                echo -e -n "$1"
		read result;
		log "Value entered for $1 $result"
    done
}

requiredSecretPrompt()
{
	echo -e -n "$1"
	read -s result;
	log "Value entered for Password '******'"
	echo

	while [ -z "$result" ]; do
		echo "The value entered is invalid. Re-enter the information."
		logError "Invalid value entered for Password"
                echo -e -n "$1"
		read -s result;
		echo
		log "Value entered for Password '******'"
    done
}

#Check that HTTPD version 2 is installed and mod_ssl.so is available.
checkHttpd()
{
	log  "Checking to see if httpd is available..."
        # Check to see if httpd is available
	command -v httpd &>/dev/null || { echo "Cannot locate Apache 2.0 in system path." >&2; log "Cannot locate Apache in system path."; exit 1; }

	apache=`httpd -v | grep Apache/`
	fullVersion=${apache#*/}
	fullVersion=${fullVersion% *}
	version=${fullVersion%%.*}
	
	log "Checking if httpd -v command returns valid version..."
	if [ -z "$version" ]
	then
	       echo ""httpd -v" command did not return a valid version.Please ensure you have Apache version 2.0 and above installed"
		
	else
		log  "Checking to see if httpd is version 2..."
        	if [ $version != "2" ]
		then
			echo "Apache 2.0 not found. "'('"Found version $fullVersion"')'""
			logError "Apache 2.0 not found. Found version $fullVersion"
			exit 1
		fi
	fi

	log  "Checking to see if mod_ssl is available..."
        if [ ! -e "/etc/httpd/modules/mod_ssl.so" ]
	then
		echo "Unable to find /etc/httpd/modules/mod_ssl.so. Make sure that the mod_ssl"
		echo "module is installed on this server."
		logError "Unable to find /etc/httpd/modules/mod_ssl.so. Make sure that the mod_ssl module is installed on this server."
		log "module is installed on this server."
		exit 1;
	fi
}

showEula()
{
	echo -e -n "${BoldOn}Do you accept the End User Software Licence Agreement in the eula.txt file? (y/n):${BoldOff} "
	log "Presenting End User Software Licence Agreement..."
        while [ "$accept" != "y" ]; do
		read -s -n1 accept
                log "End User Software Licence Agreement accepted."
		if [ "$accept" = "n" ]
		then
			echo n
			log "End User Software Licence Agreement declined."
			exit 0
		fi
	done
	echo y
}
getCipher(){
echo
        echo "The RSA encryption algorithm is typical for most cases, while the DSA encryption algorithm"
        echo " is a requirement for some U.S. government agencies. Only use DSA if you are sure that you need it."
        echo -e -n "${BoldOn}Please specify the cipher algorithm. ${BoldOff}\n"
	if [[ "$brand" == "Symantec" ]]
	then
		echo -e -n "${BoldOn}Choose between ${CyanF} RSA ${Reset} ${BoldOn}or ${CyanF} DSA ${Reset} ${BoldOn}or ${CyanF} ECC ${Reset}:"
	else
		echo -e -n "${BoldOn}Choose between ${CyanF} RSA ${Reset} ${BoldOn}or ${CyanF} DSA ${Reset}"
	fi

	read algo
	algo=$(echo $algo | tr '[:lower:]' '[:upper:]')
        
		if [ -z "${algo##[R][S][A]}" ]
                 then
                      cipher="RSA"
                      
                elif [ -z "${algo##[D][S][A]}" ]
                then
                      cipher="DSA"
                elif [ -z "${algo##[E][C][C]}" ] && [[ "$brand" == "Symantec" ]]
	        then
		    cipher="ECC"
  
		else
                   cipher="RSA"
                    echo
                    echo -e -n "\tInvalid selection. Defaulting to RSA"
                    echo
	fi
}
checkAlgorithmEntered(){

	count=$((count+1))
	if  echo "${AlgoOptions[@]}" | fgrep --word-regexp "$UserInput">/dev/null 2>&1; 
	then
          
	     cipher="$UserInput"
	     result=1
	    
	elif [ $count -lt 2 ]
	then
	     echo "Type the name of your preferred encryption algorithm from following value/s: "
	     for (( i=${cipherOptions}-1; i>=0; i-- ));
	     do
	              echo -e -n "${BoldOn}.${AlgoOptions[i]}${BoldOff}\n"
	     done
	     echo -n "Enter the encryption algorithm:"
    	     read UserInput
	     UserInput=$(echo $UserInput | tr '[:lower:]' '[:upper:]')
	else
   	    cipher=$defaultalgo
	    
     fi
} 

setCipher(){
	declare -i count=0
	declare -i result=0
	declare -i cipherOptions=0
	
	cipher=$(echo ${cipher} | tr '[:lower:]' '[:upper:]')
	IFS="," read -ra AlgoOptions<<<"$cipher"               
	defaultalgo="${AlgoOptions[0]}"
	cipherOptions=${#AlgoOptions[@]}

	if [ $cipherOptions -eq 1 ]
	then
	  checkAlgorithmEntered

	   if [ $result -eq 1 ]
	   then
		log "setting cipher value to $cipher" 
	   else
         	checkAlgorithmEntered
	   fi
 	else
	echo "Type the name of your preferred encryption algorithm from following value/s: "

	for (( i=${cipherOptions}-1; i>=0; i-- ));
	  do
			    
		echo -e -n "${BoldOn}.${AlgoOptions[i]}${BoldOff}\n"
	  done
		echo -n "Enter the encryption algorithm:"		
		read UserInput
		UserInput=$(echo $UserInput | tr '[:lower:]' '[:upper:]')
		checkAlgorithmEntered

		if [ $result -eq 1 ]
		then
			log "setting cipher value to $cipher" 
		else
        	 	checkAlgorithmEntered
		fi
	fi
}



#=========================================SUBJECT START=====================================================

getSubject1()
{
        echo
        echo "Enter the fully-qualified domain name for the Web server where"
	echo "you plan to request the certificate. Examples are"
	echo "\"server.example.com\" and \"www.example.com\""
	echo
	requiredPrompt "${BoldOn}Your web server's FQDN is:${BoldOff} "
	if [[ "$result" =~ "'" || "$result" =~ "\"" ]]
        then
            echo "Quotes are not allowed in Domain Name"
            exit 1
        fi

        commonName=$result
	echo

	requiredTwoCharPrompt "${BoldOn}Enter the two letter country code:${BoldOff} "
	country=$result
        echo

	echo "For the US and Canada, enter the state or province name."
	echo "Do not abbreviate it. For example, do not use OH, instead use Ohio."
	echo "All other customers enter N/A."
	echo
	requiredPrompt "${BoldOn}State or Province:${BoldOff} "
	state=$result
	echo

	requiredPrompt "${BoldOn}Enter the name of the server's locality or city:${BoldOff} "
	city=$result
	echo

	echo "Enter the full legal name of the organization as it appears on your"
	echo "account. This field is case sensitive."
	echo
	requiredPrompt "${BoldOn}Organization:${BoldOff} "
	org=$result
	echo

	echo "You can optionally use an organization unit to help specify"
	echo "certificates. For example, you could use ENG for engineering."
	echo
	echo -e -n "${BoldOn}Enter the Organization Unit. Press Enter to skip this field:${BoldOff} "
	read orgunit
	echo

	if [ -z "$orgunit" ]
	then
		subject="/C=$country/ST=$state/L=$city/O=$org/CN=$commonName"
	else
		subject="/C=$country/ST=$state/L=$city/O=$org/OU=$orgunit/CN=$commonName"
	fi
}

#=========================================SUBJECT END=======================================================


#=========================================CERTIFICATE START==================================================
getCipherFromCert()
{
   cipher=$(openssl x509 -in ${cert} -text | grep -Po '^.*?(?<=Public\ Key\ Algorithm:\ ).*?(?=Encryption)'| cut -d ':' -f2)
   if [ -z $cipher ]
   then
	result=$(openssl x509 -in ${cert} -text | grep -Po '^.*?(?<=Public\ Key\ Algorithm:\ ).*?(?=PublicKey)'| cut -d ':' -f2)
	if [[ "$result" -eq "id-ec" ]]
	then
	    cipher="ecc"                       
	fi
    fi
}
getCert()
{
 requiredFilePrompt "Enter the path and filename of the certificate file that will be installed: "
 cert=$result
 if [ ! -f $cert ]
 then
     echo "The certificate is not found."
     log "The certificate is not found."
     exit 1
 fi
 getCipherFromCert
}

getCertWithAutoDownload()
{
    getUserNamePasswordOrderNumber

    curlRequest="curl --request POST --header \"Content-type:  application/JSON\" --data '{\"pin\": \"${orderNumber}\", \"userName\": \"${userName}\", \"password\":\"${password}\",\"format\": \"x509\"}' https://trustcenter-enterprise.websecurity.symantec.com/service/api/certificatePickup"

    curlResponse=$(eval $curlRequest)

    statusCode=$(echo $curlResponse | jsonValue statusCode 1)
    orderStatus=$(echo $curlResponse | jsonValue orderStatus 1)
    
 
    if [ $statusCode ==  0 ]
       then
         if [[ "$orderStatus" == "Valid" ]]
              then
                certFromResponse=$(echo $curlResponse | jsonValue certificate 1)
                sed -e 's/\\n/\\\n/g' <<< $certFromResponse | sed -e 's/\\//g' > ./$orderNumber.cer
            else
                echo "SSL Assistant could not download your certificate. "
                echo "This can occur if your order is pending approval or has been rejected, or if the certificate has been revoked."
                echo "Please try again when your order has been approved and your certificate is ready to download."
                exit 1;
            fi
      else
           echo "SSL Assistant could not download your certificate."
           echo "Check your internet connection and make sure your username, password, and order number are correct and then try again."
           exit 1;

     fi


     cert="./$orderNumber.cer"
     log "Generating  the certificate file in current directory from the json response"
     if [ ! -f $cert ]
        then
         echo "The certificate is not found."
         log "The certificate is not found."
         exit 1
     fi
     getCipherFromCert
}

getUserNamePasswordOrderNumber()
{
    echo
    echo "Enter your ${brand} Certificate Center username, password, and order number and click Continue."
    echo "SSL Assistant will download and install your certificate."

	requiredPrompt "${BoldOn}Enter Order Number:${BoldOff} "
	orderNumber=$result
	echo

    requiredPrompt "${BoldOn}Enter Username:${BoldOff} "
	userName=$result
	echo

	requiredSecretPrompt "${BoldOn}Enter Password:${BoldOff} "
	password=$result
	echo
}



getIntermediateCerts()
{


		#Secure Site, Wildcard SSL, Financial SSL for OFX and Wirelsss LAN Server
		issuer1="VeriSign Class 3 Secure Server CA - G3"
		issuer1Chain="-----BEGIN CERTIFICATE-----
MIIF7DCCBNSgAwIBAgIQbsx6pacDIAm4zrz06VLUkTANBgkqhkiG9w0BAQUFADCB
yjELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDlZlcmlTaWduLCBJbmMuMR8wHQYDVQQL
ExZWZXJpU2lnbiBUcnVzdCBOZXR3b3JrMTowOAYDVQQLEzEoYykgMjAwNiBWZXJp
U2lnbiwgSW5jLiAtIEZvciBhdXRob3JpemVkIHVzZSBvbmx5MUUwQwYDVQQDEzxW
ZXJpU2lnbiBDbGFzcyAzIFB1YmxpYyBQcmltYXJ5IENlcnRpZmljYXRpb24gQXV0
aG9yaXR5IC0gRzUwHhcNMTAwMjA4MDAwMDAwWhcNMjAwMjA3MjM1OTU5WjCBtTEL
MAkGA1UEBhMCVVMxFzAVBgNVBAoTDlZlcmlTaWduLCBJbmMuMR8wHQYDVQQLExZW
ZXJpU2lnbiBUcnVzdCBOZXR3b3JrMTswOQYDVQQLEzJUZXJtcyBvZiB1c2UgYXQg
aHR0cHM6Ly93d3cudmVyaXNpZ24uY29tL3JwYSAoYykxMDEvMC0GA1UEAxMmVmVy
aVNpZ24gQ2xhc3MgMyBTZWN1cmUgU2VydmVyIENBIC0gRzMwggEiMA0GCSqGSIb3
DQEBAQUAA4IBDwAwggEKAoIBAQCxh4QfwgxF9byrJZenraI+nLr2wTm4i8rCrFbG
5btljkRPTc5v7QlK1K9OEJxoiy6Ve4mbE8riNDTB81vzSXtig0iBdNGIeGwCU/m8
f0MmV1gzgzszChew0E6RJK2GfWQS3HRKNKEdCuqWHQsV/KNLO85jiND4LQyUhhDK
tpo9yus3nABINYYpUHjoRWPNGUFP9ZXse5jUxHGzUL4os4+guVOc9cosI6n9FAbo
GLSa6Dxugf3kzTU2s1HTaewSulZub5tXxYsU5w7HnO1KVGrJTcW/EbGuHGeBy0RV
M5l/JJs/U0V/hhrzPPptf4H1uErT9YU3HLWm0AnkGHs4TvoPAgMBAAGjggHfMIIB
2zA0BggrBgEFBQcBAQQoMCYwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLnZlcmlz
aWduLmNvbTASBgNVHRMBAf8ECDAGAQH/AgEAMHAGA1UdIARpMGcwZQYLYIZIAYb4
RQEHFwMwVjAoBggrBgEFBQcCARYcaHR0cHM6Ly93d3cudmVyaXNpZ24uY29tL2Nw
czAqBggrBgEFBQcCAjAeGhxodHRwczovL3d3dy52ZXJpc2lnbi5jb20vcnBhMDQG
A1UdHwQtMCswKaAnoCWGI2h0dHA6Ly9jcmwudmVyaXNpZ24uY29tL3BjYTMtZzUu
Y3JsMA4GA1UdDwEB/wQEAwIBBjBtBggrBgEFBQcBDARhMF+hXaBbMFkwVzBVFglp
bWFnZS9naWYwITAfMAcGBSsOAwIaBBSP5dMahqyNjmvDz4Bq1EgYLHsZLjAlFiNo
dHRwOi8vbG9nby52ZXJpc2lnbi5jb20vdnNsb2dvLmdpZjAoBgNVHREEITAfpB0w
GzEZMBcGA1UEAxMQVmVyaVNpZ25NUEtJLTItNjAdBgNVHQ4EFgQUDURcFlNEwYJ+
HSCrJfQBY9i+eaUwHwYDVR0jBBgwFoAUf9Nlp8Ld7LvwMAnzQzn6Aq8zMTMwDQYJ
KoZIhvcNAQEFBQADggEBAAyDJO/dwwzZWJz+NrbrioBL0aP3nfPMU++CnqOh5pfB
WJ11bOAdG0z60cEtBcDqbrIicFXZIDNAMwfCZYP6j0M3m+oOmmxw7vacgDvZN/R6
bezQGH1JSsqZxxkoor7YdyT3hSaGbYcFQEFn0Sc67dxIHSLNCwuLvPSxe/20majp
dirhGi2HbnTTiN0eIsbfFrYrghQKlFzyUOyvzv9iNw2tZdMGQVPtAhTItVgooazg
W+yzf5VK+wPIrSbb5mZ4EkrZn0L74ZjmQoObj49nJOhhGbXdzbULJgWOw27EyHW4
Rs/iGAZeqa6ogZpHFt4MKGwlJ7net4RYxh84HqTEy2Y=
-----END CERTIFICATE-----"

		#Secure Site Pro and Premium SSL
		issuer2="VeriSign Class 3 International Server CA - G3"
		issuer2Chain="-----BEGIN CERTIFICATE-----
MIIGKTCCBRGgAwIBAgIQZBvoIM4CCBPzLU0tldZ+ZzANBgkqhkiG9w0BAQUFADCB
yjELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDlZlcmlTaWduLCBJbmMuMR8wHQYDVQQL
ExZWZXJpU2lnbiBUcnVzdCBOZXR3b3JrMTowOAYDVQQLEzEoYykgMjAwNiBWZXJp
U2lnbiwgSW5jLiAtIEZvciBhdXRob3JpemVkIHVzZSBvbmx5MUUwQwYDVQQDEzxW
ZXJpU2lnbiBDbGFzcyAzIFB1YmxpYyBQcmltYXJ5IENlcnRpZmljYXRpb24gQXV0
aG9yaXR5IC0gRzUwHhcNMTAwMjA4MDAwMDAwWhcNMjAwMjA3MjM1OTU5WjCBvDEL
MAkGA1UEBhMCVVMxFzAVBgNVBAoTDlZlcmlTaWduLCBJbmMuMR8wHQYDVQQLExZW
ZXJpU2lnbiBUcnVzdCBOZXR3b3JrMTswOQYDVQQLEzJUZXJtcyBvZiB1c2UgYXQg
aHR0cHM6Ly93d3cudmVyaXNpZ24uY29tL3JwYSAoYykxMDE2MDQGA1UEAxMtVmVy
aVNpZ24gQ2xhc3MgMyBJbnRlcm5hdGlvbmFsIFNlcnZlciBDQSAtIEczMIIBIjAN
BgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAmdacYvAV9IGaQQhZjxOdF8mfUdza
sVLv/+NB3eDfxCjG4615HycQmLi7IJfBKERBD+qpqFLPTU4bi7u1xHbZzFYG7rNV
ICreFY1xy1TIbxfNiQDk3P/hwB9ocenHKS5+vDv85burJlSLZpDN9pK5MSSAvJ5s
1fx+0uFLjNxC+kRLX/gYtS4w9D0SmNNiBXNUppyiHb5SgzoHRsQ7AlYhv/JRT9Cm
mTnprqU/iZucff5NYAclIPe712mDK4KTQzfZg0EbawurSmaET0qO3n40mY5o1so5
BptMs5pITRNGtFghBMT7oE2sLktiEuP7TfbJUQABH/weaoEqOOC5T9YtRQIDAQAB
o4ICFTCCAhEwEgYDVR0TAQH/BAgwBgEB/wIBADBwBgNVHSAEaTBnMGUGC2CGSAGG
+EUBBxcDMFYwKAYIKwYBBQUHAgEWHGh0dHBzOi8vd3d3LnZlcmlzaWduLmNvbS9j
cHMwKgYIKwYBBQUHAgIwHhocaHR0cHM6Ly93d3cudmVyaXNpZ24uY29tL3JwYTAO
BgNVHQ8BAf8EBAMCAQYwbQYIKwYBBQUHAQwEYTBfoV2gWzBZMFcwVRYJaW1hZ2Uv
Z2lmMCEwHzAHBgUrDgMCGgQUj+XTGoasjY5rw8+AatRIGCx7GS4wJRYjaHR0cDov
L2xvZ28udmVyaXNpZ24uY29tL3ZzbG9nby5naWYwNAYDVR0lBC0wKwYIKwYBBQUH
AwEGCCsGAQUFBwMCBglghkgBhvhCBAEGCmCGSAGG+EUBCAEwNAYIKwYBBQUHAQEE
KDAmMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC52ZXJpc2lnbi5jb20wNAYDVR0f
BC0wKzApoCegJYYjaHR0cDovL2NybC52ZXJpc2lnbi5jb20vcGNhMy1nNS5jcmww
KAYDVR0RBCEwH6QdMBsxGTAXBgNVBAMTEFZlcmlTaWduTVBLSS0yLTcwHQYDVR0O
BBYEFNebfNgioBX33a1fzimbWMO8RgC1MB8GA1UdIwQYMBaAFH/TZafC3ey78DAJ
80M5+gKvMzEzMA0GCSqGSIb3DQEBBQUAA4IBAQBxtX1zUkrd1000Ky6vlEalSVAC
T/gvF3DyE9wfIYaqwk98NzzURniuXXhv0bpavBCrWDbFjGIVRWAXIeLVQqh3oVXY
QwRR9m66SOZdTLdE0z6k1dYzmp8N5tdOlkSVWmzWoxZTDphDzqS4w2Z6BVxiEOgb
Ett9LnZQ/9/XaxvMisxx+rNAVnwzeneUW/ULU/sOX7xo+68q7jA3eRaTJX9NEP9X
+79uOzMh3nnchhdZLUNkt6Zmh+q8lkYZGoaLb9e3SQBb26O/KZru99MzrqP0nkzK
XmnUG623kHdq2FlveasB+lXwiiFm5WVu/XzT3x7rfj8GkPsZC9MGAht4Q5mo
-----END CERTIFICATE-----"

		#Secure Site with EV
		issuer3="VeriSign Class 3 Extended Validation SSL CA"
		issuer3Chain="-----BEGIN CERTIFICATE-----
MIIF5DCCBMygAwIBAgIQW3dZxheE4V7HJ8AylSkoazANBgkqhkiG9w0BAQUFADCB
yjELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDlZlcmlTaWduLCBJbmMuMR8wHQYDVQQL
ExZWZXJpU2lnbiBUcnVzdCBOZXR3b3JrMTowOAYDVQQLEzEoYykgMjAwNiBWZXJp
U2lnbiwgSW5jLiAtIEZvciBhdXRob3JpemVkIHVzZSBvbmx5MUUwQwYDVQQDEzxW
ZXJpU2lnbiBDbGFzcyAzIFB1YmxpYyBQcmltYXJ5IENlcnRpZmljYXRpb24gQXV0
aG9yaXR5IC0gRzUwHhcNMDYxMTA4MDAwMDAwWhcNMTYxMTA3MjM1OTU5WjCBujEL
MAkGA1UEBhMCVVMxFzAVBgNVBAoTDlZlcmlTaWduLCBJbmMuMR8wHQYDVQQLExZW
ZXJpU2lnbiBUcnVzdCBOZXR3b3JrMTswOQYDVQQLEzJUZXJtcyBvZiB1c2UgYXQg
aHR0cHM6Ly93d3cudmVyaXNpZ24uY29tL3JwYSAoYykwNjE0MDIGA1UEAxMrVmVy
aVNpZ24gQ2xhc3MgMyBFeHRlbmRlZCBWYWxpZGF0aW9uIFNTTCBDQTCCASIwDQYJ
KoZIhvcNAQEBBQADggEPADCCAQoCggEBAJjboFXrnP0XeeOabhQdsVuYI4cWbod2
nLU4O7WgerQHYwkZ5iqISKnnnbYwWgiXDOyq5BZpcmIjmvt6VCiYxQwtt9citsj5
OBfH3doxRpqUFI6e7nigtyLUSVSXTeV0W5K87Gws3+fBthsaVWtmCAN/Ra+aM/EQ
wGyZSpIkMQht3QI+YXZ4eLbtfjeubPOJ4bfh3BXMt1afgKCxBX9ONxX/ty8ejwY4
P1C3aSijtWZfNhpSSENmUt+ikk/TGGC+4+peGXEFv54cbGhyJW+ze3PJbb0S/5tB
Ml706H7FC6NMZNFOvCYIZfsZl1h44TO/7Wg+sSdFb8Di7Jdp91zT91ECAwEAAaOC
AdIwggHOMB0GA1UdDgQWBBT8ilC6nrklWntVhU+VAGOP6VhrQzASBgNVHRMBAf8E
CDAGAQH/AgEAMD0GA1UdIAQ2MDQwMgYEVR0gADAqMCgGCCsGAQUFBwIBFhxodHRw
czovL3d3dy52ZXJpc2lnbi5jb20vY3BzMD0GA1UdHwQ2MDQwMqAwoC6GLGh0dHA6
Ly9FVlNlY3VyZS1jcmwudmVyaXNpZ24uY29tL3BjYTMtZzUuY3JsMA4GA1UdDwEB
/wQEAwIBBjARBglghkgBhvhCAQEEBAMCAQYwbQYIKwYBBQUHAQwEYTBfoV2gWzBZ
MFcwVRYJaW1hZ2UvZ2lmMCEwHzAHBgUrDgMCGgQUj+XTGoasjY5rw8+AatRIGCx7
GS4wJRYjaHR0cDovL2xvZ28udmVyaXNpZ24uY29tL3ZzbG9nby5naWYwKQYDVR0R
BCIwIKQeMBwxGjAYBgNVBAMTEUNsYXNzM0NBMjA0OC0xLTQ3MD0GCCsGAQUFBwEB
BDEwLzAtBggrBgEFBQcwAYYhaHR0cDovL0VWU2VjdXJlLW9jc3AudmVyaXNpZ24u
Y29tMB8GA1UdIwQYMBaAFH/TZafC3ey78DAJ80M5+gKvMzEzMA0GCSqGSIb3DQEB
BQUAA4IBAQCWovp/5j3t1CvOtxU/wHIDX4u6FpAl98KD2Md1NGNoElMMU4l7yVYJ
p8M2RE4O0GJis4b66KGbNGeNUyIXPv2s7mcuQ+JdfzOE8qJwwG6Cl8A0/SXGI3/t
5rDFV0OEst4t8dD2SB8UcVeyrDHhlyQjyRNddOVG7wl8nuGZMQoIeRuPcZ8XZsg4
z+6Ml7YGuXNG5NOUweVgtSV1LdlpMezNlsOjdv3odESsErlNv1HoudRETifLriDR
fip8tmNHnna6l9AW5wtsbfdDbzMLKTB3+p359U64drPNGLT5IO892+bKrZvQTtKH
qQ2mRHNQ3XBb7a1+Srwi1agm5MKFIA3Z
-----END CERTIFICATE-----"

		issuer4="VeriSign Class 3 Extended Validation SSL SGC CA"
		issuer4Chain="-----BEGIN CERTIFICATE-----
MIIGHjCCBQagAwIBAgIQLEjdkw31WY75PJlUemDtQzANBgkqhkiG9w0BAQUFADCB
yjELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDlZlcmlTaWduLCBJbmMuMR8wHQYDVQQL
ExZWZXJpU2lnbiBUcnVzdCBOZXR3b3JrMTowOAYDVQQLEzEoYykgMjAwNiBWZXJp
U2lnbiwgSW5jLiAtIEZvciBhdXRob3JpemVkIHVzZSBvbmx5MUUwQwYDVQQDEzxW
ZXJpU2lnbiBDbGFzcyAzIFB1YmxpYyBQcmltYXJ5IENlcnRpZmljYXRpb24gQXV0
aG9yaXR5IC0gRzUwHhcNMDYxMTA4MDAwMDAwWhcNMTYxMTA3MjM1OTU5WjCBvjEL
MAkGA1UEBhMCVVMxFzAVBgNVBAoTDlZlcmlTaWduLCBJbmMuMR8wHQYDVQQLExZW
ZXJpU2lnbiBUcnVzdCBOZXR3b3JrMTswOQYDVQQLEzJUZXJtcyBvZiB1c2UgYXQg
aHR0cHM6Ly93d3cudmVyaXNpZ24uY29tL3JwYSAoYykwNjE4MDYGA1UEAxMvVmVy
aVNpZ24gQ2xhc3MgMyBFeHRlbmRlZCBWYWxpZGF0aW9uIFNTTCBTR0MgQ0EwggEi
MA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQC9Voi6iDRkZM/NyrDu5xlzxXLZ
u0W8taj/g74cA9vtibcuEBolvFXKQaGfC88ZXnC5XjlLnjEcX4euKqqoK6IbOxAj
XxOx3QiMThTag4HjtYzjaO0kZ85Wtqybc5ZE24qMs9bwcZOO23FUSutzWWqPcFEs
A5+X0cwRerxiDZUqyRx1V+n1x+q6hDXLx4VafuRN4RGXfQ4gNEXb8aIJ6+s9nriW
Q140SwglHkMaotm3igE0PcP45a9PjP/NZfAjTsWXs1zakByChQ0GDcEitnsopAPD
TFPRWLxyvAg5/KB2qKjpS26IPeOzMSWMcylIDjJ5Bu09Q/T25On8fb6OCNUfAgMB
AAGjggIIMIICBDAdBgNVHQ4EFgQUTkPIHXbvN1N6T/JYb5TzOOLVvd8wEgYDVR0T
AQH/BAgwBgEB/wIBADA9BgNVHSAENjA0MDIGBFUdIAAwKjAoBggrBgEFBQcCARYc
aHR0cHM6Ly93d3cudmVyaXNpZ24uY29tL2NwczA9BgNVHR8ENjA0MDKgMKAuhixo
dHRwOi8vRVZTZWN1cmUtY3JsLnZlcmlzaWduLmNvbS9wY2EzLWc1LmNybDAOBgNV
HQ8BAf8EBAMCAQYwEQYJYIZIAYb4QgEBBAQDAgEGMG0GCCsGAQUFBwEMBGEwX6Fd
oFswWTBXMFUWCWltYWdlL2dpZjAhMB8wBwYFKw4DAhoEFI/l0xqGrI2Oa8PPgGrU
SBgsexkuMCUWI2h0dHA6Ly9sb2dvLnZlcmlzaWduLmNvbS92c2xvZ28uZ2lmMCkG
A1UdEQQiMCCkHjAcMRowGAYDVQQDExFDbGFzczNDQTIwNDgtMS00ODAfBgNVHSME
GDAWgBR/02Wnwt3su/AwCfNDOfoCrzMxMzA9BggrBgEFBQcBAQQxMC8wLQYIKwYB
BQUHMAGGIWh0dHA6Ly9FVlNlY3VyZS1vY3NwLnZlcmlzaWduLmNvbTA0BgNVHSUE
LTArBglghkgBhvhCBAEGCmCGSAGG+EUBCAEGCCsGAQUFBwMBBggrBgEFBQcDAjAN
BgkqhkiG9w0BAQUFAAOCAQEAJ3SmNOodneFT1hydDKdbTKln8vAytwEP+0IYON7k
7knIE8kL7ATDQHEYcnZDAiNdq3vISBQayHsd/PYKnzah0glzcWaWdVE0v5kwUWed
VLcmRaxzCCOGJplx9I7X6jmbBgkjv2LdqMS2faSJBz7zba5AWVB5lzc9Mnh9smNL
+eoIaQ4T7ejPu6wFhsoiz4hiXTwiSdhj1SSmve9c48wgOyLq/ETGqOUf4YbNDE2P
k1PZf+6hCKezMJZJcG6jbD3QY+8lZmPMqrcYF07qcHb2ukKmgDcJTp9miC5rM2bI
wHGkQeta4/wULkuI/a5uW2XpJ+S/5LAjwbJ9W2Il1z4Q1A==
-----END CERTIFICATE-----"

		issuer5="GeoTrust SSL CA"
		issuer5Chain="-----BEGIN CERTIFICATE-----
MIID2TCCAsGgAwIBAgIDAjbQMA0GCSqGSIb3DQEBBQUAMEIxCzAJBgNVBAYTAlVT
MRYwFAYDVQQKEw1HZW9UcnVzdCBJbmMuMRswGQYDVQQDExJHZW9UcnVzdCBHbG9i
YWwgQ0EwHhcNMTAwMjE5MjIzOTI2WhcNMjAwMjE4MjIzOTI2WjBAMQswCQYDVQQG
EwJVUzEXMBUGA1UEChMOR2VvVHJ1c3QsIEluYy4xGDAWBgNVBAMTD0dlb1RydXN0
IFNTTCBDQTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAJCzgMHk5Uat
cGA9uuUU3Z6KXot1WubKbUGlI+g5hSZ6p1V3mkihkn46HhrxJ6ujTDnMyz1Hr4Gu
FmpcN+9FQf37mpc8oEOdxt8XIdGKolbCA0mEEoE+yQpUYGa5jFTk+eb5lPHgX3UR
8im55IaisYmtph6DKWOy8FQchQt65+EuDa+kvc3nsVrXjAVaDktzKIt1XTTYdwvh
dGLicTBi2LyKBeUxY0pUiWozeKdOVSQdl+8a5BLGDzAYtDRN4dgjOyFbLTAZJQ50
96QhS6CkIMlszZhWwPKoXz4mdaAN+DaIiixafWcwqQ/RmXAueOFRJq9VeiS+jDkN
d53eAsMMvR8CAwEAAaOB2TCB1jAOBgNVHQ8BAf8EBAMCAQYwHQYDVR0OBBYEFEJ5
VBthzVUrPmPVPEhX9Z/7Rc5KMB8GA1UdIwQYMBaAFMB6mGiNifurBWQMEX2qfWW4
ysxOMBIGA1UdEwEB/wQIMAYBAf8CAQAwOgYDVR0fBDMwMTAvoC2gK4YpaHR0cDov
L2NybC5nZW90cnVzdC5jb20vY3Jscy9ndGdsb2JhbC5jcmwwNAYIKwYBBQUHAQEE
KDAmMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5nZW90cnVzdC5jb20wDQYJKoZI
hvcNAQEFBQADggEBANTvU4ToGr2hiwTAqfVfoRB4RV2yV2pOJMtlTjGXkZrUJPji
J2ZwMZzBYlQG55cdOprApClICq8kx6jEmlTBfEx4TCtoLF0XplR4TEbigMMfOHES
0tdT41SFULgCy+5jOvhWiU1Vuy7AyBh3hjELC3DwfjWDpCoTZFZnNF0WX3OsewYk
2k9QbSqr0E1TQcKOu3EDSSmGGM8hQkx0YlEVxW+o78Qn5Rsz3VqI138S0adhJR/V
4NwdzxoQ2KDLX4z6DOW/cf/lXUQdpj6HR/oaToODEj+IZpWYeZqF6wJHzSXj8gYE
TpnKXKBuervdo5AaRTPvvz7SBMS24CqFZUE+ENQ=
-----END CERTIFICATE-----"

		issuer6="GeoTrust DV SSL CA"
		issuer6Chain="-----BEGIN CERTIFICATE-----
MIID+jCCAuKgAwIBAgIDAjbSMA0GCSqGSIb3DQEBBQUAMEIxCzAJBgNVBAYTAlVT
MRYwFAYDVQQKEw1HZW9UcnVzdCBJbmMuMRswGQYDVQQDExJHZW9UcnVzdCBHbG9i
YWwgQ0EwHhcNMTAwMjI2MjEzMjMxWhcNMjAwMjI1MjEzMjMxWjBhMQswCQYDVQQG
EwJVUzEWMBQGA1UEChMNR2VvVHJ1c3QgSW5jLjEdMBsGA1UECxMURG9tYWluIFZh
bGlkYXRlZCBTU0wxGzAZBgNVBAMTEkdlb1RydXN0IERWIFNTTCBDQTCCASIwDQYJ
KoZIhvcNAQEBBQADggEPADCCAQoCggEBAKa7jnrNpJxiV9RRMEJ7ixqy0ogGrTs8
KRMMMbxp+Z9alNoGuqwkBJ7O1KrESGAA+DSuoZOv3gR+zfhcIlINVlPrqZTP+3RE
60OUpJd6QFc1tqRi2tVI+Hrx7JC1Xzn+Y3JwyBKF0KUuhhNAbOtsTdJU/V8+Jh9m
cajAuIWe9fV1j9qRTonjynh0MF8VCpmnyoM6djVI0NyLGiJOhaRO+kltK3C+jgwh
w2LMpNGtFmuae8tk/426QsMmqhV4aJzs9mvIDFcN5TgH02pXA50gDkvEe4GwKhz1
SupKmEn+Als9AxSQKH6a9HjQMYRX5Uw4ekIR4vUoUQNLIBW7Ihq28BUCAwEAAaOB
2TCB1jAOBgNVHQ8BAf8EBAMCAQYwHQYDVR0OBBYEFIz02ZMKR7wAoErOS3VuoLaw
sn78MB8GA1UdIwQYMBaAFMB6mGiNifurBWQMEX2qfWW4ysxOMBIGA1UdEwEB/wQI
MAYBAf8CAQAwOgYDVR0fBDMwMTAvoC2gK4YpaHR0cDovL2NybC5nZW90cnVzdC5j
b20vY3Jscy9ndGdsb2JhbC5jcmwwNAYIKwYBBQUHAQEEKDAmMCQGCCsGAQUFBzAB
hhhodHRwOi8vb2NzcC5nZW90cnVzdC5jb20wDQYJKoZIhvcNAQEFBQADggEBADOR
NxHbQPnejLICiHevYyHBrbAN+qB4VqOC/btJXxRtyNxflNoRZnwekcW22G1PqvK/
ISh+UqKSeAhhaSH+LeyCGIT0043FiruKzF3mo7bMbq1vsw5h7onOEzRPSVX1ObuZ
lvD16lo8nBa9AlPwKg5BbuvvnvdwNs2AKnbIh+PrI7OWLOYdlF8cpOLNJDErBjgy
YWE5XIlMSB1CyWee0r9Y9/k3MbBn3Y0mNhp4GgkZPJMHcCrhfCn13mZXCxJeFu1e
vTezMGnGkqX2Gdgd+DYSuUuVlZzQzmwwpxb79k1ktl8qFJymyFWOIPllByTMOAVM
IIi0tWeUz12OYjf+xLQ=
-----END CERTIFICATE-----"

		issuer7="GeoTrust Extended Validation SSL CA"
		issuer7Chain="-----BEGIN CERTIFICATE-----
MIIEnDCCA4SgAwIBAgIQaUiiayAapCHomLHEksfFjjANBgkqhkiG9w0BAQUFADBY
MQswCQYDVQQGEwJVUzEWMBQGA1UEChMNR2VvVHJ1c3QgSW5jLjExMC8GA1UEAxMo
R2VvVHJ1c3QgUHJpbWFyeSBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eTAeFw0wNjEx
MjkwMDAwMDBaFw0xNjExMjgyMzU5NTlaMIGFMQswCQYDVQQGEwJVUzEVMBMGA1UE
ChMMR2VvVHJ1c3QgSW5jMTEwLwYDVQQLEyhTZWUgd3d3Lmdlb3RydXN0LmNvbS9y
ZXNvdXJjZXMvY3BzIChjKTA2MSwwKgYDVQQDEyNHZW9UcnVzdCBFeHRlbmRlZCBW
YWxpZGF0aW9uIFNTTCBDQTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEB
AMLv7ewLLXKKdGhzNm4QqH5If1i7eGfc7XvWfKZPPZ9dbwrQoLRl/b7Tv3e2lKWC
/4GVnSgQBuzCtJCqWlFMc9lrdKg1SfSmNoDUXHWennwBx4ycgciGgxqOvQATotz/
pXiqdywhYgiXP4C992ekedt91z5uttWWuZiGTnpn4pOv2qXRJ/vxZsMqAwy2x4Id
Ofs83ik2cV3hqLUWOXwb/3uG9YCSleADO6pE+/QAteWp4voY+YSaweH2Lg6BixQp
NP8fVWCIpJnGb28EOTp1pKceWN+3/8maHXDbg6DTgxstbSqQW6NjkXO1/52CekHz
06ovCw2fz0TAXseha8+ulNsCAwEAAaOCATIwggEuMB0GA1UdDgQWBBQoxOuP8V95
kKMrVcNWTn1rU3IsGDA9BggrBgEFBQcBAQQxMC8wLQYIKwYBBQUHMAGGIWh0dHA6
Ly9FVlNlY3VyZS1vY3NwLmdlb3RydXN0LmNvbTASBgNVHRMBAf8ECDAGAQH/AgEA
MEYGA1UdIAQ/MD0wOwYEVR0gADAzMDEGCCsGAQUFBwIBFiVodHRwOi8vd3d3Lmdl
b3RydXN0LmNvbS9yZXNvdXJjZXMvY3BzMEEGA1UdHwQ6MDgwNqA0oDKGMGh0dHA6
Ly9FVlNlY3VyZS1jcmwuZ2VvdHJ1c3QuY29tL0dlb1RydXN0UENBLmNybDAOBgNV
HQ8BAf8EBAMCAQYwHwYDVR0jBBgwFoAULNVQQZcVi/CPNmFbSvtr2ZnJM5IwDQYJ
KoZIhvcNAQEFBQADggEBAAJgoxYSndgcGeRaN2z/Mpg3Rk+8gXyAw8qJKgD+Xj7s
uowrH6uVa5GUIaBgHwIG+s8XbfiVq814IxSWwJ0fG+tQ4WVCitKzya2Aw2fPtFgb
1QTkWP40ReD7pIQii+niN0yY8Qv/pIlT0U3AaEjXWYcaO3310Pkjcspg/cMiFfCa
lVhvfCST7KUSPbQbAejuae1Ba1LLmrdcFdG9BkB64AyXy2Dngl9qX95JhFZqr3yw
S62MTw95oMwRPCXnRr960C+IyL/rlAtqdTN/cwC4EnAjXlV/RVseELECaNgnQM8k
CeJldM6JRI17KJBorqzCOMhWDTOIKH9U/Dw8UAmTPTg=
-----END CERTIFICATE-----"

		issuer8="RapidSSL CA"
		issuer8Chain="-----BEGIN CERTIFICATE-----
MIID1TCCAr2gAwIBAgIDAjbRMA0GCSqGSIb3DQEBBQUAMEIxCzAJBgNVBAYTAlVT
MRYwFAYDVQQKEw1HZW9UcnVzdCBJbmMuMRswGQYDVQQDExJHZW9UcnVzdCBHbG9i
YWwgQ0EwHhcNMTAwMjE5MjI0NTA1WhcNMjAwMjE4MjI0NTA1WjA8MQswCQYDVQQG
EwJVUzEXMBUGA1UEChMOR2VvVHJ1c3QsIEluYy4xFDASBgNVBAMTC1JhcGlkU1NM
IENBMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAx3H4Vsce2cy1rfa0
l6P7oeYLUF9QqjraD/w9KSRDxhApwfxVQHLuverfn7ZB9EhLyG7+T1cSi1v6kt1e
6K3z8Buxe037z/3R5fjj3Of1c3/fAUnPjFbBvTfjW761T4uL8NpPx+PdVUdp3/Jb
ewdPPeWsIcHIHXro5/YPoar1b96oZU8QiZwD84l6pV4BcjPtqelaHnnzh8jfyMX8
N8iamte4dsywPuf95lTq319SQXhZV63xEtZ/vNWfcNMFbPqjfWdY3SZiHTGSDHl5
HI7PynvBZq+odEj7joLCniyZXHstXZu8W1eefDp6E63yoxhbK1kPzVw662gzxigd
gtFQiwIDAQABo4HZMIHWMA4GA1UdDwEB/wQEAwIBBjAdBgNVHQ4EFgQUa2k9ahhC
St2PAmU5/TUkhniRFjAwHwYDVR0jBBgwFoAUwHqYaI2J+6sFZAwRfap9ZbjKzE4w
EgYDVR0TAQH/BAgwBgEB/wIBADA6BgNVHR8EMzAxMC+gLaArhilodHRwOi8vY3Js
Lmdlb3RydXN0LmNvbS9jcmxzL2d0Z2xvYmFsLmNybDA0BggrBgEFBQcBAQQoMCYw
JAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmdlb3RydXN0LmNvbTANBgkqhkiG9w0B
AQUFAAOCAQEAq7y8Cl0YlOPBscOoTFXWvrSY8e48HM3P8yQkXJYDJ1j8Nq6iL4/x
/torAsMzvcjdSCIrYA+lAxD9d/jQ7ZZnT/3qRyBwVNypDFV+4ZYlitm12ldKvo2O
SUNjpWxOJ4cl61tt/qJ/OCjgNqutOaWlYsS3XFgsql0BYKZiZ6PAx2Ij9OdsRu61
04BqIhPSLT90T+qvjF+0OJzbrs6vhB6m9jRRWXnT43XcvNfzc9+S7NIgWW+c+5X4
knYYCnwPLKbK3opie9jzzl9ovY8+wXS7FXI6FoOpC+ZNmZzYV+yoAVHHb1c0XqtK
LEL2TxyJeN4mTvVvk0wVaydWTQBUbHq3tw==
-----END CERTIFICATE-----"

		issuer9="Thawte DV SSL CA"
		issuer9Chain="-----BEGIN CERTIFICATE-----
MIIEjzCCA3egAwIBAgIQdhASihe2grs6H50amjXAkjANBgkqhkiG9w0BAQUFADCB
qTELMAkGA1UEBhMCVVMxFTATBgNVBAoTDHRoYXd0ZSwgSW5jLjEoMCYGA1UECxMf
Q2VydGlmaWNhdGlvbiBTZXJ2aWNlcyBEaXZpc2lvbjE4MDYGA1UECxMvKGMpIDIw
MDYgdGhhd3RlLCBJbmMuIC0gRm9yIGF1dGhvcml6ZWQgdXNlIG9ubHkxHzAdBgNV
BAMTFnRoYXd0ZSBQcmltYXJ5IFJvb3QgQ0EwHhcNMTAwMjE4MDAwMDAwWhcNMjAw
MjE3MjM1OTU5WjBeMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMVGhhd3RlLCBJbmMu
MR0wGwYDVQQLExREb21haW4gVmFsaWRhdGVkIFNTTDEZMBcGA1UEAxMQVGhhd3Rl
IERWIFNTTCBDQTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMuYyTY/
0pzYFgfUSWP5g7DoAi3MXFp0l6YT7xMT3gV8p+bKACPaOfnvE89Sxa+a48q+84LZ
iz2q4cyuiFBmoy3sYRR1SasOJPGsRFsLKKIzIHYeBmBqZwVxi7pmYhZ6s20Nx9CU
QMaMPR6SDGI0DUSJ1feJ/intGI/2mysI92qr2EiXWvSf7Qx1UiL31V6EAJ/ASg0x
d0xk0BLmDzrwocDVXB3nXy3C99Y2GNmVbkROyVgUTbaOu83eYh76W7W9GCuYrKyT
P1Ba9RQLos+2855PWs1awzYj2hqvsE3WSiIDj0MCGb3qrN3EejUyFPFyLghVQAz0
B0FBrzg3hClCslUCAwEAAaOB/DCB+TAyBggrBgEFBQcBAQQmMCQwIgYIKwYBBQUH
MAGGFmh0dHA6Ly9vY3NwLnRoYXd0ZS5jb20wEgYDVR0TAQH/BAgwBgEB/wIBADA0
BgNVHR8ELTArMCmgJ6AlhiNodHRwOi8vY3JsLnRoYXd0ZS5jb20vVGhhd3RlUENB
LmNybDAOBgNVHQ8BAf8EBAMCAQYwKQYDVR0RBCIwIKQeMBwxGjAYBgNVBAMTEVZl
cmlTaWduTVBLSS0yLTExMB0GA1UdDgQWBBSrRORd7IPH2cCFn/fhxpeQsIw/mDAf
BgNVHSMEGDAWgBR7W0XPr87Lev0xkhpqtvNG61dIUDANBgkqhkiG9w0BAQUFAAOC
AQEABLr7rLv8S1QRoy2Iszy9AG2KGraNxMGD+MdTKsEybjqBoVR92ho/OkVPNudC
sApChZegrPvlh6eDT+ixt5tYZW4mgAuSTUdVuWEWUWXpK/Fo2Vi4A4HRt2Yc07zF
pntfPsU4RnbndbSgDEvOosKpwcw2c3v7uSQkoF6n9vq7DChDnh3wTvA/2CSwIdxt
Le6/Wjv6iJx0bK8h3ZLswxXvlHUmRtamP79mSKod790n5rdRiTh9E4QMQPzQtfHg
2/lPL0ActI5HImG4TJbe8F8Rfk8R2exQRyIOxR3iZEnnaGNFOorZcfRe8W63FE0+
bxQe3FL+vN8MvSk/dvsRX2hoFQ==
-----END CERTIFICATE-----"

		issuer10="Thawte SSL CA"
		issuer10Chain="-----BEGIN CERTIFICATE-----
MIIEbDCCA1SgAwIBAgIQTV8sNAiyTCDNbVB+JE3J7DANBgkqhkiG9w0BAQUFADCB
qTELMAkGA1UEBhMCVVMxFTATBgNVBAoTDHRoYXd0ZSwgSW5jLjEoMCYGA1UECxMf
Q2VydGlmaWNhdGlvbiBTZXJ2aWNlcyBEaXZpc2lvbjE4MDYGA1UECxMvKGMpIDIw
MDYgdGhhd3RlLCBJbmMuIC0gRm9yIGF1dGhvcml6ZWQgdXNlIG9ubHkxHzAdBgNV
BAMTFnRoYXd0ZSBQcmltYXJ5IFJvb3QgQ0EwHhcNMTAwMjA4MDAwMDAwWhcNMjAw
MjA3MjM1OTU5WjA8MQswCQYDVQQGEwJVUzEVMBMGA1UEChMMVGhhd3RlLCBJbmMu
MRYwFAYDVQQDEw1UaGF3dGUgU1NMIENBMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8A
MIIBCgKCAQEAmeSFW3ZJfS8F2MWsyMip09yY5tc0pi8M8iIm2KPJFEyPBaRF6BQM
WJAFGrfFwQalgK+7HUlrUjSIw1nn72vEJ0GMK2Yd0OCjl5gZNEtB1ZjVxwWtouTX
7QytT8G1sCH9PlBTssSQ0NQwZ2ya8Q50xMLciuiX/8mSrgGKVgqYMrAAI+yQGmDD
7bs6yw9jnw1EyVLhJZa/7VCViX9WFLG3YR0cB4w6LPf/gN45RdWvGtF42MdxaqMZ
pzJQIenyDqHGEwNESNFmqFJX1xG0k4vlmZ9d53hR5U32t1m0drUJN00GOBN6HAiY
XMRISstSoKn4sZ2Oe3mwIC88lqgRYke7EQIDAQABo4H7MIH4MDIGCCsGAQUFBwEB
BCYwJDAiBggrBgEFBQcwAYYWaHR0cDovL29jc3AudGhhd3RlLmNvbTASBgNVHRMB
Af8ECDAGAQH/AgEAMDQGA1UdHwQtMCswKaAnoCWGI2h0dHA6Ly9jcmwudGhhd3Rl
LmNvbS9UaGF3dGVQQ0EuY3JsMA4GA1UdDwEB/wQEAwIBBjAoBgNVHREEITAfpB0w
GzEZMBcGA1UEAxMQVmVyaVNpZ25NUEtJLTItOTAdBgNVHQ4EFgQUp6KDuzRFQD38
1TBPErk+oQGf9tswHwYDVR0jBBgwFoAUe1tFz6/Oy3r9MZIaarbzRutXSFAwDQYJ
KoZIhvcNAQEFBQADggEBAIAigOBsyJUW11cmh/NyNNvGclYnPtOW9i4lkaU+M5en
S+Uv+yV9Lwdh+m+DdExMU3IgpHrPUVFWgYiwbR82LMgrsYiZwf5Eq0hRfNjyRGQq
2HGn+xov+RmNNLIjv8RMVR2OROiqXZrdn/0Dx7okQ40tR0Tb9tiYyLL52u/tKVxp
EvrRI5YPv5wN8nlFUzeaVi/oVxBw9u6JDEmJmsEj9cIqzEHPIqtlbreUgm0vQF9Y
3uuVK6ZyaFIZkSqudZ1OkubK3lTqGKslPOZkpnkfJn1h7X3S5XFV2JMXfBQ4MDzf
huNMrUnjl1nOG5srztxl1Asoa06ERlFE9zMILViXIa4=
-----END CERTIFICATE-----"

		issuer11="thawte Extended Validation SSL CA"
		issuer11Chain="-----BEGIN CERTIFICATE-----
MIIFCjCCA/KgAwIBAgIQexFV63iakIW1jJL/Qrf+VjANBgkqhkiG9w0BAQUFADCB
qTELMAkGA1UEBhMCVVMxFTATBgNVBAoTDHRoYXd0ZSwgSW5jLjEoMCYGA1UECxMf
Q2VydGlmaWNhdGlvbiBTZXJ2aWNlcyBEaXZpc2lvbjE4MDYGA1UECxMvKGMpIDIw
MDYgdGhhd3RlLCBJbmMuIC0gRm9yIGF1dGhvcml6ZWQgdXNlIG9ubHkxHzAdBgNV
BAMTFnRoYXd0ZSBQcmltYXJ5IFJvb3QgQ0EwHhcNMDYxMTE3MDAwMDAwWhcNMTYx
MTE2MjM1OTU5WjCBizELMAkGA1UEBhMCVVMxFTATBgNVBAoTDHRoYXd0ZSwgSW5j
LjE5MDcGA1UECxMwVGVybXMgb2YgdXNlIGF0IGh0dHBzOi8vd3d3LnRoYXd0ZS5j
b20vY3BzIChjKTA2MSowKAYDVQQDEyF0aGF3dGUgRXh0ZW5kZWQgVmFsaWRhdGlv
biBTU0wgQ0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQC1jUf3sEh2
m737qcu/BDGiPZp+MCnTKLj+aM7P6TBqU5UOUGWAJsmYv/IU/wZ8anvcUAfimPrf
zzBdyqi5ipstLX5Zixr3s8nDaYAPiRkId7JSVa14g51ruYfkUyQ3LPwZDot5FE2+
gJ60m3N0MfI47IqvKjaOZM4xJhQDVFOO+4QIwX5HMj1x4Lq6jIJYlk1oQ1Ya80Za
MpmVsGBv6UGKSMwWDURosYrd3Rc9pJt4fy4pBvDc1dITP8A2Bf3HtbmAG4pGdC/x
q3mel274pRNa8/y118iWGTfuBrzGJxSBBRQzOBafS+IP2zi78wHvNS7er/Hkb2/3
lgBWXo9glB0vAgMBAAGjggFIMIIBRDA7BggrBgEFBQcBAQQvMC0wKwYIKwYBBQUH
MAGGH2h0dHA6Ly9FVlNlY3VyZS1vY3NwLnRoYXd0ZS5jb20wEgYDVR0TAQH/BAgw
BgEB/wIBADA7BgNVHSAENDAyMDAGBFUdIAAwKDAmBggrBgEFBQcCARYaaHR0cHM6
Ly93d3cudGhhd3RlLmNvbS9jcHMwNAYDVR0fBC0wKzApoCegJYYjaHR0cDovL2Ny
bC50aGF3dGUuY29tL1RoYXd0ZVBDQS5jcmwwDgYDVR0PAQH/BAQDAgEGMC4GA1Ud
EQQnMCWkIzAhMR8wHQYDVQQDExZQcml2YXRlTGFiZWwzLTIwNDgtMjM0MB0GA1Ud
DgQWBBTNMuLyXSVHAqqPeUsy7gOZ/TBJ0TAfBgNVHSMEGDAWgBR7W0XPr87Lev0x
khpqtvNG61dIUDANBgkqhkiG9w0BAQUFAAOCAQEAC7SWzgMM0Z2vy+M5Vg3GIqDJ
cX3qZZUx8dy2HvKNMV1hs1SEE8wrPwJcxx8VAYKQHjElBuMyDIfww76axABB9saR
5Ww+kl2j5D0fMi0xHlDBAiG0I+MHdZpSRVH60x39AW9gbSXZv0Oxp0NsrYy7vPeZ
QevWlc8gXH5vxCraS00bW8KfsJTUv0eX/Z1JeWCOrpYZobDr6N9CxyJ0YQwlo3+P
RdJ+50puHU9Iu8LaGn5KWYH6HOP7FHNBA6F3+psG/HwzvUY9DAYXhXsqe+M26IPf
+qrLMgx5qoZ0bERU9tgHns2Y9CMFCS+iU7XbCoHMXyPLeRHFEVuFaycBifMOuw==
-----END CERTIFICATE-----"

		issuer12="Thawte SGC CA - G2"
		issuer12Chain="-----BEGIN CERTIFICATE-----
MIIEyzCCA7OgAwIBAgIQGKIjbNcnx1KN9ntLhW7/7TANBgkqhkiG9w0BAQUFADCB
yjELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDlZlcmlTaWduLCBJbmMuMR8wHQYDVQQL
ExZWZXJpU2lnbiBUcnVzdCBOZXR3b3JrMTowOAYDVQQLEzEoYykgMjAwNiBWZXJp
U2lnbiwgSW5jLiAtIEZvciBhdXRob3JpemVkIHVzZSBvbmx5MUUwQwYDVQQDEzxW
ZXJpU2lnbiBDbGFzcyAzIFB1YmxpYyBQcmltYXJ5IENlcnRpZmljYXRpb24gQXV0
aG9yaXR5IC0gRzUwHhcNMTAwNzI5MDAwMDAwWhcNMjAwNzI4MjM1OTU5WjBBMQsw
CQYDVQQGEwJVUzEVMBMGA1UEChMMVGhhd3RlLCBJbmMuMRswGQYDVQQDExJUaGF3
dGUgU0dDIENBIC0gRzIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDN
2elcVUzG/SYNPJ1WOnpGAgXr8MKtvhIvWf9nNSnZadlNNz5th0m8u9UWYkQpcZZc
pifoxZz8GQspry5c2guPv+1TFaeCNTBeCDYyJDY2GuRyK8RoSKR4HzM0IP6Xbpys
Ov3m/YNfdYNxXZDfvUhXbRAmr29B2Mx4nj2chSiJQzGrp26hvALmvo/DY6RkaDsb
w9ozyHtaH9YIcrI2NBjTIE+Y6AKT31CyZ8g9lmRVx2klCrohNnDTWaiC0lRtTgZa
4dgHjTW40BahdP5KG3CoqUOagCegQLdv+eOoqB6KkzyWNqeI6TadwePvtn4CN2IJ
14vGcNkyUJqxpx5UIR5JAgMBAAGjggEzMIIBLzAyBggrBgEFBQcBAQQmMCQwIgYI
KwYBBQUHMAGGFmh0dHA6Ly9vY3NwLnRoYXd0ZS5jb20wEgYDVR0TAQH/BAgwBgEB
/wIBADA0BgNVHR8ELTArMCmgJ6AlhiNodHRwOi8vY3JsLnZlcmlzaWduLmNvbS9w
Y2EzLWc1LmNybDA0BgNVHSUELTArBggrBgEFBQcDAQYIKwYBBQUHAwIGCWCGSAGG
+EIEAQYKYIZIAYb4RQEIATAOBgNVHQ8BAf8EBAMCAQYwKQYDVR0RBCIwIKQeMBwx
GjAYBgNVBAMTEVZlcmlTaWduTVBLSS0yLTE3MB0GA1UdDgQWBBQkwMCkSTxSCxLY
kgxR0YenTVR1LDAfBgNVHSMEGDAWgBR/02Wnwt3su/AwCfNDOfoCrzMxMzANBgkq
hkiG9w0BAQUFAAOCAQEAONp2NRhJMjTwtOgoCEXrj2I+mSFyd5XgNoKz/6t/Emzh
HBDJVJjlDDF0zIB6oCanRcgRTHbk0KmxyJKjgHkmDY3PyEdjLRM8wpY01wBCOkqL
nhep3MlQxUDhKUVhIvWzsIh4ja6hjVBvRIJ0UocVDBxO8hY32sEFadkBVO7NcUn2
bFZ8dXPiip+maddgnwTDo5+BYLPFvaVV0GnbRZhkIPLAi4xO6VdSNqu7U2cwiWMT
KPNE0UN2tIFoKgchP4/0Z9MIoHnezLlTLR9E01ScowdNigg0Td0Xev6ta0uZtgDJ
YnZ+mJqiSRyGvrJVlSwtJyG8GbDxPq220Rre7bbuNQ==
-----END CERTIFICATE-----"

issuer13="GeoTrust DSA SSL CA"
		issuer13Chain="-----BEGIN CERTIFICATE-----
MIIGKDCCBc6gAwIBAgIQFqvLXu4iB8dSKCVCtHHYozALBglghkgBZQMEAwIwgZgx
CzAJBgNVBAYTAlVTMRYwFAYDVQQKEw1HZW9UcnVzdCBJbmMuMTkwNwYDVQQLEzAo
YykgMjAxMiBHZW9UcnVzdCBJbmMuIC0gRm9yIGF1dGhvcml6ZWQgdXNlIG9ubHkx
NjA0BgNVBAMTLUdlb1RydXN0IFByaW1hcnkgQ2VydGlmaWNhdGlvbiBBdXRob3Jp
dHkgLSBHNDAeFw0xMjEyMjAwMDAwMDBaFw0yMjEyMTkyMzU5NTlaMEMxCzAJBgNV
BAYTAlVTMRYwFAYDVQQKEw1HZW9UcnVzdCBJbmMuMRwwGgYDVQQDExNHZW9UcnVz
dCBEU0EgU1NMIENBMIIDSDCCAjoGByqGSM44BAEwggItAoIBAQCw6R9PSn05ePT+
P0f6bYSPK7pVMumPJ0rX91bKX8BBLlYTkY+DLSLqglAJIQotxm0kJyevH1fZYmr9
T2zFLJ2rSg/VHsGpeJGzd+mGQmcGFb84Yk2fDXd2cGu319+Zpk0UVEJRA6wYOxKM
E85RDi256cF4Xdmz4MB+QNfPFysrg5CzqpNi5ufxBSmFygxpRREm/1pjxV9Wk4M3
dnkV5qatjvbMBwa9z1qMWXjm9WUr90Nu7yQwx2lvXC40xNZSj93F0+u2CkkDdmc3
0wNLOza1wZbFielYVlOd1N4+fvFTRvev+k3/KzuLkUGvXKphVZ6W3m4YsyD5lDbY
ZCeBrz95AiEAp1UgPdxEok2bRF3vtIz8aBjjfTCZ58O/FLqlAMacDNcCggEBAItC
IotTyREGxYiR65E8qVurBIyRs3Bo5grr8uHzHmTbR2MCo866se3M1acA8C9k9hKM
v49HXJ0eri1EMSCNpViVvlll4Pwvq/Qn85Y1OlJKZ4rMd8PVBE//Z3GqI3B6K9RH
i/DubrCDxjlnE4UpuAB90zTzPaFuOS5ysLORsKvQ1BSRTL43iC8wo4hUNhVSIpQV
ImaVGJiUJck1qgiQpZxvg2NEEeMMpuabj4ixyjg9RDcTtX4J1LoLyE490PCFxibo
U+uBtM9y66gmAQjpheODLAYIyNrrPASZTUX00fr1OalmIoIUNWGsF3kqA56aKK94
ATYABTVy1jPWmSq3Z1cDggEGAAKCAQEAp76cuCuy6OzEm+mG9DUIYCJBH2RcZa+0
OefEJ1AOzF364FtL1UGuol7eIF2NNrFVGzoDNAIPn/3gdyiuMNyeytEApZqHEAEh
D4R9TiNuFfEtk+RiohNseXf8pcBIVZHyf1xEfVBjBs4QBX99wA+LSh+Qcx77bPBl
AeiV7hjVHjGur/ckiaUmrptJgcoobPXC0qXYA11UqiLxSQCgQepjn+FKtajfaL3A
NG6OAwvScMpuJ+kriBE4D1iSVr4pxYUqz7w1E4ks0MBVNAR/UsCF6fkyVMiA+VG9
5m/k0U/l2ZFWA0YsyPN5U3kzq+TX1KPoGmBSp6RvMK22MXq/IybdLqOCAVowggFW
MA4GA1UdDwEB/wQEAwIBBjA7BggrBgEFBQcBAQQvMC0wKwYIKwYBBQUHMAGGH2h0
dHA6Ly9wY2EtZzQtb2NzcC5nZW90cnVzdC5jb20wEgYDVR0TAQH/BAgwBgEB/wIB
ADBGBgNVHSAEPzA9MDsGBFUdIAAwMzAxBggrBgEFBQcCARYlaHR0cDovL3d3dy5n
ZW90cnVzdC5jb20vcmVzb3VyY2VzL2NwczA7BgNVHR8ENDAyMDCgLqAshipodHRw
Oi8vY3JsLmdlb3RydXN0LmNvbS9HZW9UcnVzdFBDQS1HNC5jcmwwLgYDVR0RBCcw
JaQjMCExHzAdBgNVBAMTFlNZTUMtRFNBLUNBLTIwNDgtMjU2LTUwHQYDVR0OBBYE
FDbLuhnZIpKk13i2KQ0WgQD7z/OQMB8GA1UdIwQYMBaAFJXfXnTAgtDIJ9nGaSpq
f0zScsyGMAsGCWCGSAFlAwQDAgNHADBEAiBECdTopEoHoDnWVAjCt/HWhBI6oHLr
kKHvuT7X/WNp9wIgOpeupMvaoiYFCU6j+3IN4BxJfVAT33ReB8IFSwjRl9k=
-----END CERTIFICATE-----"

issuer14="RapidSSL Enterprise DSA SSL CA"
		issuer14Chain="-----BEGIN CERTIFICATE-----
MIIGWTCCBf6gAwIBAgIQVo61t8H1d+mYT30jNZQZTjALBglghkgBZQMEAwIwgZgx
CzAJBgNVBAYTAlVTMRYwFAYDVQQKEw1HZW9UcnVzdCBJbmMuMTkwNwYDVQQLEzAo
YykgMjAxMiBHZW9UcnVzdCBJbmMuIC0gRm9yIGF1dGhvcml6ZWQgdXNlIG9ubHkx
NjA0BgNVBAMTLUdlb1RydXN0IFByaW1hcnkgQ2VydGlmaWNhdGlvbiBBdXRob3Jp
dHkgLSBHNDAeFw0xMjEyMjAwMDAwMDBaFw0yMjEyMTkyMzU5NTlaMG4xCzAJBgNV
BAYTAlVTMRYwFAYDVQQKEw1HZW9UcnVzdCBJbmMuMR4wHAYDVQQLExVGb3IgSW50
ZXJuYWwgVXNlIE9ubHkxJzAlBgNVBAMTHlJhcGlkU1NMIEVudGVycHJpc2UgRFNB
IFNTTCBDQTCCA0cwggI6BgcqhkjOOAQBMIICLQKCAQEAsOkfT0p9OXj0/j9H+m2E
jyu6VTLpjydK1/dWyl/AQS5WE5GPgy0i6oJQCSEKLcZtJCcnrx9X2WJq/U9sxSyd
q0oP1R7BqXiRs3fphkJnBhW/OGJNnw13dnBrt9ffmaZNFFRCUQOsGDsSjBPOUQ4t
uenBeF3Zs+DAfkDXzxcrK4OQs6qTYubn8QUphcoMaUURJv9aY8VfVpODN3Z5Feam
rY72zAcGvc9ajFl45vVlK/dDbu8kMMdpb1wuNMTWUo/dxdPrtgpJA3ZnN9MDSzs2
tcGWxYnpWFZTndTePn7xU0b3r/pN/ys7i5FBr1yqYVWelt5uGLMg+ZQ22GQnga8/
eQIhAKdVID3cRKJNm0Rd77SM/GgY430wmefDvxS6pQDGnAzXAoIBAQCLQiKLU8kR
BsWIkeuRPKlbqwSMkbNwaOYK6/Lh8x5k20djAqPOurHtzNWnAPAvZPYSjL+PR1yd
Hq4tRDEgjaVYlb5ZZeD8L6v0J/OWNTpSSmeKzHfD1QRP/2dxqiNweivUR4vw7m6w
g8Y5ZxOFKbgAfdM08z2hbjkucrCzkbCr0NQUkUy+N4gvMKOIVDYVUiKUFSJmlRiY
lCXJNaoIkKWcb4NjRBHjDKbmm4+Isco4PUQ3E7V+CdS6C8hOPdDwhcYm6FPrgbTP
cuuoJgEI6YXjgywGCMja6zwEmU1F9NH69TmpZiKCFDVhrBd5KgOemiiveAE2AAU1
ctYz1pkqt2dXA4IBBQACggEAeQhnjhxUX26SheigtiIZPoA1SMneHhr/f0HBL7fR
AkyIscjyZ5vJUG7CStQBVHyomgFIRZtGSECP9aPhDEHgDUkTv0/UcXWyaTl6o7KF
NZzl9URCizxeuSNU4EGZwEehQKMRHPhsU686RE/RFPsALqhCbDSMG0DPuUcuQL7z
erZfabjrQF9ae0823qdWVOq2sSTV1GmxgpZfTvsa0WAbNFnGBh0cL24ASETxOPwd
l3IRP63GBTabJtFvU8qpIZYGYwsg0Qvxwh66nO3N0CqlQjUJrzRzVD0yZKDwjDow
R9V53z531D8JB97zvk+flxSLgdvKvKZ/9FIn1QoaswHR76OCAWAwggFcMA4GA1Ud
DwEB/wQEAwIBBjASBgNVHRMBAf8ECDAGAQH/AgEAMDsGA1UdHwQ0MDIwMKAuoCyG
Kmh0dHA6Ly9jcmwuZ2VvdHJ1c3QuY29tL0dlb1RydXN0UENBLUc0LmNybDA7Bggr
BgEFBQcBAQQvMC0wKwYIKwYBBQUHMAGGH2h0dHA6Ly9wY2EtZzQtb2NzcC5nZW90
cnVzdC5jb20wTAYDVR0gBEUwQzBBBgpghkgBhvhFAQc2MDMwMQYIKwYBBQUHAgEW
JWh0dHA6Ly93d3cuZ2VvdHJ1c3QuY29tL3Jlc291cmNlcy9jcHMwLgYDVR0RBCcw
JaQjMCExHzAdBgNVBAMTFlNZTUMtRFNBLUNBLTIwNDgtMjU2LTYwHQYDVR0OBBYE
FByKhM3+wb0F3UY2bpjKd+QQ75cbMB8GA1UdIwQYMBaAFJXfXnTAgtDIJ9nGaSpq
f0zScsyGMAsGCWCGSAFlAwQDAgNIADBFAiBcYfnQl8EZh4gMahkzaXOEXLsWVcEu
MNNS3ovZCNk/4gIhAIAIMYuQd99w053Iy4CBasPJ8B3FVBQ8ERy051/YTMDb
-----END CERTIFICATE-----"

issuer15="Symantec Class 3 DSA EV SSL CA"
		issuer15Chain="-----BEGIN CERTIFICATE-----
MIIGbjCCBhOgAwIBAgIQetPPk/r+BsI14Z0ys1BzqjALBglghkgBZQMEAwIwgZQx
CzAJBgNVBAYTAlVTMR0wGwYDVQQKExRTeW1hbnRlYyBDb3Jwb3JhdGlvbjEfMB0G
A1UECxMWU3ltYW50ZWMgVHJ1c3QgTmV0d29yazFFMEMGA1UEAxM8U3ltYW50ZWMg
Q2xhc3MgMyBQdWJsaWMgUHJpbWFyeSBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eSAt
IEc3MB4XDTEyMTIyMDAwMDAwMFoXDTIyMTIxOTIzNTk1OVowdjELMAkGA1UEBhMC
VVMxHTAbBgNVBAoTFFN5bWFudGVjIENvcnBvcmF0aW9uMR8wHQYDVQQLExZTeW1h
bnRlYyBUcnVzdCBOZXR3b3JrMScwJQYDVQQDEx5TeW1hbnRlYyBDbGFzcyAzIERT
QSBFViBTU0wgQ0EwggNHMIICOgYHKoZIzjgEATCCAi0CggEBALDpH09KfTl49P4/
R/pthI8rulUy6Y8nStf3VspfwEEuVhORj4MtIuqCUAkhCi3GbSQnJ68fV9liav1P
bMUsnatKD9Uewal4kbN36YZCZwYVvzhiTZ8Nd3Zwa7fX35mmTRRUQlEDrBg7EowT
zlEOLbnpwXhd2bPgwH5A188XKyuDkLOqk2Lm5/EFKYXKDGlFESb/WmPFX1aTgzd2
eRXmpq2O9swHBr3PWoxZeOb1ZSv3Q27vJDDHaW9cLjTE1lKP3cXT67YKSQN2ZzfT
A0s7NrXBlsWJ6VhWU53U3j5+8VNG96/6Tf8rO4uRQa9cqmFVnpbebhizIPmUNthk
J4GvP3kCIQCnVSA93ESiTZtEXe+0jPxoGON9MJnnw78UuqUAxpwM1wKCAQEAi0Ii
i1PJEQbFiJHrkTypW6sEjJGzcGjmCuvy4fMeZNtHYwKjzrqx7czVpwDwL2T2Eoy/
j0dcnR6uLUQxII2lWJW+WWXg/C+r9CfzljU6Ukpnisx3w9UET/9ncaojcHor1EeL
8O5usIPGOWcThSm4AH3TNPM9oW45LnKws5Gwq9DUFJFMvjeILzCjiFQ2FVIilBUi
ZpUYmJQlyTWqCJClnG+DY0QR4wym5puPiLHKOD1ENxO1fgnUugvITj3Q8IXGJuhT
64G0z3LrqCYBCOmF44MsBgjI2us8BJlNRfTR+vU5qWYighQ1YawXeSoDnpoor3gB
NgAFNXLWM9aZKrdnVwOCAQUAAoIBAC8a5Y92zHDPwC2mQI5O0gf2ss4EiWPqKZJt
OUIK4H2KOMNCkeWmarZU2kAf9+VneVxGeViCvFBR9ESMrExxGk1BcZmKWXiK8QsJ
XyFLXKOEB8frS9k8Laabq63mgQdrcFD7Bly7b7aoN19RmV/TC1elJemmjaqg7J1R
tnVVny4tFkDsWS13nq1svSDAX3tEdvOMCnoGYb8a2V+q0ben2/tnOFax1duMUlR7
o4xUuvJjoCBcuyFEcN4qBaHFNOfpRdEwnhcNJ8YdZVCjUrNlw+lo5FJJ+G8WVmdi
yvrhrQH5DMquxccGihlrpcbCOJifla0laJLqcQUVc032j/MGqOKjggFxMIIBbTAS
BgNVHRMBAf8ECDAGAQH/AgEAMA4GA1UdDwEB/wQEAwIBBjA3BgNVHR8EMDAuMCyg
KqAohiZodHRwOi8vY3JsLndzLnN5bWFudGVjLmNvbS9wY2EzLWc3LmNybDA3Bggr
BgEFBQcBAQQrMCkwJwYIKwYBBQUHMAGGG2h0dHA6Ly9vY3NwLndzLnN5bWFudGVj
LmNvbTBlBgNVHSAEXjBcMFoGBFUdIAAwUjAmBggrBgEFBQcCARYaaHR0cDovL3d3
dy5zeW1hdXRoLmNvbS9jcHMwKAYIKwYBBQUHAgIwHBoaaHR0cDovL3d3dy5zeW1h
dXRoLmNvbS9ycGEwLgYDVR0RBCcwJaQjMCExHzAdBgNVBAMTFlNZTUMtRFNBLUNB
LTIwNDgtMjU2LTMwHQYDVR0OBBYEFLmT6A8bEscN5Y1nNBoaUPeNgUeLMB8GA1Ud
IwQYMBaAFEfgXoEnCE4mVwLnHP0zV1MrG4+/MAsGCWCGSAFlAwQDAgNIADBFAiBx
NCLXmP0Zvpx0aTeW9YqVPl/BixTLll3dZ8y7KEsj2wIhAKE89SgPaXfIQJ42F9mV
jNhcFbrTdrxDzJuq1oXnlEvM
-----END CERTIFICATE-----"


issuer16="Symantec Class 3 DSA SSL CA"
		issuer16Chain="-----BEGIN CERTIFICATE-----
MIIGcTCCBhagAwIBAgIQHrFI4XdXwtOkTLqdcFZ3CDALBglghkgBZQMEAwIwgZQx
CzAJBgNVBAYTAlVTMR0wGwYDVQQKExRTeW1hbnRlYyBDb3Jwb3JhdGlvbjEfMB0G
A1UECxMWU3ltYW50ZWMgVHJ1c3QgTmV0d29yazFFMEMGA1UEAxM8U3ltYW50ZWMg
Q2xhc3MgMyBQdWJsaWMgUHJpbWFyeSBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eSAt
IEc3MB4XDTEyMTIyMDAwMDAwMFoXDTIyMTIxOTIzNTk1OVowczELMAkGA1UEBhMC
VVMxHTAbBgNVBAoTFFN5bWFudGVjIENvcnBvcmF0aW9uMR8wHQYDVQQLExZTeW1h
bnRlYyBUcnVzdCBOZXR3b3JrMSQwIgYDVQQDExtTeW1hbnRlYyBDbGFzcyAzIERT
QSBTU0wgQ0EwggNHMIICOgYHKoZIzjgEATCCAi0CggEBALDpH09KfTl49P4/R/pt
hI8rulUy6Y8nStf3VspfwEEuVhORj4MtIuqCUAkhCi3GbSQnJ68fV9liav1PbMUs
natKD9Uewal4kbN36YZCZwYVvzhiTZ8Nd3Zwa7fX35mmTRRUQlEDrBg7EowTzlEO
LbnpwXhd2bPgwH5A188XKyuDkLOqk2Lm5/EFKYXKDGlFESb/WmPFX1aTgzd2eRXm
pq2O9swHBr3PWoxZeOb1ZSv3Q27vJDDHaW9cLjTE1lKP3cXT67YKSQN2ZzfTA0s7
NrXBlsWJ6VhWU53U3j5+8VNG96/6Tf8rO4uRQa9cqmFVnpbebhizIPmUNthkJ4Gv
P3kCIQCnVSA93ESiTZtEXe+0jPxoGON9MJnnw78UuqUAxpwM1wKCAQEAi0Iii1PJ
EQbFiJHrkTypW6sEjJGzcGjmCuvy4fMeZNtHYwKjzrqx7czVpwDwL2T2Eoy/j0dc
nR6uLUQxII2lWJW+WWXg/C+r9CfzljU6Ukpnisx3w9UET/9ncaojcHor1EeL8O5u
sIPGOWcThSm4AH3TNPM9oW45LnKws5Gwq9DUFJFMvjeILzCjiFQ2FVIilBUiZpUY
mJQlyTWqCJClnG+DY0QR4wym5puPiLHKOD1ENxO1fgnUugvITj3Q8IXGJuhT64G0
z3LrqCYBCOmF44MsBgjI2us8BJlNRfTR+vU5qWYighQ1YawXeSoDnpoor3gBNgAF
NXLWM9aZKrdnVwOCAQUAAoIBADlBIUy5pAvX6fQDwi72FnGKOyLKsaKPMzWH/XPQ
809RyKM4TJfjGk7wHDYqHQOsAaPXzODSu3ZdUyv3Vm/E/GX3DoKV0huxOWv/nRsH
49jtqZuzmR6PRUCooAszuzYwdJTyaLq9Ia6szaHm3AuQ1ZjdIEhrXlcUMMrUi2nj
aMqXidk7hK/A5t2gwwp4lLqOr9p6wN1LBOWHU+zjUncKVqQ0DUd4HmpPgc5+jBeo
pk33Hei3Fg5yXw/1/KM+B/zzegqRqWdU4epmMDOegvJXoRHUTRWo8QDXqYhe7xEN
4i8qeG7CJaRXgxyedOp6XQcB2d7cB6nbgPGtVT0o1Idvm2+jggF3MIIBczASBgNV
HRMBAf8ECDAGAQH/AgEAMA4GA1UdDwEB/wQEAwIBBjA3BggrBgEFBQcBAQQrMCkw
JwYIKwYBBQUHMAGGG2h0dHA6Ly9vY3NwLndzLnN5bWFudGVjLmNvbTBrBgNVHSAE
ZDBiMGAGCmCGSAGG+EUBBzYwUjAmBggrBgEFBQcCARYaaHR0cDovL3d3dy5zeW1h
dXRoLmNvbS9jcHMwKAYIKwYBBQUHAgIwHBoaaHR0cDovL3d3dy5zeW1hdXRoLmNv
bS9ycGEwNwYDVR0fBDAwLjAsoCqgKIYmaHR0cDovL2NybC53cy5zeW1hbnRlYy5j
b20vcGNhMy1nNy5jcmwwLgYDVR0RBCcwJaQjMCExHzAdBgNVBAMTFlNZTUMtRFNB
LUNBLTIwNDgtMjU2LTIwHQYDVR0OBBYEFB/HzNYHMkqL3p1bu104SI32VyfQMB8G
A1UdIwQYMBaAFEfgXoEnCE4mVwLnHP0zV1MrG4+/MAsGCWCGSAFlAwQDAgNIADBF
AiBWJ3BPEHlOIxsU6xhK6/URGAhH6iR2O3d5Q8T6f8ahFAIhAKxaKuSZ7ZURpxAm
Q5dleLnN0ctb4IF1K9S4JIN2dmsT
-----END CERTIFICATE-----"


issuer17="thawte DSA SSL CA"
		issuer17Chain="-----BEGIN CERTIFICATE-----
MIIGJDCCBcmgAwIBAgIQbT3s+pt4qr0oAI3ZcDdjDjALBglghkgBZQMEAwIwga4x
CzAJBgNVBAYTAlVTMRUwEwYDVQQKEwx0aGF3dGUsIEluYy4xKDAmBgNVBAsTH0Nl
cnRpZmljYXRpb24gU2VydmljZXMgRGl2aXNpb24xODA2BgNVBAsTLyhjKSAyMDEy
IHRoYXd0ZSwgSW5jLiAtIEZvciBhdXRob3JpemVkIHVzZSBvbmx5MSQwIgYDVQQD
Ext0aGF3dGUgUHJpbWFyeSBSb290IENBIC0gRzQwHhcNMTIxMjIwMDAwMDAwWhcN
MjIxMjE5MjM1OTU5WjBAMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMdGhhd3RlLCBJ
bmMuMRowGAYDVQQDExF0aGF3dGUgRFNBIFNTTCBDQTCCA0gwggI6BgcqhkjOOAQB
MIICLQKCAQEAsOkfT0p9OXj0/j9H+m2Ejyu6VTLpjydK1/dWyl/AQS5WE5GPgy0i
6oJQCSEKLcZtJCcnrx9X2WJq/U9sxSydq0oP1R7BqXiRs3fphkJnBhW/OGJNnw13
dnBrt9ffmaZNFFRCUQOsGDsSjBPOUQ4tuenBeF3Zs+DAfkDXzxcrK4OQs6qTYubn
8QUphcoMaUURJv9aY8VfVpODN3Z5FeamrY72zAcGvc9ajFl45vVlK/dDbu8kMMdp
b1wuNMTWUo/dxdPrtgpJA3ZnN9MDSzs2tcGWxYnpWFZTndTePn7xU0b3r/pN/ys7
i5FBr1yqYVWelt5uGLMg+ZQ22GQnga8/eQIhAKdVID3cRKJNm0Rd77SM/GgY430w
mefDvxS6pQDGnAzXAoIBAQCLQiKLU8kRBsWIkeuRPKlbqwSMkbNwaOYK6/Lh8x5k
20djAqPOurHtzNWnAPAvZPYSjL+PR1ydHq4tRDEgjaVYlb5ZZeD8L6v0J/OWNTpS
SmeKzHfD1QRP/2dxqiNweivUR4vw7m6wg8Y5ZxOFKbgAfdM08z2hbjkucrCzkbCr
0NQUkUy+N4gvMKOIVDYVUiKUFSJmlRiYlCXJNaoIkKWcb4NjRBHjDKbmm4+Isco4
PUQ3E7V+CdS6C8hOPdDwhcYm6FPrgbTPcuuoJgEI6YXjgywGCMja6zwEmU1F9NH6
9TmpZiKCFDVhrBd5KgOemiiveAE2AAU1ctYz1pkqt2dXA4IBBgACggEBAJzaudYH
djJGC5gPXFS+oWZc4SEicF5teHo2ZkI86j8TDGZWBCXHng3m/JrY3qT11tBU4go/
XR5AQ9GYtLAiOXZKIdFSjyjrDGVotWNxpoZi1hXpVEsCAEwyWqKdO+47zUF2/tgc
QzAnAwbb2NV9D35rg3wKenUKdQfp98PrlWUh2UOmFkae83eLr/7VxEF4nOF+CI/4
Kx9y6Qy3So/OHucSp8206yqJ80EyYox9cnAeS81xBwJqn1LIPRFGJ85cEXRldATI
+CvgvfdnpWnJaPPUvJoaPF9DVfi4FTGV7aFfeQfi9QemF8WMPq0JpdrFkfrnGVw9
wxGzySeiXj7UDhKjggFCMIIBPjASBgNVHRMBAf8ECDAGAQH/AgEAMA4GA1UdDwEB
/wQEAwIBBjAyBggrBgEFBQcBAQQmMCQwIgYIKwYBBQUHMAGGFmh0dHA6Ly9vY3Nw
LnRoYXd0ZS5jb20wOwYDVR0gBDQwMjAwBgRVHSAAMCgwJgYIKwYBBQUHAgEWGmh0
dHBzOi8vd3d3LnRoYXd0ZS5jb20vY3BzMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6
Ly9jcmwudGhhd3RlLmNvbS9UaGF3dGVQQ0EtRzQuY3JsMC4GA1UdEQQnMCWkIzAh
MR8wHQYDVQQDExZTWU1DLURTQS1DQS0yMDQ4LTI1Ni00MB0GA1UdDgQWBBTKE7FN
7Jp+tnxFHrgd5NLIchqxHTAfBgNVHSMEGDAWgBTHZ4lkIvGdsfOLg6bCDpmTUXbr
ljALBglghkgBZQMEAwIDSAAwRQIhAKb8sDyC2UehqUcEPUQ65bnmmtiplEplDUZt
ULqZQweDAiAr4MAcnfC9otwLcBllGVA4vsOKPsFSq5u2EPn3ovIynw==
-----END CERTIFICATE-----"

issuer18="Symantec Class 3 ECC 256 bit SSL CA"
		issuer18Chain="-----BEGIN CERTIFICATE-----
MIID2DCCA1+gAwIBAgIQC7imBJfYHie79fJofRL9BDAKBggqhkjOPQQDAzCByjEL
MAkGA1UEBhMCVVMxFzAVBgNVBAoTDlZlcmlTaWduLCBJbmMuMR8wHQYDVQQLExZW
ZXJpU2lnbiBUcnVzdCBOZXR3b3JrMTowOAYDVQQLEzEoYykgMjAwNyBWZXJpU2ln
biwgSW5jLiAtIEZvciBhdXRob3JpemVkIHVzZSBvbmx5MUUwQwYDVQQDEzxWZXJp
U2lnbiBDbGFzcyAzIFB1YmxpYyBQcmltYXJ5IENlcnRpZmljYXRpb24gQXV0aG9y
aXR5IC0gRzQwHhcNMTIxMjIwMDAwMDAwWhcNMjIxMjE5MjM1OTU5WjB7MQswCQYD
VQQGEwJVUzEdMBsGA1UEChMUU3ltYW50ZWMgQ29ycG9yYXRpb24xHzAdBgNVBAsT
FlN5bWFudGVjIFRydXN0IE5ldHdvcmsxLDAqBgNVBAMTI1N5bWFudGVjIENsYXNz
IDMgRUNDIDI1NiBiaXQgU1NMIENBMFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE
uRNzQZVO1XDKSs2cdysdKYy/RCf46j9GQK8+SxDP1/M6zADL9/3r0G7CXaPQKjH/
sP4+2198bAdVm/Ja4gT9jaOCAXMwggFvMDcGCCsGAQUFBwEBBCswKTAnBggrBgEF
BQcwAYYbaHR0cDovL29jc3Aud3Muc3ltYW50ZWMuY29tMBIGA1UdEwEB/wQIMAYB
Af8CAQAwawYDVR0gBGQwYjBgBgpghkgBhvhFAQc2MFIwJgYIKwYBBQUHAgEWGmh0
dHA6Ly93d3cuc3ltYXV0aC5jb20vY3BzMCgGCCsGAQUFBwICMBwaGmh0dHA6Ly93
d3cuc3ltYXV0aC5jb20vcnBhMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwu
d3Muc3ltYW50ZWMuY29tL3BjYTMtZzQuY3JsMA4GA1UdDwEB/wQEAwIBBjAqBgNV
HREEIzAhpB8wHTEbMBkGA1UEAxMSU1lNQy1FQ0MtQ0EtcDI1Ni0yMB0GA1UdDgQW
BBR1cZ/95MUaSpibq/vBOqxN1M9vjDAfBgNVHSMEGDAWgBSzFpH97qZu5LUuSY+H
eIGA7OWxtTAKBggqhkjOPQQDAwNnADBkAjBX2/VYEe7Xlb/LnqFAkIs3KMU/jixK
eCclGN4skAuL1zTivRiiMYAkK+AvObUg5kECMHJTR6AofNOUwZrVorTapiXOMm+3
U8HFnSA9ObyWT3ush9ZitlaHmk+hgBcRfDs+sQ==
-----END CERTIFICATE-----"


issuer19="Symantec Class 3 ECC 256 bit Extended Validation CA"
		issuer19Chain="-----BEGIN CERTIFICATE-----
MIID4zCCA2qgAwIBAgIQTZVdIK+FxJ9pJfurfGZfiTAKBggqhkjOPQQDAzCByjEL
MAkGA1UEBhMCVVMxFzAVBgNVBAoTDlZlcmlTaWduLCBJbmMuMR8wHQYDVQQLExZW
ZXJpU2lnbiBUcnVzdCBOZXR3b3JrMTowOAYDVQQLEzEoYykgMjAwNyBWZXJpU2ln
biwgSW5jLiAtIEZvciBhdXRob3JpemVkIHVzZSBvbmx5MUUwQwYDVQQDEzxWZXJp
U2lnbiBDbGFzcyAzIFB1YmxpYyBQcmltYXJ5IENlcnRpZmljYXRpb24gQXV0aG9y
aXR5IC0gRzQwHhcNMTIxMjIwMDAwMDAwWhcNMjIxMjE5MjM1OTU5WjCBizELMAkG
A1UEBhMCVVMxHTAbBgNVBAoTFFN5bWFudGVjIENvcnBvcmF0aW9uMR8wHQYDVQQL
ExZTeW1hbnRlYyBUcnVzdCBOZXR3b3JrMTwwOgYDVQQDEzNTeW1hbnRlYyBDbGFz
cyAzIEVDQyAyNTYgYml0IEV4dGVuZGVkIFZhbGlkYXRpb24gQ0EwWTATBgcqhkjO
PQIBBggqhkjOPQMBBwNCAATdBD2y8pCTl8bpu7yR21Hwo4bt+8bThZMyBUngBINh
llH/VyGuC9oO5wShf9sqHL3KmDXFcXNAzehqq1SEQybio4IBbTCCAWkwEgYDVR0T
AQH/BAgwBgEB/wIBADA3BgNVHR8EMDAuMCygKqAohiZodHRwOi8vY3JsLndzLnN5
bWFudGVjLmNvbS9wY2EzLWc0LmNybDAOBgNVHQ8BAf8EBAMCAQYwNwYIKwYBBQUH
AQEEKzApMCcGCCsGAQUFBzABhhtodHRwOi8vb2NzcC53cy5zeW1hbnRlYy5jb20w
ZQYDVR0gBF4wXDBaBgRVHSAAMFIwJgYIKwYBBQUHAgEWGmh0dHA6Ly93d3cuc3lt
YXV0aC5jb20vY3BzMCgGCCsGAQUFBwICMBwaGmh0dHA6Ly93d3cuc3ltYXV0aC5j
b20vcnBhMCoGA1UdEQQjMCGkHzAdMRswGQYDVQQDExJTWU1DLUVDQy1DQS1wMjU2
LTMwHQYDVR0OBBYEFEgTZReU7J4WKip0XOhTLbT7g+uOMB8GA1UdIwQYMBaAFLMW
kf3upm7ktS5Jj4d4gYDs5bG1MAoGCCqGSM49BAMDA2cAMGQCMFyb7oOjdk2MLQVM
gjS6s77Oj+jDNIH7QHfoNGxbFys7rdWno9LzZsJPsrDIdpiPvwIwT8IvzpLFqb3O
fU7UGztmJOpOzYKvVEqI7+O/OpNjVCF9EjDSMs2ryYGwpxFDe0Vm
-----END CERTIFICATE-----"

#***************************************************************
# SHA 256 Intermediate Certificates with SHA 256 roots
#***************************************************************
issuer20="GeoTrust Extended Validation SHA256 SSL CA"
		issuer20Chain="-----BEGIN CERTIFICATE-----
MIID4zCCA2qgAwIBAgIQTZVdIK+FxJ9pJfurfGZfiTAKBggqhkjOPQQDAzCByjEL
MAkGA1UEBhMCVVMxFzAVBgNVBAoTDlZlcmlTaWduLCBJbmMuMR8wHQYDVQQLExZW
ZXJpU2lnbiBUcnVzdCBOZXR3b3JrMTowOAYDVQQLEzEoYykgMjAwNyBWZXJpU2ln
biwgSW5jLiAtIEZvciBhdXRob3JpemVkIHVzZSBvbmx5MUUwQwYDVQQDEzxWZXJp
U2lnbiBDbGFzcyAzIFB1YmxpYyBQcmltYXJ5IENlcnRpZmljYXRpb24gQXV0aG9y
aXR5IC0gRzQwHhcNMTIxMjIwMDAwMDAwWhcNMjIxMjE5MjM1OTU5WjCBizELMAkG
A1UEBhMCVVMxHTAbBgNVBAoTFFN5bWFudGVjIENvcnBvcmF0aW9uMR8wHQYDVQQL
ExZTeW1hbnRlYyBUcnVzdCBOZXR3b3JrMTwwOgYDVQQDEzNTeW1hbnRlYyBDbGFz
cyAzIEVDQyAyNTYgYml0IEV4dGVuZGVkIFZhbGlkYXRpb24gQ0EwWTATBgcqhkjO
PQIBBggqhkjOPQMBBwNCAATdBD2y8pCTl8bpu7yR21Hwo4bt+8bThZMyBUngBINh
llH/VyGuC9oO5wShf9sqHL3KmDXFcXNAzehqq1SEQybio4IBbTCCAWkwEgYDVR0T
AQH/BAgwBgEB/wIBADA3BgNVHR8EMDAuMCygKqAohiZodHRwOi8vY3JsLndzLnN5
bWFudGVjLmNvbS9wY2EzLWc0LmNybDAOBgNVHQ8BAf8EBAMCAQYwNwYIKwYBBQUH
AQEEKzApMCcGCCsGAQUFBzABhhtodHRwOi8vb2NzcC53cy5zeW1hbnRlYy5jb20w
ZQYDVR0gBF4wXDBaBgRVHSAAMFIwJgYIKwYBBQUHAgEWGmh0dHA6Ly93d3cuc3lt
YXV0aC5jb20vY3BzMCgGCCsGAQUFBwICMBwaGmh0dHA6Ly93d3cuc3ltYXV0aC5j
b20vcnBhMCoGA1UdEQQjMCGkHzAdMRswGQYDVQQDExJTWU1DLUVDQy1DQS1wMjU2
LTMwHQYDVR0OBBYEFEgTZReU7J4WKip0XOhTLbT7g+uOMB8GA1UdIwQYMBaAFLMW
kf3upm7ktS5Jj4d4gYDs5bG1MAoGCCqGSM49BAMDA2cAMGQCMFyb7oOjdk2MLQVM
gjS6s77Oj+jDNIH7QHfoNGxbFys7rdWno9LzZsJPsrDIdpiPvwIwT8IvzpLFqb3O
fU7UGztmJOpOzYKvVEqI7+O/OpNjVCF9EjDSMs2ryYGwpxFDe0Vm
-----END CERTIFICATE-----"

issuer21="GeoTrust SHA256 SSL CA"
		issuer21Chain="-----BEGIN CERTIFICATE-----
MIIExzCCA6+gAwIBAgIQQYISfRLZxrMhOUMSVmQAuDANBgkqhkiG9w0BAQsFADCB
mDELMAkGA1UEBhMCVVMxFjAUBgNVBAoTDUdlb1RydXN0IEluYy4xOTA3BgNVBAsT
MChjKSAyMDA4IEdlb1RydXN0IEluYy4gLSBGb3IgYXV0aG9yaXplZCB1c2Ugb25s
eTE2MDQGA1UEAxMtR2VvVHJ1c3QgUHJpbWFyeSBDZXJ0aWZpY2F0aW9uIEF1dGhv
cml0eSAtIEczMB4XDTEzMDUyMzAwMDAwMFoXDTIzMDUyMjIzNTk1OVowRjELMAkG
A1UEBhMCVVMxFjAUBgNVBAoTDUdlb1RydXN0IEluYy4xHzAdBgNVBAMTFkdlb1Ry
dXN0IFNIQTI1NiBTU0wgQ0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
AQDGqQtdF6V9xs8q78Zm0UIeX4N4aJGv5qeL8B1EAQoZypzUix3hoZCjwVu011tq
i/wOSR7CYin+gBU5i4EqJ7X7EqgFIgvFLPXZmN0WLztm52KiQzKsj7WFyFIGLFzA
d/pn94PoXgWNyKuhFjKK0kDshjocI6mNtQDecr2FVf4GAWBdrbPgZXOlkhSelFZv
k+6vqTowJUqOCYTvt9LV15tJzenAXmdxIqxQkEMgXaGjFYP9/Kc5vGtlSBJg/90j
szqq9J+cN1NBokeTgTMJ5SLGyBxJoW6NzIOzms3qQ/IZ0yTLqCmuUsz0CCewhOrO
J7XhNBNzklyHhirGsGg2rcsJAgMBAAGjggFcMIIBWDA7BggrBgEFBQcBAQQvMC0w
KwYIKwYBBQUHMAGGH2h0dHA6Ly9wY2EtZzMtb2NzcC5nZW90cnVzdC5jb20wEgYD
VR0TAQH/BAgwBgEB/wIBADBMBgNVHSAERTBDMEEGCmCGSAGG+EUBBzYwMzAxBggr
BgEFBQcCARYlaHR0cDovL3d3dy5nZW90cnVzdC5jb20vcmVzb3VyY2VzL2NwczA7
BgNVHR8ENDAyMDCgLqAshipodHRwOi8vY3JsLmdlb3RydXN0LmNvbS9HZW9UcnVz
dFBDQS1HMy5jcmwwDgYDVR0PAQH/BAQDAgEGMCoGA1UdEQQjMCGkHzAdMRswGQYD
VQQDExJWZXJpU2lnbk1QS0ktMi00MTYwHQYDVR0OBBYEFBRnju2DT9YenUAEDARG
oXA0sg9yMB8GA1UdIwQYMBaAFMR5yo6hTgMdHNxr2zFblD4/MH8tMA0GCSqGSIb3
DQEBCwUAA4IBAQAQEOryENYIRuLBjz42WcgrD/5N7OP4tlYxeCXUdvII3e8/zYsc
fqp//AuoI2RRs4fWCfoi+scKUejOuPYDcOAbWrmxspMREPmXBQcpbG1XJVTo+Wab
Dvvbn+6Wb2XLH9hVzjH6zwL00H9QZv8veZulwt/Wz8gVg5aEmLJG1F8TqD6nNJwF
ONrP1mmVqSaHdgHXslEPgWlGJhyZtoNY4ztYj9y0ccC5v0KcHAOe5Eao6rnBzfZb
qTyW+3mkM3Onnni5cNxydMQyyAAbye9I0/s6m/r+eppAaRzI2ig3C9OjuX6WzCso
w1Zsb+nbUrH6mvvnr7WXpiLDxaiTsQDJB7J9
-----END CERTIFICATE-----"

issuer22="Symantec Class 3 Extended Validation SHA256 SSL CA"
		issuer22Chain="-----BEGIN CERTIFICATE-----
MIIFSTCCBDGgAwIBAgIQCbdJ/X8LSRbKBVZWz/bZgjANBgkqhkiG9w0BAQsFADCB
vTELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDlZlcmlTaWduLCBJbmMuMR8wHQYDVQQL
ExZWZXJpU2lnbiBUcnVzdCBOZXR3b3JrMTowOAYDVQQLEzEoYykgMjAwOCBWZXJp
U2lnbiwgSW5jLiAtIEZvciBhdXRob3JpemVkIHVzZSBvbmx5MTgwNgYDVQQDEy9W
ZXJpU2lnbiBVbml2ZXJzYWwgUm9vdCBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eTAe
Fw0xMzA0MDkwMDAwMDBaFw0yMzA0MDgyMzU5NTlaMIGKMQswCQYDVQQGEwJVUzEd
MBsGA1UEChMUU3ltYW50ZWMgQ29ycG9yYXRpb24xHzAdBgNVBAsTFlN5bWFudGVj
IFRydXN0IE5ldHdvcmsxOzA5BgNVBAMTMlN5bWFudGVjIENsYXNzIDMgRXh0ZW5k
ZWQgVmFsaWRhdGlvbiBTSEEyNTYgU1NMIENBMIIBIjANBgkqhkiG9w0BAQEFAAOC
AQ8AMIIBCgKCAQEAwUo5gP1SVSC5FK9OwhPfSgNKsGXFaGaKJJxyi63peok7gyXs
LFcSKSb3qHD0Y+AGVTyD8cPxY0sypzk9D/exa/G+Xxua5KoXZUbBpue3YXWKmCYZ
HqcPo8eypoUnOQR0G8YHFiqSqOjpm8RaIIoby0YJUeSi5CGDM9UnyXvbqOF2hljp
4b0TV2vgGq9xA7MV8EQB5WFk9fIRmVLs7ej1PRNrISfCxgPA8g/VWH/17yql/yjq
jeWOdt8sZmSbNb9j/Z9KSJ8whT7VsvH+yESoWC6gnWC9Cs7BJQgcTfK0w+tcOLfY
1JslzuMzFs/JL8wocPpjdNXExxEVpZnyKSLABQIDAQABo4IBdDCCAXAwNwYIKwYB
BQUHAQEEKzApMCcGCCsGAQUFBzABhhtodHRwOi8vb2NzcC53cy5zeW1hbnRlYy5j
b20wEgYDVR0TAQH/BAgwBgEB/wIBADBlBgNVHSAEXjBcMFoGBFUdIAAwUjAmBggr
BgEFBQcCARYaaHR0cDovL3d3dy5zeW1hdXRoLmNvbS9jcHMwKAYIKwYBBQUHAgIw
HBoaaHR0cDovL3d3dy5zeW1hdXRoLmNvbS9ycGEwPgYDVR0fBDcwNTAzoDGgL4Yt
aHR0cDovL2NybC53cy5zeW1hbnRlYy5jb20vdW5pdmVyc2FsLXJvb3QuY3JsMA4G
A1UdDwEB/wQEAwIBBjAqBgNVHREEIzAhpB8wHTEbMBkGA1UEAxMSVmVyaVNpZ25N
UEtJLTItMzcyMB0GA1UdDgQWBBSybePkFA+MPHNCplqZGtMUdbaG2zAfBgNVHSME
GDAWgBS2d/ppSEefUxLVwuoHMnYH0ZcHGTANBgkqhkiG9w0BAQsFAAOCAQEAdJ3d
mGjc+GgcDYkNvwlH3cWvtjX7EqazxfQGSbmJcnB0fKn1cxQh6wAW9VOsKBq0salx
V6wBS/SYJMULRSKRRtL+1rYIRPMbgwUcFMBo34qHylbm72/zlBO0W4VPrVe68Ow7
gOeiAV+7ZYUARJc0uNiuIW+Xva9zHMVw3Mb3x2sgh6oEYmnI9sPzpHSPG1VPKrsH
NUZlCdqof2NXVfDrn0kVlVeqf8tER1EAWVaDHUCRLdgd0l9x7ibBbkUNxU0SP7+R
5TYnB2qysmYrhf8nQaKSs8pOAY371fbh5FTWa8ySae7kOY6dNM4Us/CAauNW7mW0
zB9UpGiJBN2YLL3Pow==
-----END CERTIFICATE-----"

issuer23="Symantec Class 3 Secure Server SHA256 SSL CA"
		issuer23Chain="-----BEGIN CERTIFICATE-----
MIIFSTCCBDGgAwIBAgIQaYeUGdnjYnB0nbvlncZoXjANBgkqhkiG9w0BAQsFADCB
vTELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDlZlcmlTaWduLCBJbmMuMR8wHQYDVQQL
ExZWZXJpU2lnbiBUcnVzdCBOZXR3b3JrMTowOAYDVQQLEzEoYykgMjAwOCBWZXJp
U2lnbiwgSW5jLiAtIEZvciBhdXRob3JpemVkIHVzZSBvbmx5MTgwNgYDVQQDEy9W
ZXJpU2lnbiBVbml2ZXJzYWwgUm9vdCBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eTAe
Fw0xMzA0MDkwMDAwMDBaFw0yMzA0MDgyMzU5NTlaMIGEMQswCQYDVQQGEwJVUzEd
MBsGA1UEChMUU3ltYW50ZWMgQ29ycG9yYXRpb24xHzAdBgNVBAsTFlN5bWFudGVj
IFRydXN0IE5ldHdvcmsxNTAzBgNVBAMTLFN5bWFudGVjIENsYXNzIDMgU2VjdXJl
IFNlcnZlciBTSEEyNTYgU1NMIENBMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIB
CgKCAQEAvjgWUYuA2+oOTezoP1zEfKJd7TuvpdaeEDUs48XlqN6Mhhcm5t4LUUos
0PvRFFpy98nduIMcxkaMMSWRDlkXo9ATjJLBr4FUTrxiAp6qpxpX2MqmmXpwVk+Y
By5LltBMOVO5YS87dnyOBZ6ZRNEDVHcpK1YqqmHkhC8SFTy914roCR5W8bUUrIqE
zq54omAKU34TTBpAcA5SWf9aaC5MRhM7OQmCeAI1SSAIgrOxbIkPbh41JbAsJIPj
xVAsukaQRYcNcv9dETjFkXbFLPsFKoKVoVlj49AmWM1nVjq633zS0jvY3hp6d+QM
jAvrK8IisL1Vutm5VdEiesYCTj/DNQIDAQABo4IBejCCAXYwEgYDVR0TAQH/BAgw
BgEB/wIBADA+BgNVHR8ENzA1MDOgMaAvhi1odHRwOi8vY3JsLndzLnN5bWFudGVj
LmNvbS91bml2ZXJzYWwtcm9vdC5jcmwwDgYDVR0PAQH/BAQDAgEGMDcGCCsGAQUF
BwEBBCswKTAnBggrBgEFBQcwAYYbaHR0cDovL29jc3Aud3Muc3ltYW50ZWMuY29t
MGsGA1UdIARkMGIwYAYKYIZIAYb4RQEHNjBSMCYGCCsGAQUFBwIBFhpodHRwOi8v
d3d3LnN5bWF1dGguY29tL2NwczAoBggrBgEFBQcCAjAcGhpodHRwOi8vd3d3LnN5
bWF1dGguY29tL3JwYTAqBgNVHREEIzAhpB8wHTEbMBkGA1UEAxMSVmVyaVNpZ25N
UEtJLTItMzczMB0GA1UdDgQWBBTbYiD7fQKJfNI7b8fkMmwFUh2tsTAfBgNVHSME
GDAWgBS2d/ppSEefUxLVwuoHMnYH0ZcHGTANBgkqhkiG9w0BAQsFAAOCAQEAGcyV
4i97SdBIkFP0B7EgRDVwFNVENzHv73DRLUzpLbBTkQFMVOd9m9o6/7fLFK0wD2ka
KvC8zTXrSNy5h/3PsVr2Bdo8ZOYr5txzXprYDJvSl7Po+oeVU+GZrYjo+rwJTaLE
ahsoOy3DIRXuFPqdmBDrnz7mJCRfehwFu5oxI1h5TOxtGBlNUR8IYb2RBQxanCb8
C6UgJb9qGyv3AglyaYMyFMNgW379mjL6tJUOGvk7CaRUR5oMzjKv0SHMf9IG72AO
Ym9vgRoXncjLKMziX24serTLR3x0aHtIcQKcIwnzWq5fQi5fK1ktUojljQuzqGH5
S5tV1tqxkju/w5v5LA==
-----END CERTIFICATE-----"

issuer24="thawte Extended Validation SHA256 SSL CA"
		issuer24Chain="-----BEGIN CERTIFICATE-----
MIIE0DCCA7igAwIBAgIQCkieiFN+iqZFTW4sSyrrIDANBgkqhkiG9w0BAQsFADCB
rjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDHRoYXd0ZSwgSW5jLjEoMCYGA1UECxMf
Q2VydGlmaWNhdGlvbiBTZXJ2aWNlcyBEaXZpc2lvbjE4MDYGA1UECxMvKGMpIDIw
MDggdGhhd3RlLCBJbmMuIC0gRm9yIGF1dGhvcml6ZWQgdXNlIG9ubHkxJDAiBgNV
BAMTG3RoYXd0ZSBQcmltYXJ5IFJvb3QgQ0EgLSBHMzAeFw0xMzA0MDkwMDAwMDBa
Fw0yMzA0MDgyMzU5NTlaMFcxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwx0aGF3dGUs
IEluYy4xMTAvBgNVBAMTKHRoYXd0ZSBFeHRlbmRlZCBWYWxpZGF0aW9uIFNIQTI1
NiBTU0wgQ0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDyxLx06CX2
AGIo40zouN8Tn4sHN+9iSvFXCfaC6HXwCqknz5M77DaJpW4d1lTzuASXcrRpJczR
Qg5b1Rx/omBusVIa25MvuwsNZFMWyxwJJJUpIrSKGACJ/vcfcsjoXC8aG6IYuO8Y
XMu12zpO2w+u38R54x6qXKOk5axhmzeFj0h1G7nVaJbpJ3lwVyMau2yTkMdF1xfS
Nyp2s82CqU/AA3vhPXp+W7iF8vUV+3CpvfVQZRad47ZrYW6hep7oDRz3Ko5pfkMw
jnjO7mUeO5uHHkkc+DJGXShGeSpOJ10XWKg3/qgTqWkV3zYiiXW6ygFALu2d1wyq
Mc4nrlfV0lH7AgMBAAGjggE+MIIBOjASBgNVHRMBAf8ECDAGAQH/AgEAMA4GA1Ud
DwEB/wQEAwIBBjAyBggrBgEFBQcBAQQmMCQwIgYIKwYBBQUHMAGGFmh0dHA6Ly9v
Y3NwLnRoYXd0ZS5jb20wOwYDVR0gBDQwMjAwBgRVHSAAMCgwJgYIKwYBBQUHAgEW
Gmh0dHBzOi8vd3d3LnRoYXd0ZS5jb20vY3BzMDcGA1UdHwQwMC4wLKAqoCiGJmh0
dHA6Ly9jcmwudGhhd3RlLmNvbS9UaGF3dGVQQ0EtRzMuY3JsMCoGA1UdEQQjMCGk
HzAdMRswGQYDVQQDExJWZXJpU2lnbk1QS0ktMi0zNzQwHQYDVR0OBBYEFDskyDGg
t1rQarjSygd0zB4k1MTcMB8GA1UdIwQYMBaAFK1sqpRgnO3k//o+CnQrYwP3tlm/
MA0GCSqGSIb3DQEBCwUAA4IBAQBomCaq1DPJunVw1J9JrdbBVNzuqlYfeKfwoaTu
C/kSr9+muO7DyzUTalkq+MnpTC+8sbwrwgIw4cO+wvCBjJl3iVgAo8x/owJMU7Ju
Nk/+34d2sz/sWmJQtgBFWPKHrHfm0CBQY8XksnAVGJAFe3uvK0a+a04fU/yEJ66D
0o1HU6cOH2O1utsW2GoJJVV9jz1KwYP5s7mnBFrI8xEEkVMw2VKHyzkAnOxTwwIJ
fqc2jnIhLyO7TMZHpaHuZ8QvXDpHOGHiwx43kp7IL2v679LDzSmNmPhSF+21Uzzf
r8kbYq3fAu5dNPZBS8vDVa+xy9qcc9UCqC2nrPzh5QfQUeg1
-----END CERTIFICATE-----"

issuer25="thawte SHA256 SSL CA"
		issuer25Chain="-----BEGIN CERTIFICATE-----
MIIEwjCCA6qgAwIBAgIQNjSeGMmcJmm2Vi5s5a1xMjANBgkqhkiG9w0BAQsFADCB
rjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDHRoYXd0ZSwgSW5jLjEoMCYGA1UECxMf
Q2VydGlmaWNhdGlvbiBTZXJ2aWNlcyBEaXZpc2lvbjE4MDYGA1UECxMvKGMpIDIw
MDggdGhhd3RlLCBJbmMuIC0gRm9yIGF1dGhvcml6ZWQgdXNlIG9ubHkxJDAiBgNV
BAMTG3RoYXd0ZSBQcmltYXJ5IFJvb3QgQ0EgLSBHMzAeFw0xMzA1MjMwMDAwMDBa
Fw0yMzA1MjIyMzU5NTlaMEMxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwx0aGF3dGUs
IEluYy4xHTAbBgNVBAMTFHRoYXd0ZSBTSEEyNTYgU1NMIENBMIIBIjANBgkqhkiG
9w0BAQEFAAOCAQ8AMIIBCgKCAQEAo2Mr1LpdOK6wz7lMON8gffErR3Edi2jzVvmc
2qrlhCbepXEwvPMxI53oO4DIZld1tlcO25P1Jo5wumRSZooqiFxEGE2oony9VmEy
kBL5NYdIYLBukGdEAY3nyQ1jaHJyq2M8hrgffa2IJadqiCn7WcZ4cV8suonm04D9
V+y5UV9DMy5+JTukBNFgjLNEM5MMrSq2RKIZO6/EkG97BYeGmyxqnStsd8kAn8nP
rO0+G/fD89n4bNSgV8T7KDKqM/Dmupjf5cJOnHS/ikjC8hvwd0BBBwSyOtVMxCmp
EUA/AkbwkdXSgYOGE7Mx7UarqId2qZl9vM0xUPSltdylMrOLiwIDAQABo4IBRDCC
AUAwMgYIKwYBBQUHAQEEJjAkMCIGCCsGAQUFBzABhhZodHRwOi8vb2NzcC50aGF3
dGUuY29tMBIGA1UdEwEB/wQIMAYBAf8CAQAwQQYDVR0gBDowODA2BgpghkgBhvhF
AQc2MCgwJgYIKwYBBQUHAgEWGmh0dHBzOi8vd3d3LnRoYXd0ZS5jb20vY3BzMDcG
A1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwudGhhd3RlLmNvbS9UaGF3dGVQQ0Et
RzMuY3JsMA4GA1UdDwEB/wQEAwIBBjAqBgNVHREEIzAhpB8wHTEbMBkGA1UEAxMS
VmVyaVNpZ25NUEtJLTItNDE1MB0GA1UdDgQWBBQrmjWuARg4MOFwegXgEXajzr2Q
FDAfBgNVHSMEGDAWgBStbKqUYJzt5P/6Pgp0K2MD97ZZvzANBgkqhkiG9w0BAQsF
AAOCAQEAdKZW6K+Tlhn7JvkNsESlzel6SAN0AWwTcbfggpCZYiPj1pmv8McenqgY
Idu0lD80VhuZVS+O8EUzMrdywRNbNNP1YOUuGNFcxWrBqodQDBydZCv/G9zVLmEL
57m2kVOG2QMq0T17StorB74p8mBCqZEaDi480X2lExQC+u6LjbbIuD5WgVchJD9l
w7TJzlyNRqxT8/lVdMgr/dJ4cPX4EeX0p60g9Z3x7HD2E6zmjI3bP8byeQ6rUvLM
G3knzxaz1vPGNoBD7MWU8N2QjfjGUkZW63RHvqbzGa5xTMDh59TP7dQGKCoRPLrZ
QW4A54E3k+TaYsYdZ29jtBSG2aZi8A==
-----END CERTIFICATE-----"


issuer26="thawte DV SSL SHA256 CA"
		issuer26Chain="-----BEGIN CERTIFICATE-----
MIIE3DCCA8SgAwIBAgIQPiM0Wu0sClF7Jt7UgB0QqjANBgkqhkiG9w0BAQsFADCB
rjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDHRoYXd0ZSwgSW5jLjEoMCYGA1UECxMf
Q2VydGlmaWNhdGlvbiBTZXJ2aWNlcyBEaXZpc2lvbjE4MDYGA1UECxMvKGMpIDIw
MDggdGhhd3RlLCBJbmMuIC0gRm9yIGF1dGhvcml6ZWQgdXNlIG9ubHkxJDAiBgNV
BAMTG3RoYXd0ZSBQcmltYXJ5IFJvb3QgQ0EgLSBHMzAeFw0xNDA2MTAwMDAwMDBa
Fw0yNDA2MDkyMzU5NTlaMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwx0aGF3dGUs
IEluYy4xHTAbBgNVBAsTFERvbWFpbiBWYWxpZGF0ZWQgU1NMMSAwHgYDVQQDExd0
aGF3dGUgRFYgU1NMIFNIQTI1NiBDQTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCC
AQoCggEBALOsDX+tuxNNlF9nQmrQiXGp7XQEkyTITVah8JGWhNmEas9SIeMasVRM
5saenks4qZZUHfWz7ZIE0G5UkG4v6X2YtIotEqO0Qkcdf19A4fx/kaYB3FWkUHgq
Yz+EfizIKyG2xg5evLix1BuYs8b44ego7TJEG8t/9+SxEevGCLBb7qjC7Eaqjynf
ubekA6A1elg/iylHwdIi+izGx2zN0/dYMpOU0W+pKpwPCiiSqxQKtt/tQHpkB1TO
6nWXMrmWoHXJdzECdK9Ud0+ZooFLeVm4kj/5B+pCdFcuNexVivxhPD5XcZI7q+TB
4RcsZDYAhLV8Gn2wQTN8I/ZOd1oswUsCAwEAAaOCATwwggE4MC4GCCsGAQUFBwEB
BCIwIDAeBggrBgEFBQcwAYYSaHR0cDovL3Quc3ltY2QuY29tMBIGA1UdEwEB/wQI
MAYBAf8CAQAwQQYDVR0gBDowODA2BgpghkgBhvhFAQc2MCgwJgYIKwYBBQUHAgEW
Gmh0dHBzOi8vd3d3LnRoYXd0ZS5jb20vY3BzMDQGA1UdHwQtMCswKaAnoCWGI2h0
dHA6Ly90LnN5bWNiLmNvbS9UaGF3dGVQQ0EtRzMuY3JsMA4GA1UdDwEB/wQEAwIB
BjApBgNVHREEIjAgpB4wHDEaMBgGA1UEAxMRU3ltYW50ZWNQS0ktMS02OTUwHQYD
VR0OBBYEFH0pMS/BHm6uMQVqs+sczandroCaMB8GA1UdIwQYMBaAFK1sqpRgnO3k
//o+CnQrYwP3tlm/MA0GCSqGSIb3DQEBCwUAA4IBAQA2/6LxHH65UXuU01p7SCXT
N6KCKi1fOB6HZ+zJMavXkjO4vTXKsYBwBIJ8iMw3LhZ0bpNAY8qNe/8HKOb5M6vw
YY09yoPFUNi9aTkfrry37hXFjQQGIDMoBJnFnBH1AQ9HXtiJmaXOwoD+Rvrvthuo
kbKDs+JXDRrkltW8971tA/hifuv4Qgn+CWSkyVy40jkLeQKeFTkdwNnNHF9odo3z
Hi36v6dJog2X9ZbC6WzUzUcLi4oBi9v6z5J1Lt4+p3O1/gNRp0LDx0JrqW++9iDh
jr+fCY7lCOiSk3c+SUScf+l5nf9Lr+A4VzQNXxEyEpKpYYiBpR74oPBFWoZxIIWF
-----END CERTIFICATE-----"


#***************************************************************
# SHA 256 Intermediate Certificates with SHA 1 roots
#***************************************************************

issuer27="GeoTrust EV SSL CA - G4"
		issuer27Chain="-----BEGIN CERTIFICATE-----
MIIEbjCCA1agAwIBAgIQboqQ68/wRIpyDQgF0IKlRDANBgkqhkiG9w0BAQsFADBY
MQswCQYDVQQGEwJVUzEWMBQGA1UEChMNR2VvVHJ1c3QgSW5jLjExMC8GA1UEAxMo
R2VvVHJ1c3QgUHJpbWFyeSBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eTAeFw0xMzEw
MzEwMDAwMDBaFw0yMzEwMzAyMzU5NTlaMEcxCzAJBgNVBAYTAlVTMRYwFAYDVQQK
Ew1HZW9UcnVzdCBJbmMuMSAwHgYDVQQDExdHZW9UcnVzdCBFViBTU0wgQ0EgLSBH
NDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBANm0BfI4Zw8J53z1Yyrl
uV6oEa51cdlMhGetiV38KD0qsKXV1OYwCoTU5BjLhTfFRnHrHHtp22VpjDAFPgfh
bzzBC2HmOET8vIwvTnVX9ZaZfD6HHw+QS3DDPzlFOzpry7t7QFTRi0uhctIE6eBy
GpMRei/xq52cmFiuLOp3Xy8uh6+4a+Pi4j/WPeCWRN8RVWNSL/QmeMQPIE0KwGhw
FYY47rd2iKsYj081HtSMydt+PUTUNozBN7VZW4f56fHUxSi9HdzMlnLReqGnILW4
r/hupWB7K40f7vQr1mnNr8qAWCnoTAAgikkKbo6MqNEAEoS2xeKVosA7pGvwgtCW
XSUCAwEAAaOCAUMwggE/MBIGA1UdEwEB/wQIMAYBAf8CAQAwDgYDVR0PAQH/BAQD
AgEGMC8GCCsGAQUFBwEBBCMwITAfBggrBgEFBQcwAYYTaHR0cDovL2cyLnN5bWNi
LmNvbTBHBgNVHSAEQDA+MDwGBFUdIAAwNDAyBggrBgEFBQcCARYmaHR0cHM6Ly93
d3cuZ2VvdHJ1c3QuY29tL3Jlc291cmNlcy9jcHMwNAYDVR0fBC0wKzApoCegJYYj
aHR0cDovL2cxLnN5bWNiLmNvbS9HZW9UcnVzdFBDQS5jcmwwKQYDVR0RBCIwIKQe
MBwxGjAYBgNVBAMTEVN5bWFudGVjUEtJLTEtNTM4MB0GA1UdDgQWBBTez1xQt64C
HxUXqhboDbUonWpa8zAfBgNVHSMEGDAWgBQs1VBBlxWL8I82YVtK+2vZmckzkjAN
BgkqhkiG9w0BAQsFAAOCAQEAtI69B7mahew7Z70HYGHmhNHU7+sbuguCS5VktmZT
I723hN3ke40J2s+y9fHDv4eEvk6mqMLnEjkoNOCkVkRADJ+IoxXT6NNe4xwEYPtp
Nk9qfgwqKMHzqlgObM4dB8NKwJyNw3SxroLwGuH5Tim9Rt63Hfl929kPhMuSRcwc
sxj2oM9xbwwum9Its5mTg0SsFaqbLmfsT4hpBVZ7i7JDqTpsHBMzJRv9qMhXAvsc
4NG9O1ZEZcNj9Rvv7DDZ424uE+k5CCoMcvOazPYnKYTT70zHhBFlH8bjgQPbh8x4
97Wdlj5qf7wRhXp15kF9Dc/55YVpJY/HjQct+GkPy0FTAA==
-----END CERTIFICATE-----"

issuer28="GeoTrust SSL CA - G3"
		issuer28Chain="-----BEGIN CERTIFICATE-----
MIIETzCCAzegAwIBAgIDAjpvMA0GCSqGSIb3DQEBCwUAMEIxCzAJBgNVBAYTAlVT
MRYwFAYDVQQKEw1HZW9UcnVzdCBJbmMuMRswGQYDVQQDExJHZW9UcnVzdCBHbG9i
YWwgQ0EwHhcNMTMxMTA1MjEzNjUwWhcNMjIwNTIwMjEzNjUwWjBEMQswCQYDVQQG
EwJVUzEWMBQGA1UEChMNR2VvVHJ1c3QgSW5jLjEdMBsGA1UEAxMUR2VvVHJ1c3Qg
U1NMIENBIC0gRzMwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDjvn4K
hqPPa209K6GXrUkkTdd3uTR5CKWeop7eRxKSPX7qGYax6E89X/fQp3eaWx8KA7UZ
U9ulIZRpY51qTJEMEEe+EfpshiW3qwRoQjgJZfAU2hme+msLq2LvjafvY3AjqK+B
89FuiGdT7BKkKXWKp/JXPaKDmJfyCn3U50NuMHhiIllZuHEnRaoPZsZVP/oyFysx
j0ag+mkUfJ2fWuLrM04QprPtd2PYw5703d95mnrU7t7dmszDt6ldzBE6B7tvl6QB
I0eVH6N3+liSxsfQvc+TGEK3fveeZerVO8rtrMVwof7UEJrwEgRErBpbeFBFV0xv
vYDLgVwts7x2oR5lAgMBAAGjggFKMIIBRjAfBgNVHSMEGDAWgBTAephojYn7qwVk
DBF9qn1luMrMTjAdBgNVHQ4EFgQU0m/3lvSFP3I8MH0j2oV4m6N8WnwwEgYDVR0T
AQH/BAgwBgEB/wIBADAOBgNVHQ8BAf8EBAMCAQYwNgYDVR0fBC8wLTAroCmgJ4Yl
aHR0cDovL2cxLnN5bWNiLmNvbS9jcmxzL2d0Z2xvYmFsLmNybDAvBggrBgEFBQcB
AQQjMCEwHwYIKwYBBQUHMAGGE2h0dHA6Ly9nMi5zeW1jYi5jb20wTAYDVR0gBEUw
QzBBBgpghkgBhvhFAQc2MDMwMQYIKwYBBQUHAgEWJWh0dHA6Ly93d3cuZ2VvdHJ1
c3QuY29tL3Jlc291cmNlcy9jcHMwKQYDVR0RBCIwIKQeMBwxGjAYBgNVBAMTEVN5
bWFudGVjUEtJLTEtNTM5MA0GCSqGSIb3DQEBCwUAA4IBAQCg1Pcs+3QLf2TxzUNq
n2JTHAJ8mJCi7k9o1CAacxI+d7NQ63K87oi+fxfqd4+DYZVPhKHLMk9sIb7SaZZ9
Y73cK6gf0BOEcP72NZWJ+aZ3sEbIu7cT9clgadZM/tKO79NgwYCA4ef7i28heUrg
3Kkbwbf7w0lZXLV3B0TUl/xJAIlvBk4BcBmsLxHA4uYPL4ZLjXvDuacu9PGsFj45
SVGeF0tPEDpbpaiSb/361gsDTUdWVxnzy2v189bPsPX1oxHSIFMTNDcFLENaY9+N
QNaFHlHpURceA1bJ8TCt55sRornQMYGbaLHZ6PPmlH7HrhMvh+3QJbBo+d4IWvMp
zNSS
-----END CERTIFICATE-----"

issuer29="Symantec Class 3 EV SSL CA - G3"
		issuer29Chain="-----BEGIN CERTIFICATE-----
MIIFKzCCBBOgAwIBAgIQfuFKb2/v8tN/P61lTTratDANBgkqhkiG9w0BAQsFADCB
yjELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDlZlcmlTaWduLCBJbmMuMR8wHQYDVQQL
ExZWZXJpU2lnbiBUcnVzdCBOZXR3b3JrMTowOAYDVQQLEzEoYykgMjAwNiBWZXJp
U2lnbiwgSW5jLiAtIEZvciBhdXRob3JpemVkIHVzZSBvbmx5MUUwQwYDVQQDEzxW
ZXJpU2lnbiBDbGFzcyAzIFB1YmxpYyBQcmltYXJ5IENlcnRpZmljYXRpb24gQXV0
aG9yaXR5IC0gRzUwHhcNMTMxMDMxMDAwMDAwWhcNMjMxMDMwMjM1OTU5WjB3MQsw
CQYDVQQGEwJVUzEdMBsGA1UEChMUU3ltYW50ZWMgQ29ycG9yYXRpb24xHzAdBgNV
BAsTFlN5bWFudGVjIFRydXN0IE5ldHdvcmsxKDAmBgNVBAMTH1N5bWFudGVjIENs
YXNzIDMgRVYgU1NMIENBIC0gRzMwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEK
AoIBAQDYoWV0I+grZOIy1zM3PY71NBZI3U9/hxz4RCMTjvsR2ERaGHGOYBYmkpv9
FwvhcXBC/r/6HMCqo6e1cej/GIP23xAKE2LIPZyn3i4/DNkd5y77Ks7Imn+Hv9hM
BBUyydHMlXGgTihPhNk1++OGb5RT5nKKY2cuvmn2926OnGAE6yn6xEdC0niY4+wL
pZLct5q9gGQrOHw4CVtm9i2VeoayNC6FnpAOX7ddpFFyRnATv2fytqdNFB5suVPu
IxpOjUhVQ0GxiXVqQCjFfd3SbtICGS97JJRL6/EaqZvjI5rq+jOrCiy39GAI3Z8c
zd0tAWaAr7MvKR0juIrhoXAHDDQPAgMBAAGjggFdMIIBWTAvBggrBgEFBQcBAQQj
MCEwHwYIKwYBBQUHMAGGE2h0dHA6Ly9zMi5zeW1jYi5jb20wEgYDVR0TAQH/BAgw
BgEB/wIBADBlBgNVHSAEXjBcMFoGBFUdIAAwUjAmBggrBgEFBQcCARYaaHR0cDov
L3d3dy5zeW1hdXRoLmNvbS9jcHMwKAYIKwYBBQUHAgIwHBoaaHR0cDovL3d3dy5z
eW1hdXRoLmNvbS9ycGEwMAYDVR0fBCkwJzAloCOgIYYfaHR0cDovL3MxLnN5bWNi
LmNvbS9wY2EzLWc1LmNybDAOBgNVHQ8BAf8EBAMCAQYwKQYDVR0RBCIwIKQeMBwx
GjAYBgNVBAMTEVN5bWFudGVjUEtJLTEtNTMzMB0GA1UdDgQWBBQBWavn3ToLWaZk
Y9bPIAdX1ZHnajAfBgNVHSMEGDAWgBR/02Wnwt3su/AwCfNDOfoCrzMxMzANBgkq
hkiG9w0BAQsFAAOCAQEAQgFVe9AWGl1Y6LubqE3X89frE5SG1n8hC0e8V5uSXU8F
nzikEHzPg74GQ0aNCLxq1xCm+quvL2GoY/Jl339MiBKIT7Np2f8nwAqXkY9W+4nE
qLuSLRtzsMarNvSWbCAI7woeZiRFT2cAQMgHVHQzO6atuyOfZu2iRHA0+w7qAf3P
eHTfp61Vt19N9tY/4IbOJMdCqRMURDVLtt/JYKwMf9mTIUvunORJApjTYHtcvNUw
LwfORELEC5n+5p/8sHiGUW3RLJ3GlvuFgrsEL/digO9i2n/2DqyQuFa9eT/ygG6j
2bkPXToHHZGThkspTOHcteHgM52zyzaRS/6htO7w+Q==
-----END CERTIFICATE-----"

issuer30="Symantec Class 3 Secure Server CA - G4"
		issuer30Chain="-----BEGIN CERTIFICATE-----
MIIFODCCBCCgAwIBAgIQUT+5dDhwtzRAQY0wkwaZ/zANBgkqhkiG9w0BAQsFADCB
yjELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDlZlcmlTaWduLCBJbmMuMR8wHQYDVQQL
ExZWZXJpU2lnbiBUcnVzdCBOZXR3b3JrMTowOAYDVQQLEzEoYykgMjAwNiBWZXJp
U2lnbiwgSW5jLiAtIEZvciBhdXRob3JpemVkIHVzZSBvbmx5MUUwQwYDVQQDEzxW
ZXJpU2lnbiBDbGFzcyAzIFB1YmxpYyBQcmltYXJ5IENlcnRpZmljYXRpb24gQXV0
aG9yaXR5IC0gRzUwHhcNMTMxMDMxMDAwMDAwWhcNMjMxMDMwMjM1OTU5WjB+MQsw
CQYDVQQGEwJVUzEdMBsGA1UEChMUU3ltYW50ZWMgQ29ycG9yYXRpb24xHzAdBgNV
BAsTFlN5bWFudGVjIFRydXN0IE5ldHdvcmsxLzAtBgNVBAMTJlN5bWFudGVjIENs
YXNzIDMgU2VjdXJlIFNlcnZlciBDQSAtIEc0MIIBIjANBgkqhkiG9w0BAQEFAAOC
AQ8AMIIBCgKCAQEAstgFyhx0LbUXVjnFSlIJluhL2AzxaJ+aQihiw6UwU35VEYJb
A3oNL+F5BMm0lncZgQGUWfm893qZJ4Itt4PdWid/sgN6nFMl6UgfRk/InSn4vnlW
9vf92Tpo2otLgjNBEsPIPMzWlnqEIRoiBAMnF4scaGGTDw5RgDMdtLXO637QYqzu
s3sBdO9pNevK1T2p7peYyo2qRA4lmUoVlqTObQJUHypqJuIGOmNIrLRM0XWTUP8T
L9ba4cYY9Z/JJV3zADreJk20KQnNDz0jbxZKgRb78oMQw7jW2FUyPfG9D72MUpVK
Fpd6UiFjdS8W+cRmvvW1Cdj/JwDNRHxvSz+w9wIDAQABo4IBYzCCAV8wEgYDVR0T
AQH/BAgwBgEB/wIBADAwBgNVHR8EKTAnMCWgI6Ahhh9odHRwOi8vczEuc3ltY2Iu
Y29tL3BjYTMtZzUuY3JsMA4GA1UdDwEB/wQEAwIBBjAvBggrBgEFBQcBAQQjMCEw
HwYIKwYBBQUHMAGGE2h0dHA6Ly9zMi5zeW1jYi5jb20wawYDVR0gBGQwYjBgBgpg
hkgBhvhFAQc2MFIwJgYIKwYBBQUHAgEWGmh0dHA6Ly93d3cuc3ltYXV0aC5jb20v
Y3BzMCgGCCsGAQUFBwICMBwaGmh0dHA6Ly93d3cuc3ltYXV0aC5jb20vcnBhMCkG
A1UdEQQiMCCkHjAcMRowGAYDVQQDExFTeW1hbnRlY1BLSS0xLTUzNDAdBgNVHQ4E
FgQUX2DPYZBV34RDFIpgKrL1evRDGO8wHwYDVR0jBBgwFoAUf9Nlp8Ld7LvwMAnz
Qzn6Aq8zMTMwDQYJKoZIhvcNAQELBQADggEBAF6UVkndji1l9cE2UbYD49qecxny
H1mrWH5sJgUs+oHXXCMXIiw3k/eG7IXmsKP9H+IyqEVv4dn7ua/ScKAyQmW/hP4W
Ko8/xabWo5N9Q+l0IZE1KPRj6S7t9/Vcf0uatSDpCr3gRRAMFJSaXaXjS5HoJJtG
QGX0InLNmfiIEfXzf+YzguaoxX7+0AjiJVgIcWjmzaLmFN5OUiQt/eV5E1PnXi8t
TRttQBVSK/eHiXgSgW7ZTaoteNTCLD0IX4eRnh8OsN4wUmSGiaqdZpwOdgyA8nTY
Kvi4Os7X1g8RvmurFPW9QaAiY4nxug9vKWNmLT+sjHLF+8fk1A/yO0+MKcc=
-----END CERTIFICATE-----"

issuer31="thawte EV SSL CA - G3"
		issuer31Chain="-----BEGIN CERTIFICATE-----
MIIErzCCA5egAwIBAgIQXXL7M3Yg9kxygNvpEoH/ajANBgkqhkiG9w0BAQsFADCB
qTELMAkGA1UEBhMCVVMxFTATBgNVBAoTDHRoYXd0ZSwgSW5jLjEoMCYGA1UECxMf
Q2VydGlmaWNhdGlvbiBTZXJ2aWNlcyBEaXZpc2lvbjE4MDYGA1UECxMvKGMpIDIw
MDYgdGhhd3RlLCBJbmMuIC0gRm9yIGF1dGhvcml6ZWQgdXNlIG9ubHkxHzAdBgNV
BAMTFnRoYXd0ZSBQcmltYXJ5IFJvb3QgQ0EwHhcNMTMxMDMxMDAwMDAwWhcNMjMx
MDMwMjM1OTU5WjBEMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMdGhhd3RlLCBJbmMu
MR4wHAYDVQQDExV0aGF3dGUgRVYgU1NMIENBIC0gRzMwggEiMA0GCSqGSIb3DQEB
AQUAA4IBDwAwggEKAoIBAQDE3dqUHjKyLqCDwKZ9X2Ut/Se4cw74C6nUViZpmGc1
OWRYzoJvmJTRj+CQ1u1VS5hL1xBZNAIb51ExUcQ4wrzbA1zK4XzcT1mX6gd/D4U+
kuqqp9m+AUHkYlZHNr1XkeYh0/hBC9i66O2BrXDAi27ziW4nnqamc1m7cQDUT0tI
6dXJJzacfBwCqqy9O9FTg2of5ghHM6exnwK+m0ftMwTcHIAn0UozoIzrAUehMpBk
e8TghMky6d00H4poZ/OtEGPr7oqasSobJnShKrCP/lKYRpfPo1Ycb26Zl40mDqns
wlNw/HqlGUm9tReCVd6X4F1ihIHwcKg0U08U/T1dPW+5AgMBAAGjggE1MIIBMTAS
BgNVHRMBAf8ECDAGAQH/AgEAMA4GA1UdDwEB/wQEAwIBBjAvBggrBgEFBQcBAQQj
MCEwHwYIKwYBBQUHMAGGE2h0dHA6Ly90Mi5zeW1jYi5jb20wOwYDVR0gBDQwMjAw
BgRVHSAAMCgwJgYIKwYBBQUHAgEWGmh0dHBzOi8vd3d3LnRoYXd0ZS5jb20vY3Bz
MDIGA1UdHwQrMCkwJ6AloCOGIWh0dHA6Ly90MS5zeW1jYi5jb20vVGhhd3RlUENB
LmNybDApBgNVHREEIjAgpB4wHDEaMBgGA1UEAxMRU3ltYW50ZWNQS0ktMS01MzYw
HQYDVR0OBBYEFPBwUdrTKpFPUnfXhnd0D85xGmwiMB8GA1UdIwQYMBaAFHtbRc+v
zst6/TGSGmq280brV0hQMA0GCSqGSIb3DQEBCwUAA4IBAQChLpQ+mxb0WBpvwfrB
fkOTssP3iesTYl3dzGETKx1OiHkRYhQ3MEb/iWIQhSqHHvjir/6TApPK8ulGA2uh
GqzV8IAbmG+4OlD4VHEGA+eEzI5h0l9NDJcCZbWMJrwFmPTcxq/kV3/j3KHXJ0cq
4Cw/CXTcWuW1fPqCmhX6dCuELmus7zWmMPpHSqo2RPZakQfT5E6XP6ZT2CkzMm+L
PbWlDeXkiuj1wPqv2DcoJ8PtNDHZfKavTRJP0CuSnGmV8iim/qjG4CxNNusRNNbh
gZmdQfLnxVcFDhnKr0I5H6cnXuAKF7iuR6uS8YoE3zDgu0+K+RuITwO0JXp43i59
KdEx
-----END CERTIFICATE-----"

issuer32="thawte SSL CA - G2"
		issuer32Chain="-----BEGIN CERTIFICATE-----
MIIEsjCCA5qgAwIBAgIQFofWiG3iMAaFIz2/Eb9llzANBgkqhkiG9w0BAQsFADCB
qTELMAkGA1UEBhMCVVMxFTATBgNVBAoTDHRoYXd0ZSwgSW5jLjEoMCYGA1UECxMf
Q2VydGlmaWNhdGlvbiBTZXJ2aWNlcyBEaXZpc2lvbjE4MDYGA1UECxMvKGMpIDIw
MDYgdGhhd3RlLCBJbmMuIC0gRm9yIGF1dGhvcml6ZWQgdXNlIG9ubHkxHzAdBgNV
BAMTFnRoYXd0ZSBQcmltYXJ5IFJvb3QgQ0EwHhcNMTMxMDMxMDAwMDAwWhcNMjMx
MDMwMjM1OTU5WjBBMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMdGhhd3RlLCBJbmMu
MRswGQYDVQQDExJ0aGF3dGUgU1NMIENBIC0gRzIwggEiMA0GCSqGSIb3DQEBAQUA
A4IBDwAwggEKAoIBAQCy/Ab7BJPS6lkgO0SFl1I55xDweuCwlEDaRvgMKLu5zmA4
P9LYEUIbka1J7o/H3mzeN2/9iyA8bed009zVJIhBgInuNr7E1b6NUxOq5KW4kwq+
7NrNPNQyVu/QTqC4l7s5UB5uZcP9ss7gWalICcb+vq78PjuBIJeLj0bfYGQHdbsb
hjifR3s0zqHRl6122J+3Jtt5gDZI8sU3+NkyrnykU4HHmaFUOC9PdaC7WqW7zawC
WxkC1RMYp86sdFUSBYubopVGZHI4zVobOhanvnGZjFQDuJZsAdM+Bpg/IYE7An4A
R1MBHg5GQ/tLLdwLGugvmPh+0ZmrE2ykF95v9hX1AgMBAAGjggE7MIIBNzASBgNV
HRMBAf8ECDAGAQH/AgEAMA4GA1UdDwEB/wQEAwIBBjAyBgNVHR8EKzApMCegJaAj
hiFodHRwOi8vdDEuc3ltY2IuY29tL1RoYXd0ZVBDQS5jcmwwLwYIKwYBBQUHAQEE
IzAhMB8GCCsGAQUFBzABhhNodHRwOi8vdDIuc3ltY2IuY29tMEEGA1UdIAQ6MDgw
NgYKYIZIAYb4RQEHNjAoMCYGCCsGAQUFBwIBFhpodHRwczovL3d3dy50aGF3dGUu
Y29tL2NwczApBgNVHREEIjAgpB4wHDEaMBgGA1UEAxMRU3ltYW50ZWNQS0ktMS01
MzcwHQYDVR0OBBYEFMJPSFf80U+awF04fQ4F29kutVJgMB8GA1UdIwQYMBaAFHtb
Rc+vzst6/TGSGmq280brV0hQMA0GCSqGSIb3DQEBCwUAA4IBAQCNBt5DyXYCytkj
l17zY9d9RMIPawr1B+WLuPrgo/prgJK1AyzFN+DC5ZW1knAYKEKU7kt3agEPiyPs
Vk30AGnlhMji6t5bPvY8BzqUymwnscyDGmBxJ9K/AvUeRNNI1abTdiEAnPqYZOsX
Nj/rGzw+prHZWAYOctlovvGnINdS5KR3H3FwnVU1hTfhHU2UwnB/lUBuS32ytCkq
A3nIuUxnYQSgiyf/WQDrVX/GtzM1LV5OrLjqEsXo97mrvnSSLLfZTcqELxzC8HJ8
sjFuz4DliAc2UXu6Ya9tjSNbNKOVvKIxf/L157fo78S1JzLp955pxyvovrsMqufq
YBLqJop4
-----END CERTIFICATE-----"


issuer33="thawte EV SSL CA - G2"
		issuer33Chain="-----BEGIN CERTIFICATE-----
MIIErzCCA5egAwIBAgIQBSNxUOZ73TjzPvU80hExPzANBgkqhkiG9w0BAQUFADCB
qTELMAkGA1UEBhMCVVMxFTATBgNVBAoTDHRoYXd0ZSwgSW5jLjEoMCYGA1UECxMf
Q2VydGlmaWNhdGlvbiBTZXJ2aWNlcyBEaXZpc2lvbjE4MDYGA1UECxMvKGMpIDIw
MDYgdGhhd3RlLCBJbmMuIC0gRm9yIGF1dGhvcml6ZWQgdXNlIG9ubHkxHzAdBgNV
BAMTFnRoYXd0ZSBQcmltYXJ5IFJvb3QgQ0EwHhcNMTMxMDMxMDAwMDAwWhcNMjMx
MDMwMjM1OTU5WjBEMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMdGhhd3RlLCBJbmMu
MR4wHAYDVQQDExV0aGF3dGUgRVYgU1NMIENBIC0gRzIwggEiMA0GCSqGSIb3DQEB
AQUAA4IBDwAwggEKAoIBAQC0OdfRaYVQLcLryGKXMjAXBPTxgJ42N0UuRJhZvWjc
ZaHMo4Q2+bopTFkef3zLozYK1Da8nWbuDeC0SeGgtuL2P4xph3HNNCR84gl7QH0X
Tx07r+2Inhz7AcoWJjoZxFp7MmTscPt2jMmiXx4vEo3SAAtnF/vcQXefw8rTLEQp
dA0SVB4BqvsEhI4jxALF9R1x+99EwUkfiYL23J9SQlfKDiRv+f3guiGXNRp3vF1k
CNkTDLpHe3PcZ9tqWNTboFpYsPStSGX+dJqPzWtfS04oQGSYZpKxz3LYxXYL3LzZ
Dr06D7ygFnKLjKOxAwKW9ilCkOrBwwtNvsJ9lFx5x/EhAgMBAAGjggE1MIIBMTAS
BgNVHRMBAf8ECDAGAQH/AgEAMA4GA1UdDwEB/wQEAwIBBjAvBggrBgEFBQcBAQQj
MCEwHwYIKwYBBQUHMAGGE2h0dHA6Ly90Mi5zeW1jYi5jb20wOwYDVR0gBDQwMjAw
BgRVHSAAMCgwJgYIKwYBBQUHAgEWGmh0dHBzOi8vd3d3LnRoYXd0ZS5jb20vY3Bz
MDIGA1UdHwQrMCkwJ6AloCOGIWh0dHA6Ly90MS5zeW1jYi5jb20vVGhhd3RlUENB
LmNybDApBgNVHREEIjAgpB4wHDEaMBgGA1UEAxMRU3ltYW50ZWNQS0ktMS01MzUw
HQYDVR0OBBYEFC40Iw1fwXqy30AvXuVWMOSapGyEMB8GA1UdIwQYMBaAFHtbRc+v
zst6/TGSGmq280brV0hQMA0GCSqGSIb3DQEBBQUAA4IBAQCQB3H7nhipCm+K4gcT
7XNGnYDGt4FNKRPF4SenZuZsnu9TcJRaQJOJdYZk5tuDLK7CF8t3nCJof7hdP9vW
IyYJ/xYTSA+qQaGIP8DdyG0Ch/ysJ+LAK4Y6djQxXQS6rrqL2twRCw0SLz/tWoaH
wlE2gkoMSeirqHgYBXEBJeoM4aljXLClHbM+GOJBqhSVgBnq0Kgfx1HAp/E3WZu8
H+r0LaHtfmO+bHOotBGlRlTigl2WMPb0dKe2pr2a8Cb8YwbnHBqhpAztRr7G/QKo
aQKQ+m00ioV0ZuS8l3COYKYdDMTmqBOVQxrqFOE0nGr65yTPPJ7jBtE5YEoesvKU
i4Ah
-----END CERTIFICATE-----"

issuer34="Symantec Class 3 EV SSL CA - G2"
		issuer34Chain="-----BEGIN CERTIFICATE-----
MIIFKzCCBBOgAwIBAgIQNmWFB3qIZ6tY9KCU+BA3MzANBgkqhkiG9w0BAQUFADCB
yjELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDlZlcmlTaWduLCBJbmMuMR8wHQYDVQQL
ExZWZXJpU2lnbiBUcnVzdCBOZXR3b3JrMTowOAYDVQQLEzEoYykgMjAwNiBWZXJp
U2lnbiwgSW5jLiAtIEZvciBhdXRob3JpemVkIHVzZSBvbmx5MUUwQwYDVQQDEzxW
ZXJpU2lnbiBDbGFzcyAzIFB1YmxpYyBQcmltYXJ5IENlcnRpZmljYXRpb24gQXV0
aG9yaXR5IC0gRzUwHhcNMTMxMDMxMDAwMDAwWhcNMjMxMDMwMjM1OTU5WjB3MQsw
CQYDVQQGEwJVUzEdMBsGA1UEChMUU3ltYW50ZWMgQ29ycG9yYXRpb24xHzAdBgNV
BAsTFlN5bWFudGVjIFRydXN0IE5ldHdvcmsxKDAmBgNVBAMTH1N5bWFudGVjIENs
YXNzIDMgRVYgU1NMIENBIC0gRzIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEK
AoIBAQDa7MVqNhGG2yAho+xMIf0PxVw6vuyibpgOgplrenrrbvIlyS1gIF3WK+bd
mdnxVFx2mwv5J0IkfOrU5jwqziOf+3jJFUT0VixVzla3MPBJif4N2G4BfGHTRJlm
XpZIGIcJyMNJ6TXsu0x6FZFV7WCAlQvXGPOnS+bodAwua0X0F/nLv1RW7jbUTubP
rR9NfY+zVTXdYtJuVIWeRVN67mCWIn+4Gq9voA6mjhO2haHMXIyerR1xuAiU5s68
ONDR6T9xQ/uXI6hs9DHcAjveKVXyoL4eIWyvGlzfajdkAprQUXGlf7ppxSyJZ3A7
EwVy7SEjECsjKhquOglkI3onYhLRAgMBAAGjggFdMIIBWTAvBggrBgEFBQcBAQQj
MCEwHwYIKwYBBQUHMAGGE2h0dHA6Ly9zMi5zeW1jYi5jb20wEgYDVR0TAQH/BAgw
BgEB/wIBADBlBgNVHSAEXjBcMFoGBFUdIAAwUjAmBggrBgEFBQcCARYaaHR0cDov
L3d3dy5zeW1hdXRoLmNvbS9jcHMwKAYIKwYBBQUHAgIwHBoaaHR0cDovL3d3dy5z
eW1hdXRoLmNvbS9ycGEwMAYDVR0fBCkwJzAloCOgIYYfaHR0cDovL3MxLnN5bWNi
LmNvbS9wY2EzLWc1LmNybDAOBgNVHQ8BAf8EBAMCAQYwKQYDVR0RBCIwIKQeMBwx
GjAYBgNVBAMTEVN5bWFudGVjUEtJLTEtNTMyMB0GA1UdDgQWBBRL+i3k7jMy4t8N
AaGG06A7OrmsrjAfBgNVHSMEGDAWgBR/02Wnwt3su/AwCfNDOfoCrzMxMzANBgkq
hkiG9w0BAQUFAAOCAQEARqb1s+ikVsm4NPD3/vMsLmORYyzp1RR/E5P2TN5NgpnM
a8l4YfsSLUgPcOonb3jo9wM+yrg7usnfsDri3iLQMS1m2m4RJUL1eyTC3ksSd81W
2PuGgLoKU27lAQgb0cmydZ2rBics8lKPWb2uHXT648b8RE1bSmzJuDnZ91qE+aAD
wjhOizKlQNrCdfS8yvlX+YYHdVvudjUwhQdz0lxG7Q965X9sPTfBveaFSWC6jfnv
2qxKMeFk9nlnvz9v4pVS3k+NydQ9/L07uDHw9dn1QQRU4CafmYP5BTYlccTLwSse
g1CoewuMVg6qXabpL6Fn/jcgxT6d/J2sIP17u5y4IA==
-----END CERTIFICATE-----"

issuer35="Symantec Class 3 EV SSL SGC CA - G2"
		issuer35Chain="-----BEGIN CERTIFICATE-----
MIIFZTCCBE2gAwIBAgIQeg9B3xzNFNyyaSmO4ixqNTANBgkqhkiG9w0BAQUFADCB
yjELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDlZlcmlTaWduLCBJbmMuMR8wHQYDVQQL
ExZWZXJpU2lnbiBUcnVzdCBOZXR3b3JrMTowOAYDVQQLEzEoYykgMjAwNiBWZXJp
U2lnbiwgSW5jLiAtIEZvciBhdXRob3JpemVkIHVzZSBvbmx5MUUwQwYDVQQDEzxW
ZXJpU2lnbiBDbGFzcyAzIFB1YmxpYyBQcmltYXJ5IENlcnRpZmljYXRpb24gQXV0
aG9yaXR5IC0gRzUwHhcNMTMxMDMxMDAwMDAwWhcNMjMxMDMwMjM1OTU5WjB7MQsw
CQYDVQQGEwJVUzEdMBsGA1UEChMUU3ltYW50ZWMgQ29ycG9yYXRpb24xHzAdBgNV
BAsTFlN5bWFudGVjIFRydXN0IE5ldHdvcmsxLDAqBgNVBAMTI1N5bWFudGVjIENs
YXNzIDMgRVYgU1NMIFNHQyBDQSAtIEcyMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8A
MIIBCgKCAQEAxDhMQwqzoGTTUNPmqgk9gLqsHOgKaWOOgOFWBDG5b6gJiqjUtAxM
vwYqzn3LofSsemv8msy/whs+dsx7XVCzHSZsFZXgS9RdoQzTfRNZC07FlpBQLoiT
lq+XMnQN9xukxwkqFk//+lJW73H/MLW0ZUJZ0pySdadcdKVRjIg8U41mmt6iyPjI
3T05XcJ5xEg3xij6JHP+DCpo8Gao0LLwdpQiGGzzj+TRrVmBD479ioVeReh9iFbv
FGPKDppmNIfsv/3hUQ4azUtPq/xSmEhN9/vWsHGiJ7htRraPgFiASVcOdjPvnG8p
8Kh/sNUP39bBAcsMeO2cbbstldi/x5Z6TwIDAQABo4IBkzCCAY8wEgYDVR0TAQH/
BAgwBgEB/wIBADAwBgNVHR8EKTAnMCWgI6Ahhh9odHRwOi8vczEuc3ltY2IuY29t
L3BjYTMtZzUuY3JsMA4GA1UdDwEB/wQEAwIBBjAvBggrBgEFBQcBAQQjMCEwHwYI
KwYBBQUHMAGGE2h0dHA6Ly9zMi5zeW1jYi5jb20wZQYDVR0gBF4wXDBaBgRVHSAA
MFIwJgYIKwYBBQUHAgEWGmh0dHA6Ly93d3cuc3ltYXV0aC5jb20vY3BzMCgGCCsG
AQUFBwICMBwaGmh0dHA6Ly93d3cuc3ltYXV0aC5jb20vcnBhMDQGA1UdJQQtMCsG
CWCGSAGG+EIEAQYKYIZIAYb4RQEIAQYIKwYBBQUHAwEGCCsGAQUFBwMCMCkGA1Ud
EQQiMCCkHjAcMRowGAYDVQQDExFTeW1hbnRlY1BLSS0xLTU0MjAdBgNVHQ4EFgQU
Rk/B4IjafdN4m8huWS+w5PcdkOIwHwYDVR0jBBgwFoAUf9Nlp8Ld7LvwMAnzQzn6
Aq8zMTMwDQYJKoZIhvcNAQEFBQADggEBAFMvp4r4RXIynzhC9YXex2z6fOW2xFf9
QOatRfSb6/6bBJbBZl+ro+DfGmDr0JPRwRqKhcG89tgLMHNcFj64Sb0DHZcZ4lqY
qP6GFh4JAMLnuU9lI+Tck33+UyDZgPXjcmCuKez/ZzYLTRqhxvCf1SdTPtpP2YAK
NAt2EMJ19Kl37x4aNKouge9PeAOPfIunBLnl58uTgHtqBs4ux8kaiMo7FLB1OdXB
IwNckDPsgQz6sxw4WgNdqAij/tXJCFfJj2lf2X/rckAXzYEZueTdSfWqXP+Y2jLs
fJMqJv7aTB4j9xjkO2IJZ0Mg7Ta4OjWgbNxpWcoqJ5Q6be54oEex9ZQ=
-----END CERTIFICATE-----"

issuer36="thawte DV SSL CA - G2"
		issuer36Chain="-----BEGIN CERTIFICATE-----
MIIE0jCCA7qgAwIBAgIQLGnhL2pnC9md0g+RnvCeUTANBgkqhkiG9w0BAQsFADCB
qTELMAkGA1UEBhMCVVMxFTATBgNVBAoTDHRoYXd0ZSwgSW5jLjEoMCYGA1UECxMf
Q2VydGlmaWNhdGlvbiBTZXJ2aWNlcyBEaXZpc2lvbjE4MDYGA1UECxMvKGMpIDIw
MDYgdGhhd3RlLCBJbmMuIC0gRm9yIGF1dGhvcml6ZWQgdXNlIG9ubHkxHzAdBgNV
BAMTFnRoYXd0ZSBQcmltYXJ5IFJvb3QgQ0EwHhcNMTQwNjEwMDAwMDAwWhcNMjQw
NjA5MjM1OTU5WjBjMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMdGhhd3RlLCBJbmMu
MR0wGwYDVQQLExREb21haW4gVmFsaWRhdGVkIFNTTDEeMBwGA1UEAxMVdGhhd3Rl
IERWIFNTTCBDQSAtIEcyMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA
6pQHhchBLPaDEmySX6sfANSWb3TNLhHpbA85AblIkEA5TcSiyHlqpZq9kURld1St
/yVf7kL7swIP6l163RpUntdzQpvMeV/FTfS3Cxg5IHrdUAFdNEVfTBEO9YcmJrSw
835xoDFxUIloWmOKFGLljDoWVQ0+66qAHXF644cHq72idM3aCAGdG8wniIxH1Gkl
Qta7UG2FUNBIgg0In+kj40LGPJi4u27FcBPfGR0B/dK1TuZi9Af6a30Rd8RiT0BO
pXiXqyxNDKd8w8RQMp/QcJsP//91WTSFrUnVNe5PW9TUNpWgfujFoRy9E0597mNq
lhmZyKcqAOZRjUbrMFjoLQIDAQABo4IBOTCCATUwEgYDVR0TAQH/BAgwBgEB/wIB
ADBBBgNVHSAEOjA4MDYGCmCGSAGG+EUBBzYwKDAmBggrBgEFBQcCARYaaHR0cHM6
Ly93d3cudGhhd3RlLmNvbS9jcHMwDgYDVR0PAQH/BAQDAgEGMC4GCCsGAQUFBwEB
BCIwIDAeBggrBgEFBQcwAYYSaHR0cDovL3Quc3ltY2QuY29tMDEGA1UdHwQqMCgw
JqAkoCKGIGh0dHA6Ly90LnN5bWNiLmNvbS9UaGF3dGVQQ0EuY3JsMCkGA1UdEQQi
MCCkHjAcMRowGAYDVQQDExFTeW1hbnRlY1BLSS0xLTY5ODAdBgNVHQ4EFgQUn7jB
qWzy9cAiKpTtXJms1OzXxgcwHwYDVR0jBBgwFoAUe1tFz6/Oy3r9MZIaarbzRutX
SFAwDQYJKoZIhvcNAQELBQADggEBAFNU8keoAtfvqjV4vkoIDZAYS22eKlMr6VQX
d3QpftA3BwW45Pq4tGOYRNzGT4EGjDq+xzBXxnD81pMZn8NV1z4fcoqdMFo1lzLL
Y+TGct/7aMppL9vNUDg+K7urO4LH/UubvXxBmO8BU9g1jyXJAwbmnFfBUQ+e9n2T
Tfh2yDpr9MSPMzJ/nSGENNmn+ZL6QZFhhAWdo3lGzmfngfJerEy8qKtqbRXinE5a
2WOAvPdC65pExoxrBja0izKJ3sLxqCaqqaz/6nGm54xB+hc1u7OHMamTwshY4QpO
lYOcue07pe8I4HT5wxvmB6PuB9dCInkhoKHUHSbT0NamXStBwHk=
-----END CERTIFICATE-----"

#***************************************************************
# ECC Hybrid Intermediate Certificates
#***************************************************************

issuer37="Symantec Class 3 ECC 256 bit EV CA - G2"
		issuer37Chain="-----BEGIN CERTIFICATE-----
MIIEYjCCA0qgAwIBAgIQcSI8pSIYXqxEzxdw0aiqXTANBgkqhkiG9w0BAQsFADCB
yjELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDlZlcmlTaWduLCBJbmMuMR8wHQYDVQQL
ExZWZXJpU2lnbiBUcnVzdCBOZXR3b3JrMTowOAYDVQQLEzEoYykgMjAwNiBWZXJp
U2lnbiwgSW5jLiAtIEZvciBhdXRob3JpemVkIHVzZSBvbmx5MUUwQwYDVQQDEzxW
ZXJpU2lnbiBDbGFzcyAzIFB1YmxpYyBQcmltYXJ5IENlcnRpZmljYXRpb24gQXV0
aG9yaXR5IC0gRzUwHhcNMTUwNTEyMDAwMDAwWhcNMjUwNTExMjM1OTU5WjB/MQsw
CQYDVQQGEwJVUzEdMBsGA1UEChMUU3ltYW50ZWMgQ29ycG9yYXRpb24xHzAdBgNV
BAsTFlN5bWFudGVjIFRydXN0IE5ldHdvcmsxMDAuBgNVBAMTJ1N5bWFudGVjIENs
YXNzIDMgRUNDIDI1NiBiaXQgRVYgQ0EgLSBHMjBZMBMGByqGSM49AgEGCCqGSM49
AwEHA0IABC93+aAYNSQS+F5P39qxy3AhmkNBfnYME9lyISEJCvfrBSSiVc2ySA6v
e6GH2RRknqCtxX85cEyaQgABoxYHiL2jggFXMIIBUzASBgNVHRMBAf8ECDAGAQH/
AgEAMC8GA1UdHwQoMCYwJKAioCCGHmh0dHA6Ly9zLnN5bWNiLmNvbS9wY2EzLWc1
LmNybDAOBgNVHQ8BAf8EBAMCAQYwLgYIKwYBBQUHAQEEIjAgMB4GCCsGAQUFBzAB
hhJodHRwOi8vcy5zeW1jZC5jb20wXwYDVR0gBFgwVjBUBgRVHSAAMEwwIwYIKwYB
BQUHAgEWF2h0dHBzOi8vZC5zeW1jYi5jb20vY3BzMCUGCCsGAQUFBwICMBkaF2h0
dHBzOi8vZC5zeW1jYi5jb20vcnBhMCsGA1UdEQQkMCKkIDAeMRwwGgYDVQQDExNT
WU1DLUVDQy1DQS1wMjU2LTIzMB0GA1UdDgQWBBRycjbGpzGeh4nHMn3sOvWiZD94
ejAfBgNVHSMEGDAWgBR/02Wnwt3su/AwCfNDOfoCrzMxMzANBgkqhkiG9w0BAQsF
AAOCAQEAOiHdrJlwGYxgg+Zh8ePYDYqFuLbuom7+myENWaZ+NIsKAkHheANBJWJA
Ot6t8TKkGp7G+YeDQ/oEZRGwYyIrQgi7gyZqmpcojna6Wp1OxF1KHotIDEAh/LBk
73jOaJglZVeodRO40nhARoHHB0eJlIWoA8DybXAjVRMW0fxmAvFb3pjuKjokQtE9
muqFQfr8proZ8BdhmMv41d5IRATmkUU5jGJzAbph4EuypmgXSIES0IHsMxNxwJjU
ufpCh8h4dkv/pqkWH3sArdavhoK/NURrDkzPa+EwbIDVooWWBbLCBQ8LGbCyOeKp
Gov7Dys9bWC8vFML1cH+QDRfDwymdA==
-----END CERTIFICATE-----"

issuer38="Symantec Class 3 ECC 256 bit SSL CA - G2"
		issuer38Chain="-----BEGIN CERTIFICATE-----
MIIEajCCA1KgAwIBAgIQP5KHvp0dpKN6nfYoLndaxDANBgkqhkiG9w0BAQsFADCB
yjELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDlZlcmlTaWduLCBJbmMuMR8wHQYDVQQL
ExZWZXJpU2lnbiBUcnVzdCBOZXR3b3JrMTowOAYDVQQLEzEoYykgMjAwNiBWZXJp
U2lnbiwgSW5jLiAtIEZvciBhdXRob3JpemVkIHVzZSBvbmx5MUUwQwYDVQQDEzxW
ZXJpU2lnbiBDbGFzcyAzIFB1YmxpYyBQcmltYXJ5IENlcnRpZmljYXRpb24gQXV0
aG9yaXR5IC0gRzUwHhcNMTUwNTEyMDAwMDAwWhcNMjUwNTExMjM1OTU5WjCBgDEL
MAkGA1UEBhMCVVMxHTAbBgNVBAoTFFN5bWFudGVjIENvcnBvcmF0aW9uMR8wHQYD
VQQLExZTeW1hbnRlYyBUcnVzdCBOZXR3b3JrMTEwLwYDVQQDEyhTeW1hbnRlYyBD
bGFzcyAzIEVDQyAyNTYgYml0IFNTTCBDQSAtIEcyMFkwEwYHKoZIzj0CAQYIKoZI
zj0DAQcDQgAEDxukkdfnrOfRTk63ZFvhj39uBNOrONtEt0Bcbb2WljffeYmGZ/ex
Hwie/WM7RoyfvVPoFdyXPiuBRq2Gfw4BOaOCAV0wggFZMC4GCCsGAQUFBwEBBCIw
IDAeBggrBgEFBQcwAYYSaHR0cDovL3Muc3ltY2QuY29tMBIGA1UdEwEB/wQIMAYB
Af8CAQAwZQYDVR0gBF4wXDBaBgpghkgBhvhFAQc2MEwwIwYIKwYBBQUHAgEWF2h0
dHBzOi8vZC5zeW1jYi5jb20vY3BzMCUGCCsGAQUFBwICMBkaF2h0dHBzOi8vZC5z
eW1jYi5jb20vcnBhMC8GA1UdHwQoMCYwJKAioCCGHmh0dHA6Ly9zLnN5bWNiLmNv
bS9wY2EzLWc1LmNybDAOBgNVHQ8BAf8EBAMCAQYwKwYDVR0RBCQwIqQgMB4xHDAa
BgNVBAMTE1NZTUMtRUNDLUNBLXAyNTYtMjIwHQYDVR0OBBYEFCXwiuFLetkBlQrt
xlPxjHgf2fP4MB8GA1UdIwQYMBaAFH/TZafC3ey78DAJ80M5+gKvMzEzMA0GCSqG
SIb3DQEBCwUAA4IBAQAMMGUXBaWTdaLxsTGtcB/naqjIQrLvoV9NG+7MoHpGd/69
dZ/h2zOy7sGFUHoG/0HGRA9rxT/5w5GkEVIVkxtWyIWWq6rs4CTZt8Bej/KHYRbo
jtEDUkCTZSTLiCvguPyvinXgxy+LHT+PmdtEfXsvcdbeBSWUYpOsDYvD2hNtz9dw
Od5nBosMApmdxt+z7LQyZu8wMnfI1U6IMO+RWowxZ8uy0oswdFYd32l9xe+aAE/k
y9alLu/M9pvxiUKufqHJRgDBKA6uDjHLMPX+/nxXaNCPX3SI4KVZ1stHQ/U5oNlM
dHN9umAvlU313g0IgJrjsQ2nIdf9dsdP+6lrmP7s
-----END CERTIFICATE-----"

issuer39="GeoTrust DV SSL CA - G2"
issuer39Chain="-----BEGIN CERTIFICATE-----
MIIEezCCA2OgAwIBAgIDAjprMA0GCSqGSIb3DQEBBQUAMEIxCzAJBgNVBAYTAlVT
MRYwFAYDVQQKEw1HZW9UcnVzdCBJbmMuMRswGQYDVQQDExJHZW9UcnVzdCBHbG9i
YWwgQ0EwHhcNMTMwNjA0MjEyNDU5WhcNMjIwNTIwMjEyNDU5WjBmMQswCQYDVQQG
EwJVUzEWMBQGA1UEChMNR2VvVHJ1c3QgSW5jLjEdMBsGA1UECxMURG9tYWluIFZh
bGlkYXRlZCBTU0wxIDAeBgNVBAMTF0dlb1RydXN0IERWIFNTTCBDQSAtIEcyMIIB
IjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAyy+aEAggLSL+sEKPs47esaaS
ynUcz6uYAE0OAqnEKIHJBKlZofLIvJupWjtDNNHcTYkBf8AZnqOzZ6AY0Qm+fjWs
wu0zbjicwATXJk1wWV0aaKplM2qUN4MmeTcmetUjWeA7DhqMrB5To/pnhyDQPdhS
1wV9nMdRmQGUIPgsrhs64mW84CRB5sYomhFfzBBq2d5JTIsW/m7xUFQAKCPZPzYP
+bvtsXhceUmX9F+eZrB6yDBXU8v3ZLHikw7l/cSaXiVMUuWTJlQXyFp9hdfAduo8
gxvcOBc85zz5hui3/JFvdWdDQlCtplfJv2PNnSGusb4GapHkSev81g3VE+BioQID
AQABo4IBVDCCAVAwHwYDVR0jBBgwFoAUwHqYaI2J+6sFZAwRfap9ZbjKzE4wHQYD
VR0OBBYEFFwLKw+5lFjNvFCzz1iV2HZ8O8pSMBIGA1UdEwEB/wQIMAYBAf8CAQAw
DgYDVR0PAQH/BAQDAgEGMDoGA1UdHwQzMDEwL6AtoCuGKWh0dHA6Ly9jcmwuZ2Vv
dHJ1c3QuY29tL2NybHMvZ3RnbG9iYWwuY3JsMDQGCCsGAQUFBwEBBCgwJjAkBggr
BgEFBQcwAYYYaHR0cDovL29jc3AuZ2VvdHJ1c3QuY29tMEwGA1UdIARFMEMwQQYK
YIZIAYb4RQEHNjAzMDEGCCsGAQUFBwIBFiVodHRwOi8vd3d3Lmdlb3RydXN0LmNv
bS9yZXNvdXJjZXMvY3BzMCoGA1UdEQQjMCGkHzAdMRswGQYDVQQDExJWZXJpU2ln
bk1QS0ktMi00MzEwDQYJKoZIhvcNAQEFBQADggEBAJ8GgBEqrhuznxE8akS0PUoq
uJ/LyCYny4GAe7vfnaTBubT4gJmem9ZsX9yJvJMMnVn+GcQc0okGgwkslhpN0cSI
QxjsmygRMtoIf0U/mjv+P4dRw+nbYgKt2i2YIO/WL7K1YzTcLuw/5qt14T8JJcup
WGWKVDJ7tptfHO77asNsDevBh/7znUZAMy9ojmOjzCjwYFiN58IcmeMXzwBZRihn
3E49bpAhUXDIlAvOGit4GtrXsHcNfLO308+HOIxZLkLNDPUwwMAjXPDPdVooFgfb
rHdfr7DfRR8qtbUOnZwwsU+eH6MIN6eW95XbSt3vssxOtWzNqJ5mJH63whQ6q64=
-----END CERTIFICATE-----"

issuer40="GeoTrust DV SSL CA - G3"
issuer40Chain="-----BEGIN CERTIFICATE-----
MIIEbzCCA1egAwIBAgIDAjpzMA0GCSqGSIb3DQEBCwUAMEIxCzAJBgNVBAYTAlVT
MRYwFAYDVQQKEw1HZW9UcnVzdCBJbmMuMRswGQYDVQQDExJHZW9UcnVzdCBHbG9i
YWwgQ0EwHhcNMTQwNjExMjIwMjU5WhcNMjIwNTIwMjIwMjU5WjBmMQswCQYDVQQG
EwJVUzEWMBQGA1UEChMNR2VvVHJ1c3QgSW5jLjEdMBsGA1UECxMURG9tYWluIFZh
bGlkYXRlZCBTU0wxIDAeBgNVBAMTF0dlb1RydXN0IERWIFNTTCBDQSAtIEczMIIB
IjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAs0Q6bLCuyxT5jBl0NFypaeOI
U3elp/+90TwNJ+TerX+80ZBYk9am2jmcreEOVkbulZ4QaEycK/ZqOouAgYcGVyUa
VlKU3ZDrZzve+q42aNNiafZsgiRET4dcmBGVZGvoDNHd5ieXrszikWpBErar5cxu
zCO4Y4ofMZMtBsT36D1YzZcIRmx7dMD4/DE7p3/Xj7DJFWNQehJN9RIeo35V43W3
6h7qMSwITtjLQ3SJJLzSDh7w2wUk9oq/ECeEQRr2GFPukdBUF9N9Pn6yfai/27kh
KvCJuQhuWrNe6oK4ficLzFZzgQVP45YtcdV4p2DD1+yqORoFOYKB4BUsNdHuJQID
AQABo4IBSDCCAUQwHwYDVR0jBBgwFoAUwHqYaI2J+6sFZAwRfap9ZbjKzE4wHQYD
VR0OBBYEFK1lIoWQ0DvjoUmLN/nxCx1fF6B3MBIGA1UdEwEB/wQIMAYBAf8CAQAw
DgYDVR0PAQH/BAQDAgEGMDUGA1UdHwQuMCwwKqAooCaGJGh0dHA6Ly9nLnN5bWNi
LmNvbS9jcmxzL2d0Z2xvYmFsLmNybDAuBggrBgEFBQcBAQQiMCAwHgYIKwYBBQUH
MAGGEmh0dHA6Ly9nLnN5bWNkLmNvbTBMBgNVHSAERTBDMEEGCmCGSAGG+EUBBzYw
MzAxBggrBgEFBQcCARYlaHR0cDovL3d3dy5nZW90cnVzdC5jb20vcmVzb3VyY2Vz
L2NwczApBgNVHREEIjAgpB4wHDEaMBgGA1UEAxMRU3ltYW50ZWNQS0ktMS02OTkw
DQYJKoZIhvcNAQELBQADggEBAE4nuBrHO9xdu54aNSMeiFWQ0eyGnIi34B9nh+J8
tUMDDrYC6OD/hoQZcenyS/WeLi5e26vWHE7EPrgseIZxEK6NxXC/pPmJ5rTt6Evt
fAkqCQgGPtTh3oKSDDQwNQrBYHXKtlVrqgBCyz/7EOH7hcEhkHIrbsDondm1WlCO
NB67OKc8Mb168kOL6xbKrZveax74T7ZeSikfehTukfSUT6S9m3Z6vPFRepaogQ6D
hz+Lrl4ymzSesufbL+wCoOH9UVL+LNs2usHWXktYbd7G4eH6mgMsW6Lhs5v5NuzB
c/ozEmaV42kQtteqM/r2nUFtliq6voMxQX8MCtJp1vw1TMM=
-----END CERTIFICATE-----"

issuer41="GeoTrust DV SSL CA - G4"
issuer41Chain="-----BEGIN CERTIFICATE-----
MIIERDCCAyygAwIBAgIDAjp4MA0GCSqGSIb3DQEBCwUAMEIxCzAJBgNVBAYTAlVT
MRYwFAYDVQQKEw1HZW9UcnVzdCBJbmMuMRswGQYDVQQDExJHZW9UcnVzdCBHbG9i
YWwgQ0EwHhcNMTQwODI5MjIyNDU4WhcNMjIwNTIwMjIyNDU4WjBmMQswCQYDVQQG
EwJVUzEWMBQGA1UEChMNR2VvVHJ1c3QgSW5jLjEdMBsGA1UECxMURG9tYWluIFZh
bGlkYXRlZCBTU0wxIDAeBgNVBAMTF0dlb1RydXN0IERWIFNTTCBDQSAtIEc0MIIB
IjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA30GUetr35DFDtuoBG1zOY+r6
baPZau4tmnX51ZxbvTTf2BzJbdgEiNputbe18DCuQNZd+sRTwdQinQROEaaV1UV8
QQVY4Ezd+e5VvV9G3K0TCJ0s5PeC5gcrng6MNKHOxKHggXCGAAY/Lep8myiuGyiL
OQnT5/BFpLG6EWeQVXuP3u04XKHh44PEw3KRT5juHMKAqmSlPoNiHMzgnvhawBMS
faKni6PnnyrXm8rL7ZcBnCiEUQRQQby0/HjpG88U6h8P/C4BMo22NcsKGDvsWj48
G9OZQx4v973zWxK5B17tPtGph8x3cifU2XWiY0uTNr3lXNe/X3kNszKnC7JjIwID
AQABo4IBHTCCARkwHwYDVR0jBBgwFoAUwHqYaI2J+6sFZAwRfap9ZbjKzE4wHQYD
VR0OBBYEFAtQ7HfvKpv/7AOhCv+txuQqGMc+MBIGA1UdEwEB/wQIMAYBAf8CAQAw
DgYDVR0PAQH/BAQDAgEGMDUGA1UdHwQuMCwwKqAooCaGJGh0dHA6Ly9nLnN5bWNi
LmNvbS9jcmxzL2d0Z2xvYmFsLmNybDAuBggrBgEFBQcBAQQiMCAwHgYIKwYBBQUH
MAGGEmh0dHA6Ly9nLnN5bWNkLmNvbTBMBgNVHSAERTBDMEEGCmCGSAGG+EUBBzYw
MzAxBggrBgEFBQcCARYlaHR0cDovL3d3dy5nZW90cnVzdC5jb20vcmVzb3VyY2Vz
L2NwczANBgkqhkiG9w0BAQsFAAOCAQEAMyTVkKopDDW5L8PHQpPAxhBLAwh2hBCi
4OdTEifyCtp/Otz9XHlajxd0Q1Ox1dFdWbmmhGTK8ToKWZYQv6mBV4tch9x/4+S7
BXqgMgkTThCBKB+cA2K89AG1KYNGB7nnuF3I6dHdrTv4NNvB0ZWpkRjtPCw3EU3M
/lM+UEP5w1ZBrFObbAWymuLgWVcwMrYmThMlzfpIcA91VWAR9TvVXlo8i1sPD2JC
SGGFixD0wYi/f1+KwtfNK5RcHzRKCK/rromoSHVVlR27wJoBufQDIj7U5lIwDWe5
wJH9LUwwjr2MpQSRu6Srfw/Yb/BmAMmjXPWwj4PmnFrmtrnFvL7kAg==
-----END CERTIFICATE-----"

issuer42="GeoTrust DV SSL SHA256 CA"
issuer42Chain="-----BEGIN CERTIFICATE-----
MIIE1jCCA76gAwIBAgIQXmMWQN0ZZjK0k6MwB5DXVjANBgkqhkiG9w0BAQsFADCB
mDELMAkGA1UEBhMCVVMxFjAUBgNVBAoTDUdlb1RydXN0IEluYy4xOTA3BgNVBAsT
MChjKSAyMDA4IEdlb1RydXN0IEluYy4gLSBGb3IgYXV0aG9yaXplZCB1c2Ugb25s
eTE2MDQGA1UEAxMtR2VvVHJ1c3QgUHJpbWFyeSBDZXJ0aWZpY2F0aW9uIEF1dGhv
cml0eSAtIEczMB4XDTE0MDYxMDAwMDAwMFoXDTI0MDYwOTIzNTk1OVowaDELMAkG
A1UEBhMCVVMxFjAUBgNVBAoTDUdlb1RydXN0IEluYy4xHTAbBgNVBAsTFERvbWFp
biBWYWxpZGF0ZWQgU1NMMSIwIAYDVQQDExlHZW9UcnVzdCBEViBTU0wgU0hBMjU2
IENBMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAwslPk4vuoPynEQwX
sa8gZUFVSSzV/yq8rSEWTqLP+Ml8e7MPsmyNy7aCWCvHH2CtlD/qx6KjT8St0MHq
J70NqjEyaLGfw+Vvc3Dy+JEodiKtOEsgfvVz+WNonfbUd1Gu+fjObzuSTucRPXo0
a59MvsZ7OT0BTfoQSigt8uGgcSvzn5DJg6ScLgWCXsNBRrp3PJMG+jxMnAl7xorX
xkLPFkuQ3X3zpt1VoAdcKuBtlOBA+XmIM31oTnRtiOoZ7n+LwoTOeODccVJnRQuW
tlP8tvdfXAknHZt//ygIXy7u4BJS7UNFjNX7JtqXlGhGA92qZDqTz2/po8lNPhgs
u5GX/wIDAQABo4IBSTCCAUUwLgYIKwYBBQUHAQEEIjAgMB4GCCsGAQUFBzABhhJo
dHRwOi8vZy5zeW1jZC5jb20wEgYDVR0TAQH/BAgwBgEB/wIBADBMBgNVHSAERTBD
MEEGCmCGSAGG+EUBBzYwMzAxBggrBgEFBQcCARYlaHR0cDovL3d3dy5nZW90cnVz
dC5jb20vcmVzb3VyY2VzL2NwczA2BgNVHR8ELzAtMCugKaAnhiVodHRwOi8vZy5z
eW1jYi5jb20vR2VvVHJ1c3RQQ0EtRzMuY3JsMA4GA1UdDwEB/wQEAwIBBjApBgNV
HREEIjAgpB4wHDEaMBgGA1UEAxMRU3ltYW50ZWNQS0ktMS02OTYwHQYDVR0OBBYE
FEnsp8ip98W7LKok5/RDs7E86FT4MB8GA1UdIwQYMBaAFMR5yo6hTgMdHNxr2zFb
lD4/MH8tMA0GCSqGSIb3DQEBCwUAA4IBAQC8fTpScyqmULJKTmRvnuWInRutfmBp
FbHPKzCER/I0+r+9l1xqjTLCbLnq3TICebSFgUlRwskq+OS0C5Rs4i8AH1/+XfTP
cgaEIb8K5IUnlpP+Bc46zDqWjTMBeV0fVza7qgSbnaklPnpejX7jENqJH31r3KDg
23JZxYPl01eOD54GPKjIN1yq5dru7DtVESZ+Yn+HJMCT3d6wBwXwYzsL4yUna1DF
4ua3h7lr7J9EdLdWna6aZX9xXmOIvF+dQ+4NmMxJxA7cqI4S81QFqGz/jgpwHiyZ
B0L6tg+JnPfY5v7sbQthTFKQhiPF8ac0g1U/9OW/tn4jF3JAh0Tdh+eX
-----END CERTIFICATE-----"

issuer43="GeoTrust DV SSL SHA256 CA - G2"
issuer43Chain="-----BEGIN CERTIFICATE-----
MIIEzDCCA7SgAwIBAgIQESfqNkHGNiMyR3PVI3KyAjANBgkqhkiG9w0BAQsFADCB
mDELMAkGA1UEBhMCVVMxFjAUBgNVBAoTDUdlb1RydXN0IEluYy4xOTA3BgNVBAsT
MChjKSAyMDA4IEdlb1RydXN0IEluYy4gLSBGb3IgYXV0aG9yaXplZCB1c2Ugb25s
eTE2MDQGA1UEAxMtR2VvVHJ1c3QgUHJpbWFyeSBDZXJ0aWZpY2F0aW9uIEF1dGhv
cml0eSAtIEczMB4XDTE1MDYzMDAwMDAwMFoXDTI1MDYyOTIzNTk1OVowbTELMAkG
A1UEBhMCVVMxFjAUBgNVBAoTDUdlb1RydXN0IEluYy4xHTAbBgNVBAsTFERvbWFp
biBWYWxpZGF0ZWQgU1NMMScwJQYDVQQDEx5HZW9UcnVzdCBEViBTU0wgU0hBMjU2
IENBIC0gRzIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCgTVrNM/J+
l+4Zqt5NlG6Efx4gkAuJRoaEjtok529PhvKJLCzRDyaNsFpil75UTOSJT1dNyP0R
Im+5rHQlcIS6fMnY0S+5UkcsdmGePhn4kte2krcE5JcrC4XmKzRcJao64Rac/0/j
SG7KXJ58I81xmuuRp6dUnslaSVue+7945PApEDJUP/sa3ptrmR3RyNj0Sf2oBBUg
pUJoMmrTpMuPCMRJiNJn+GDzpbHuYHNIrzC6NFa7CJ4X2CguwPrxxcRJ4dJLcOI+
Xt6NYbe2pZVUUchBPGZHPKc/3zdqVlD/FOo0DmttXVm66TSQeMi0hO+Ci0SOKDYe
3uvXzUsbIAaRAgMBAAGjggE6MIIBNjAuBggrBgEFBQcBAQQiMCAwHgYIKwYBBQUH
MAGGEmh0dHA6Ly9nLnN5bWNkLmNvbTASBgNVHRMBAf8ECDAGAQH/AgEAMEkGA1Ud
IARCMEAwPgYGZ4EMAQIBMDQwMgYIKwYBBQUHAgEWJmh0dHBzOi8vd3d3Lmdlb3Ry
dXN0LmNvbS9yZXNvdXJjZXMvY3BzMDYGA1UdHwQvMC0wK6ApoCeGJWh0dHA6Ly9n
LnN5bWNiLmNvbS9HZW9UcnVzdFBDQS1HMy5jcmwwHQYDVR0lBBYwFAYIKwYBBQUH
AwEGCCsGAQUFBwMCMA4GA1UdDwEB/wQEAwIBBjAdBgNVHQ4EFgQUi8P6vNmoQx6R
/AhPms00y5/f/6QwHwYDVR0jBBgwFoAUxHnKjqFOAx0c3GvbMVuUPj8wfy0wDQYJ
KoZIhvcNAQELBQADggEBAKeIPWCRYfis6Fftk0dRGWoGXzF1iHP56MOGo07fLyx3
AUvoRTA7PsbL7sK0dk84Ndnpaa6yRTGtnnQK8rGQKBUUxWzEDwXAIKf7yAZF1cn7
oC29FOCBxa7XOZXzJ+2fr2HjBA+peFz64oPbT3RUafmhoGCou5bNvn7y6QtHXhFD
IMx19r04VQXOqoVAtnu2iMSvC++S4uyZheLYxJm1g5RuF6gPOvSVN3JSeHbehReD
Y4RrQgiHBalOYId+givm/pZz/y+lwInFv8QhNhcgiiJbGZl+NVzLNPrQdWMTRlwY
onzbk+QKGwubmz9BInp1oFYCdY4/SSeEMg/uW+tDsTY=
-----END CERTIFICATE-----"

issuer44="GeoTrust ECC EV SSL CA"
issuer44Chain="-----BEGIN CERTIFICATE-----
MIIDyDCCA06gAwIBAgIQDww3Kf30lVv4ZevF7vQy/DAKBggqhkjOPQQDAzCBmDEL
MAkGA1UEBhMCVVMxFjAUBgNVBAoTDUdlb1RydXN0IEluYy4xOTA3BgNVBAsTMChj
KSAyMDA3IEdlb1RydXN0IEluYy4gLSBGb3IgYXV0aG9yaXplZCB1c2Ugb25seTE2
MDQGA1UEAxMtR2VvVHJ1c3QgUHJpbWFyeSBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0
eSAtIEcyMB4XDTE2MDEwNzAwMDAwMFoXDTI2MDEwNjIzNTk1OVowRzELMAkGA1UE
BhMCVVMxFzAVBgNVBAoTDkdlb1RydXN0LCBJbmMuMR8wHQYDVQQDExZHZW9UcnVz
dCBFQ0MgRVYgU1NMIENBMFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEF136Fo2A
bY7q0YbhVBTL4HNFaJyTdoU3y+o8YdhxQuw1SrpQT9EwLTyx8Xzf/LNPeoalIKNu
U/3LQgNct6Fk9aOCAcgwggHEMA4GA1UdDwEB/wQEAwIBBjAdBgNVHSUEFjAUBggr
BgEFBQcDAQYIKwYBBQUHAwIwLgYIKwYBBQUHAQEEIjAgMB4GCCsGAQUFBzABhhJo
dHRwOi8vZy5zeW1jZC5jb20wEgYDVR0TAQH/BAgwBgEB/wIBADCBqQYDVR0gBIGh
MIGeMAcGBWeBDAEBMIGSBgkrBgEEAfAiAQYwgYQwPwYIKwYBBQUHAgEWM2h0dHBz
Oi8vd3d3Lmdlb3RydXN0LmNvbS9yZXNvdXJjZXMvcmVwb3NpdG9yeS9sZWdhbDBB
BggrBgEFBQcCAjA1GjNodHRwczovL3d3dy5nZW90cnVzdC5jb20vcmVzb3VyY2Vz
L3JlcG9zaXRvcnkvbGVnYWwwNgYDVR0fBC8wLTAroCmgJ4YlaHR0cDovL2cuc3lt
Y2IuY29tL0dlb1RydXN0UENBLUcyLmNybDArBgNVHREEJDAipCAwHjEcMBoGA1UE
AxMTU1lNQy1FQ0MtQ0EtcDI1Ni0zMjAdBgNVHQ4EFgQUAEsfkYEOC0POBHO7lpuC
HWZjrTwwHwYDVR0jBBgwFoAUFV81V1FV+yWyrQNp/AGj+r4RVdUwCgYIKoZIzj0E
AwMDaAAwZQIweZGj+Ar54cOBtC1I6rkfdNOtxSg77WBAvvsEv1+knWbbu8Acroz1
Q9xqHnHLXpgRAjEAxNA5KzWxutl/kVj/7bUCYtvSWLfmb2ZTTsvof7VjjWlRnPje
wLtx+yN5EV7LPWDi
-----END CERTIFICATE-----"

issuer45="GeoTrust EV SSL CA - G5"
issuer45Chain="-----BEGIN CERTIFICATE-----
MIIETjCCAzagAwIBAgIQPLa8KZazehSnktHl2OwzWjANBgkqhkiG9w0BAQsFADBY
MQswCQYDVQQGEwJVUzEWMBQGA1UEChMNR2VvVHJ1c3QgSW5jLjExMC8GA1UEAxMo
R2VvVHJ1c3QgUHJpbWFyeSBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eTAeFw0xNDA5
MDkwMDAwMDBaFw0yNDA5MDgyMzU5NTlaMEcxCzAJBgNVBAYTAlVTMRYwFAYDVQQK
Ew1HZW9UcnVzdCBJbmMuMSAwHgYDVQQDExdHZW9UcnVzdCBFViBTU0wgQ0EgLSBH
NTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALiytAioX4l4sarlK5g0
BYeP+4S5HLVRTHGMVAQTUYTlM5ZYxNwAfm+bH8CNOQqWUzwe3rkhS8CUmX6JoxbR
oIVIGWJuw6lcPaGS5VIll6uiELuHMDBdAkT/W6+xzT99Nz65VuqiPtk5n3NklFjm
sm63B5kQP9GGKWaurzJD9Ow46WS0mEl1eiWt5NWNcjP4ztOKOe8xXWJrWP0KJY+R
m1KS8rJea0JO6vcpgdWxTBqr4LmdE7mK7mhQ4r5ePVUMt3Exsnkb08yLi82fvK9P
3bJzcLa56w7CsHr+UDqWlzRbF5igsYYRq3gHkQMv3rf+jo4Yhg7K0n2iNiCRntJb
rnsCAwEAAaOCASMwggEfMBIGA1UdEwEB/wQIMAYBAf8CAQAwLgYIKwYBBQUHAQEE
IjAgMB4GCCsGAQUFBzABhhJodHRwOi8vZy5zeW1jZC5jb20wVAYDVR0gBE0wSzBJ
BgRVHSAAMEEwPwYIKwYBBQUHAgEWM2h0dHBzOi8vd3d3Lmdlb3RydXN0LmNvbS9y
ZXNvdXJjZXMvcmVwb3NpdG9yeS9sZWdhbDAzBgNVHR8ELDAqMCigJqAkhiJodHRw
Oi8vZy5zeW1jYi5jb20vR2VvVHJ1c3RQQ0EuY3JsMA4GA1UdDwEB/wQEAwIBBjAd
BgNVHQ4EFgQUCCUHIUdsMf4IWA6m6i/n2xtiaMowHwYDVR0jBBgwFoAULNVQQZcV
i/CPNmFbSvtr2ZnJM5IwDQYJKoZIhvcNAQELBQADggEBAF1R8Szzu5OMY7OiWTNj
HO5PB2c0mPIxksmUmEjCJegoF4ihMiIKqE4IMLXhCZs7/oS8CRSFjmS3DVeqTz8i
+Bk6o/AhXwsv1ZYT9eEBWKOxrSTJfeGoLsQz9OgRE/3UhCraAv+9/SvJ1PvKkglH
Gv67K+Uw5ezBOxfWtdM2wJkTEqzDxcDPhVQufIxinAc57tcih1ozO0/Hut7/pZeh
t9PJ6UTl4xktKfeEoogi/OpDyPzvqcButxv2jDBJTcTQmq+tqgBsIazwVLold69R
Dqvo9DWpRk/xacqN4oaYFLN006qDRiWqklrM0vEL81FZFWhFXs/qTuq81dXyni30
YKo=
-----END CERTIFICATE-----"

issuer46="GeoTrust Extended Validation SSL CA - G2"
issuer46Chain="-----BEGIN CERTIFICATE-----
MIIEmjCCA4KgAwIBAgIQCx2xqRnyTDxO/LV6ak5svzANBgkqhkiG9w0BAQUFADBY
MQswCQYDVQQGEwJVUzEWMBQGA1UEChMNR2VvVHJ1c3QgSW5jLjExMC8GA1UEAxMo
R2VvVHJ1c3QgUHJpbWFyeSBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eTAeFw0xMjA4
MjMwMDAwMDBaFw0yMjA4MjIyMzU5NTlaMFgxCzAJBgNVBAYTAlVTMRYwFAYDVQQK
Ew1HZW9UcnVzdCBJbmMuMTEwLwYDVQQDEyhHZW9UcnVzdCBFeHRlbmRlZCBWYWxp
ZGF0aW9uIFNTTCBDQSAtIEcyMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKC
AQEAnsYhzS490LsqTaR7H6gawgOm/0NiW7+R0WZSqYGQaDGGFrsdhVipfpFqHkwx
yiHEvnAbn4zkBS2c7RF5rY+cJYZMuvLlYnmOIl+FfCI1OCONgDyszC38WPI1v2Zb
68Ek+HCAdDL5Rt4yGYCMt+caoapkmI3Kzg7ca/fikApsHKX0kDJS5fEAQjGRSEKJ
qF1/Y40xstZIXEVFIsnFWRKrQZTq/pxGTZq8nODixkaz5n/c9Q+jE0WGbXl4/OFQ
zwmG5Z+/yzrU4LHU/6g/fWIfwG14SMPXo6UjYcU+NU2y5fj9lEu8c1Ov45ppVb7L
Z6vhvu8bwk2syylcvO24Yp0Q6QIDAQABo4IBXjCCAVowPQYIKwYBBQUHAQEEMTAv
MC0GCCsGAQUFBzABhiFodHRwOi8vRVZTZWN1cmUtb2NzcC5nZW90cnVzdC5jb20w
EgYDVR0TAQH/BAgwBgEB/wIBADBGBgNVHSAEPzA9MDsGBFUdIAAwMzAxBggrBgEF
BQcCARYlaHR0cDovL3d3dy5nZW90cnVzdC5jb20vcmVzb3VyY2VzL2NwczBBBgNV
HR8EOjA4MDagNKAyhjBodHRwOi8vRVZTZWN1cmUtY3JsLmdlb3RydXN0LmNvbS9H
ZW9UcnVzdFBDQS5jcmwwDgYDVR0PAQH/BAQDAgEGMCoGA1UdEQQjMCGkHzAdMRsw
GQYDVQQDExJWZXJpU2lnbk1QS0ktMi0yNTMwHQYDVR0OBBYEFG8mVtlc5/fJBCD4
Hrp8kScvjPoHMB8GA1UdIwQYMBaAFCzVUEGXFYvwjzZhW0r7a9mZyTOSMA0GCSqG
SIb3DQEBBQUAA4IBAQCSd+lXyevERW/JTG59ABJxpeM5/hOESWznSXH1LMfANsII
WPODdcVy2I149GXqjNXjpQ6prevjoSOuk7fYdXVKWcvynttAv06J/pVCKTR79N1q
DXRfxxETLt0RbsbjW7PPpo3l92d7urOzaXAUsMKZtNJ2WzgXOUUbgvFTuD1VOQt/
/5itbpaatmpMel69sYYSnXwsYrsJk18/2LWKw0koDwv5OSIa/l3T6BhfnV+0wCDG
qUkNVXNqCXr/opm/2LuR3DA5rihL9sV3JOjWxqegTvKmmXXN3VfdCkeSy7u3SPoh
8Gkh/+UMqgyx6t0FHBmO0Sp5aAJezDjmKcR39Rkc
-----END CERTIFICATE-----"

issuer47="GeoTrust Secure Site Starter DV SSL CA - G1"
issuer47Chain="-----BEGIN CERTIFICATE-----
MIIE2jCCA8KgAwIBAgIQTcQ29yT2hNuMeUmZk/CZTjANBgkqhkiG9w0BAQsFADCB
mDELMAkGA1UEBhMCVVMxFjAUBgNVBAoTDUdlb1RydXN0IEluYy4xOTA3BgNVBAsT
MChjKSAyMDA4IEdlb1RydXN0IEluYy4gLSBGb3IgYXV0aG9yaXplZCB1c2Ugb25s
eTE2MDQGA1UEAxMtR2VvVHJ1c3QgUHJpbWFyeSBDZXJ0aWZpY2F0aW9uIEF1dGhv
cml0eSAtIEczMB4XDTE1MDkwMTAwMDAwMFoXDTI1MDgzMTIzNTk1OVowezELMAkG
A1UEBhMCVVMxFzAVBgNVBAoTDkdlb1RydXN0LCBJbmMuMR0wGwYDVQQLExREb21h
aW4gVmFsaWRhdGVkIFNTTDE0MDIGA1UEAxMrR2VvVHJ1c3QgU2VjdXJlIFNpdGUg
U3RhcnRlciBEViBTU0wgQ0EgLSBHMTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCC
AQoCggEBAMxOpVXDRi/2C8fU+QGyDl1kS0xwwatwptjNAon+cctRROprVIG6j4aE
0fh7v76i5H9kf6EC9um/88r17+LxFXS/gPRHcQG6Wjs+OUW1APo2IG/D1FqEt79P
kR4yA7zgwYlBPCnThDCPpSxqLbI1UO6JeVp99RuubSrvnjldT/POHPsDdwxLlfxn
C98m+DbRXlvM0e8vKqaR24eQCYlJae7+etqu8ti0uMl3wZ/r+1K31VF0aBjZTJLV
WRnZ7q5sMhRKbQePv2Okx3eJovPrhhudm2gqM2j6vWkT1TAdqDjiHcLUkY8gadCk
3evqLm/3WOFKQHkCqpEd+rj21367X7MCAwEAAaOCATowggE2MC4GCCsGAQUFBwEB
BCIwIDAeBggrBgEFBQcwAYYSaHR0cDovL2cuc3ltY2QuY29tMBIGA1UdEwEB/wQI
MAYBAf8CAQAwSQYDVR0gBEIwQDA+BgZngQwBAgEwNDAyBggrBgEFBQcCARYmaHR0
cHM6Ly93d3cuZ2VvdHJ1c3QuY29tL3Jlc291cmNlcy9jcHMwNgYDVR0fBC8wLTAr
oCmgJ4YlaHR0cDovL2cuc3ltY2IuY29tL0dlb1RydXN0UENBLUczLmNybDAdBgNV
HSUEFjAUBggrBgEFBQcDAQYIKwYBBQUHAwIwDgYDVR0PAQH/BAQDAgEGMB0GA1Ud
DgQWBBQlmXJBgKhO0Qf6gbOhQriKIAg8BTAfBgNVHSMEGDAWgBTEecqOoU4DHRzc
a9sxW5Q+PzB/LTANBgkqhkiG9w0BAQsFAAOCAQEAmt/ZIBzMP/XrWl0ziD179/JU
Iz9FQktjqumXkTBmUP8OFKHAdFd0/j6BCFq8FgjI1+D503gdUrgw60OgJAn+RGKV
MxGSbQJB4X//VIp9JUCaHa7CTSDF22j2Jf3N8qUGh+xLh3F51OcMeRqL/JMjGwJh
qjM/tQmvP9/TGIwmZLKvcVvErTzCSe3S9zst7f/zDy1e2pzfXc+Bg9mcFtw+w27g
PQx4+VSryBw0+k9kpeAnWT+45Q+Jmbyzel9/QyLEUOPXkG11U9b6AqTWpAdhgzmu
WsJVGVZjed/jbapXYN9qf4e4vgHZXbvX5sBoC1sYAAqy6GTbub762Qzc8KZ0/A==
-----END CERTIFICATE-----"

issuer48="Secure Site Starter DV SSL CA - G2"
issuer48Chain="-----BEGIN CERTIFICATE-----
MIIE+zCCA+OgAwIBAgIQQsfm6YRSI90QHzYx1YcIrTANBgkqhkiG9w0BAQsFADCB
mDELMAkGA1UEBhMCVVMxFjAUBgNVBAoTDUdlb1RydXN0IEluYy4xOTA3BgNVBAsT
MChjKSAyMDA4IEdlb1RydXN0IEluYy4gLSBGb3IgYXV0aG9yaXplZCB1c2Ugb25s
eTE2MDQGA1UEAxMtR2VvVHJ1c3QgUHJpbWFyeSBDZXJ0aWZpY2F0aW9uIEF1dGhv
cml0eSAtIEczMB4XDTE1MTIwMTAwMDAwMFoXDTI1MTEzMDIzNTk1OVowcjELMAkG
A1UEBhMCVVMxFzAVBgNVBAoTDkdlb1RydXN0LCBJbmMuMR0wGwYDVQQLExREb21h
aW4gVmFsaWRhdGVkIFNTTDErMCkGA1UEAxMiU2VjdXJlIFNpdGUgU3RhcnRlciBE
ViBTU0wgQ0EgLSBHMjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAOCH
OEwreG73OMHiZUNwuaQGOXOgmt+rNR0D7r+uB+51RdveO+c9cx+29QmYuwe4MBVe
muPrvgRhHI7gFhb2NZYa0BGgONs+ItaFzCbjiibqG+dA6kQpeX/bvuGK4Qb5j1gY
dcmxkTn/2SCIjDyNaBcbz8GQPB0S6Pkv0mbEPlbpbBtVyOcHDwwzqgcqwF03cavp
KdNFmjp05/zLB6e3t8ofhNMOU5xUPVJNlbJI3F44llRz4wdFVwShZnwIr8YCpGxn
gUbJbIzOErYZBOzO0w3hogTN601gUIH6p0i1tZFe116OIrOZ7Cr4d7Ja4xz87j1N
M2YuaQIoc8YhjTjcnUMCAwEAAaOCAWQwggFgMC4GCCsGAQUFBwEBBCIwIDAeBggr
BgEFBQcwAYYSaHR0cDovL2cuc3ltY2QuY29tMBIGA1UdEwEB/wQIMAYBAf8CAQAw
SAYDVR0gBEEwPzA9BgZngQwBAgEwMzAxBggrBgEFBQcCARYlaHR0cDovL3d3dy5n
ZW90cnVzdC5jb20vcmVzb3VyY2VzL2NwczA2BgNVHR8ELzAtMCugKaAnhiVodHRw
Oi8vZy5zeW1jYi5jb20vR2VvVHJ1c3RQQ0EtRzMuY3JsMB0GA1UdJQQWMBQGCCsG
AQUFBwMBBggrBgEFBQcDAjAOBgNVHQ8BAf8EBAMCAQYwKQYDVR0RBCIwIKQeMBwx
GjAYBgNVBAMTEVN5bWFudGVjUEtJLTItMjU0MB0GA1UdDgQWBBSbVK3faWDqcEJu
6C7HFH6I/7lEmTAfBgNVHSMEGDAWgBTEecqOoU4DHRzca9sxW5Q+PzB/LTANBgkq
hkiG9w0BAQsFAAOCAQEASVSVXc0IqAvuyBR7nwK+3nd15lJUNpdR0eILC50tQt4y
NvPE85JSz855cKj3pQNN9R8/Q3fNNW8ExQF8+u7GdUTw4VGVGf2Enp410EKGuB/s
Bk/1mpNa7mEkgPGuplbHeIwimfrbwlMgJHzPeCvtBN38Oc+tU3KnoBo7Ierag9No
U4Z1wu6kbXlHt4edsgDBk6qiteez+H2lpmBJM0dv/nNyuV7Ca7Puqwy0rYV9afVS
xszK1Woa4QS5a9BwiPR4Z9iP5/YdK4sUseBmMZB+P2sNWpFkQksG6KzGBqbSZRSY
7e+rVUghMnMMbX+zKeSYFUDT37vSbAaWweB+KYgowQ==
-----END CERTIFICATE-----"

issuer49="Secure Site Starter DV SSL CA - G3"
issuer49Chain="-----BEGIN CERTIFICATE-----
MIIEljCCA36gAwIBAgIDAjqFMA0GCSqGSIb3DQEBCwUAMEIxCzAJBgNVBAYTAlVT
MRYwFAYDVQQKEw1HZW9UcnVzdCBJbmMuMRswGQYDVQQDExJHZW9UcnVzdCBHbG9i
YWwgQ0EwHhcNMTUxMjAxMTEzNzE0WhcNMjIwNTIwMTEzNzE0WjByMQswCQYDVQQG
EwJVUzEXMBUGA1UEChMOR2VvVHJ1c3QsIEluYy4xHTAbBgNVBAsTFERvbWFpbiBW
YWxpZGF0ZWQgU1NMMSswKQYDVQQDEyJTZWN1cmUgU2l0ZSBTdGFydGVyIERWIFNT
TCBDQSAtIEczMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA1VZawV+O
gvNLbg3zdRBoYhdDgUQ9P0E+Fpic7fASPeIJ7XSw8vr3xA0elW+Y9AIkGmvzSSrv
cwWbn3I0DI82g2+DCM5zcC/8xC7rRacVhH3hitoDj9/0PnwgiaxF41MFAA38kAf5
dCF3ER1iv87YXDo3XaJ4Ec0R13Z33W3ukq9egeos9WrzCfhYkovJnDSZxDiRXn0W
o4abn9tTgkY0BCyQMRJO6GO7bcwx1OIymL5N5IbdG0X4cLNBGTngRH519vplMG1P
BucDZQ2110CEuwXpK1qLDGkbxfv84Jj998SQBws0/tOh0E1pGVrNetPkXgboI84N
UoNavR9wPPCo2wIDAQABo4IBYzCCAV8wHwYDVR0jBBgwFoAUwHqYaI2J+6sFZAwR
fap9ZbjKzE4wHQYDVR0OBBYEFMJkQe1gUbQvWvC7Vrggm4tF4FEBMA4GA1UdDwEB
/wQEAwIBBjAuBggrBgEFBQcBAQQiMCAwHgYIKwYBBQUHMAGGEmh0dHA6Ly9nLnN5
bWNkLmNvbTASBgNVHRMBAf8ECDAGAQH/AgEAMDUGA1UdHwQuMCwwKqAooCaGJGh0
dHA6Ly9nLnN5bWNiLmNvbS9jcmxzL2d0Z2xvYmFsLmNybDBIBgNVHSAEQTA/MD0G
BmeBDAECATAzMDEGCCsGAQUFBwIBFiVodHRwOi8vd3d3Lmdlb3RydXN0LmNvbS9y
ZXNvdXJjZXMvY3BzMB0GA1UdJQQWMBQGCCsGAQUFBwMBBggrBgEFBQcDAjApBgNV
HREEIjAgpB4wHDEaMBgGA1UEAxMRU3ltYW50ZWNQS0ktMi0yNTUwDQYJKoZIhvcN
AQELBQADggEBAG2ID3nye01naYLOZLYlu/wVREhB5VD5yFO3PGHVmrcAwCPJ0qAn
5DbwSrc4DaZfWm2BYAmaOEx6nl+Kd8ijXw7N7aiSzGOSin2bjPOKBtUCYhuoBq2a
kaztDKhnFfh50OXKYy+Rxi5tk+BQ9JzLMB6yeVMG0ema8XzDe8F+SwGtPapI8gOJ
dCmihQH5hQg7TMeHIbYcn+ZwCL46XUY+sCHr4zO6HqHTMMDUQ+OoaygbJegUQxdP
IXSno7ClfreVqQSJj2zTEV0BkxZAnhkDKHRTDRuhuZpSEGuhxopZMBw4AjPV97SZ
lArM/oX0YJgAIJrCSrRY0esMVGAwFWw5qFU=
-----END CERTIFICATE-----"

issuer50="GeoTrust SSL CA - G2"
issuer50Chain="-----BEGIN CERTIFICATE-----
MIIEWTCCA0GgAwIBAgIDAjpjMA0GCSqGSIb3DQEBBQUAMEIxCzAJBgNVBAYTAlVT
MRYwFAYDVQQKEw1HZW9UcnVzdCBJbmMuMRswGQYDVQQDExJHZW9UcnVzdCBHbG9i
YWwgQ0EwHhcNMTIwODI3MjA0MDQwWhcNMjIwNTIwMjA0MDQwWjBEMQswCQYDVQQG
EwJVUzEWMBQGA1UEChMNR2VvVHJ1c3QgSW5jLjEdMBsGA1UEAxMUR2VvVHJ1c3Qg
U1NMIENBIC0gRzIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQC5J/lP
2Pa3FT+Pzc7WjRxr/X/aVCFOA9jK0HJSFbjJgltYeYT/JHJv8ml/vJbZmnrDPqnP
UCITDoYZ2+hJ74vm1kfy/XNFCK6PrF62+J589xD/kkNm7xzU7qFGiBGJSXl6Jc5L
avDXHHYaKTzJ5P0ehdzgMWUFRxasCgdLLnBeawanazpsrwUSxLIRJdY+lynwg2xX
HNil78zs/dYS8T/bQLSuDxjTxa9Akl0HXk7+Yhc3iemLdCai7bgK52wVWzWQct3Y
TSHUQCNcj+6AMRaraFX0DjtU6QRN8MxOgV7pb1JpTr6mFm1C9VH/4AtWPJhPc48O
bxoj8cnI2d+87FLXAgMBAAGjggFUMIIBUDAfBgNVHSMEGDAWgBTAephojYn7qwVk
DBF9qn1luMrMTjAdBgNVHQ4EFgQUEUrQcznVW2kIXLo9v2SaqIscVbwwEgYDVR0T
AQH/BAgwBgEB/wIBADAOBgNVHQ8BAf8EBAMCAQYwOgYDVR0fBDMwMTAvoC2gK4Yp
aHR0cDovL2NybC5nZW90cnVzdC5jb20vY3Jscy9ndGdsb2JhbC5jcmwwNAYIKwYB
BQUHAQEEKDAmMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5nZW90cnVzdC5jb20w
TAYDVR0gBEUwQzBBBgpghkgBhvhFAQc2MDMwMQYIKwYBBQUHAgEWJWh0dHA6Ly93
d3cuZ2VvdHJ1c3QuY29tL3Jlc291cmNlcy9jcHMwKgYDVR0RBCMwIaQfMB0xGzAZ
BgNVBAMTElZlcmlTaWduTVBLSS0yLTI1NDANBgkqhkiG9w0BAQUFAAOCAQEAPOU9
WhuiNyrjRs82lhg8e/GExVeGd0CdNfAS8HgY+yKk3phLeIHmTYbjkQ9C47ncoNb/
qfixeZeZ0cNsQqWSlOBdDDMYJckrlVPg5akMfUf+f1ExRF73Kh41opQy98nuwLbG
mqzemSFqI6A4ZO6jxIhzMjtQzr+t03UepvTp+UJrYLLdRf1dVwjOLVDmEjIWE4ry
lKKbR6iGf9mY5ffldnRk2JG8hBYo2CVEMH6C2Kyx5MDkFWzbtiQnAioBEoW6MYhY
R3TjuNJkpsMyWS4pS0XxW4lJLoKaxhgVRNAuZAEVaDj59vlmAwxVG52/AECu8Egn
TOCAXi25KhV6vGb4NQ==
-----END CERTIFICATE-----"

issuer51="GeoTrust SSL CA - G4"
issuer51Chain="-----BEGIN CERTIFICATE-----
MIIEIjCCAwqgAwIBAgIDAjp5MA0GCSqGSIb3DQEBCwUAMEIxCzAJBgNVBAYTAlVT
MRYwFAYDVQQKEw1HZW9UcnVzdCBJbmMuMRswGQYDVQQDExJHZW9UcnVzdCBHbG9i
YWwgQ0EwHhcNMTQwOTA4MjA0MTEwWhcNMjIwNTIwMjA0MTEwWjBEMQswCQYDVQQG
EwJVUzEWMBQGA1UEChMNR2VvVHJ1c3QgSW5jLjEdMBsGA1UEAxMUR2VvVHJ1c3Qg
U1NMIENBIC0gRzQwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCafZho
EUDBX3LsVbOxY/MyInKRxhYFuwiCMbT27tQYOREvLtpH/lExblvyqQrrL7v1YVll
VwLNgP/HcDJUif3brply1E8MJrkuYzB93hRbatdSeCH5v7xQ1VQSWdi1NtkhR7g/
algdjHLhl5XT4UWo8Vrlvv7jU3yl8FLgzzmUDBlx8sAlB0h9HObxOSUvmHlD6Bhy
9GWGmFoABEfaS1gefIaxSzWmIAAczRs7Il3RkygzEiOUCKrDOvXRxox+mdMYoK2d
GM9JrRAD95kzJoZGmi+gumxuyIgCt276ep6YSu6aMX0ZFGAM7I8gIzzalya26oBs
ileeIO5vFyVKMq01AgMBAAGjggEdMIIBGTAfBgNVHSMEGDAWgBTAephojYn7qwVk
DBF9qn1luMrMTjAdBgNVHQ4EFgQUrDLtWsng3jCckFhVJmP2cqZUX+MwEgYDVR0T
AQH/BAgwBgEB/wIBADAOBgNVHQ8BAf8EBAMCAQYwNQYDVR0fBC4wLDAqoCigJoYk
aHR0cDovL2cuc3ltY2IuY29tL2NybHMvZ3RnbG9iYWwuY3JsMC4GCCsGAQUFBwEB
BCIwIDAeBggrBgEFBQcwAYYSaHR0cDovL2cuc3ltY2QuY29tMEwGA1UdIARFMEMw
QQYKYIZIAYb4RQEHNjAzMDEGCCsGAQUFBwIBFiVodHRwOi8vd3d3Lmdlb3RydXN0
LmNvbS9yZXNvdXJjZXMvY3BzMA0GCSqGSIb3DQEBCwUAA4IBAQBhQK0hDwO7ldyJ
/KPLBXHpHFmXNcL6awWkFsZWRjd0GxvxPizoNxm3lNIPDsW/FAcrNM1btI3HVp0Z
/AK0npAx+qRExnXd3R8lVKMwTKzb/sSI9zEmGEeuTCAZGseuPpgKFj3SwqZdDS4p
fbKdx0EyF8qdrjm/kZje50TilZyUXGxCG1nJe2gTqJYJdO5AFKTV18l7M6MPWmmc
GvpvEkcc3x5McE5t3f4ch7Wd4VQHCYrNvqqoRnhuFvLnkQ7Dr9p2ANHYokYkA6Ua
hYFWg2MnupCO+WIRuqd8kKkaZrTFvI8pQavrjZmmzJFkutzGpkyztCMmUXJW+fN0
VZ8ldU8r
-----END CERTIFICATE-----"

issuer52="RapidSSL CA - G2"
issuer52Chain="-----BEGIN CERTIFICATE-----
MIIEVTCCAz2gAwIBAgIDAjpsMA0GCSqGSIb3DQEBBQUAMEIxCzAJBgNVBAYTAlVT
MRYwFAYDVQQKEw1HZW9UcnVzdCBJbmMuMRswGQYDVQQDExJHZW9UcnVzdCBHbG9i
YWwgQ0EwHhcNMTMwNjA1MTQ1MDI5WhcNMjIwNTIwMTQ1MDI5WjBAMQswCQYDVQQG
EwJVUzEWMBQGA1UEChMNR2VvVHJ1c3QgSW5jLjEZMBcGA1UEAxMQUmFwaWRTU0wg
Q0EgLSBHMjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBANvI6BtLORNA
WBZJr2dPSSO9hscc7PzZbvXoAcpBMk/sOXYJmAu1Tt/jsfApqHeqGe6S/ehWmtJ9
i2KYrnnLUUSMUMNUxLI5QETQCyWl7f5yU4g7vtlJfDQfQ04A8o/ZtuKqbqidVeTd
t0pdtRQWyWGUa3rrxyooVE0ozpLsHakMcZvNcW/csZh20Ntupc7CzhmyNXjY15NZ
baMScddtCkHcD6BT4EBrm0oXbXHhLevhAQEili+X8ZSV0OJF9BVIdH1cdDxVbA1n
2PT5YRS2ct4Bc42d/UaOoTVLatOk+qjj/DktU1/bcxdmeIL1AKTrlTUIBvHc06u6
k4P2hwLPyPECAwEAAaOCAVQwggFQMB8GA1UdIwQYMBaAFMB6mGiNifurBWQMEX2q
fWW4ysxOMB0GA1UdDgQWBBQaT8qHEeGPkkStP9yMCEuOqcAjrjASBgNVHRMBAf8E
CDAGAQH/AgEAMA4GA1UdDwEB/wQEAwIBBjA6BgNVHR8EMzAxMC+gLaArhilodHRw
Oi8vY3JsLmdlb3RydXN0LmNvbS9jcmxzL2d0Z2xvYmFsLmNybDA0BggrBgEFBQcB
AQQoMCYwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmdlb3RydXN0LmNvbTBMBgNV
HSAERTBDMEEGCmCGSAGG+EUBBzYwMzAxBggrBgEFBQcCARYlaHR0cDovL3d3dy5n
ZW90cnVzdC5jb20vcmVzb3VyY2VzL2NwczAqBgNVHREEIzAhpB8wHTEbMBkGA1UE
AxMSVmVyaVNpZ25NUEtJLTItNDMyMA0GCSqGSIb3DQEBBQUAA4IBAQAcbl4BIHhm
R8OG7YOSOftIGJFZ6rT7Y2VMZ6AX3nwXIvSBY1rPMHnqb9VmNV4y8Qv2UBWLZCvQ
m9MB93H1u0jpSewnZCzMQSYOPyp0FNRg3Ge0ymYWTYj4n2R2GeZOwO7o4vkldMOR
t55/Q8XnNmR5o9Jg4iaFL7VvrFDS5jZrau22qnQ/bjwWLeX/MK/nu7jUdSFpP/0V
cEqlUDaTQDicBtnH5vHoIGbz9D9VxQ9Y6G11FUwFVSNkOfy2FQZP96mza5hwVlMx
d76Kzww2YCKOBFfwqh2MFxsbnjNVnKqwrSkLYhR3sJ4mq1N/mrJc/D8JdSShBrqY
KhLAunepVld1
-----END CERTIFICATE-----"

issuer53="RapidSSL Enterprise CA"
issuer53Chain="-----BEGIN CERTIFICATE-----
MIIELTCCAxWgAwIBAgIDAjpbMA0GCSqGSIb3DQEBBQUAMEIxCzAJBgNVBAYTAlVT
MRYwFAYDVQQKEw1HZW9UcnVzdCBJbmMuMRswGQYDVQQDExJHZW9UcnVzdCBHbG9i
YWwgQ0EwHhcNMTEwMzA4MTk1MjU2WhcNMjEwMzA1MTk1MjU2WjBnMQswCQYDVQQG
EwJVUzEXMBUGA1UEChMOR2VvVHJ1c3QsIEluYy4xHjAcBgNVBAsTFUZvciBJbnRl
cm5hbCBVc2UgT25seTEfMB0GA1UEAxMWUmFwaWRTU0wgRW50ZXJwcmlzZSBDQTCC
ASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALp95UbN095bMH/3DK0rFZRx
hzeo/HGZI5xzzmFR3iq5xd43IHBYR4mPyyuD0CjIAHbOASbRqtq3o84edNP2MA3d
ns/KSK90K8T4lMueLV4eUU8VMs06PXy4/uUvNym2KfjpMqD1brNg6XofLkFLfCNi
aUC4NZD2nlOSEl4EenrKho91CEBUWx2dgwAKf4760bRtl+k8aSs+xf+5dHxBH97v
ZjqTDEmXX8iqIanH+odbZplz3y+bUQuO8lCoGZldW820vVAPhysAp+o0O595p9xQ
HfcFMbMEZ9EP/dvB0Mii0O5hMwGWg3FfRSJUdZjLwnNInC1elxOk2K6bwnJKSisC
AwEAAaOCAQUwggEBMB8GA1UdIwQYMBaAFMB6mGiNifurBWQMEX2qfWW4ysxOMB0G
A1UdDgQWBBTlDw09QB0ZeDGT1R8EAKrDQ75ClDASBgNVHRMBAf8ECDAGAQH/AgEA
MA4GA1UdDwEB/wQEAwIBBjA6BgNVHR8EMzAxMC+gLaArhilodHRwOi8vY3JsLmdl
b3RydXN0LmNvbS9jcmxzL2d0Z2xvYmFsLmNybDA0BggrBgEFBQcBAQQoMCYwJAYI
KwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmdlb3RydXN0LmNvbTApBgNVHREEIjAgpB4w
HDEaMBgGA1UEAxMRVmVyaVNpZ25NUEtJLTItNTgwDQYJKoZIhvcNAQEFBQADggEB
AA9i561VwbiRS9WBDMKX/wcsVKIivRviygPNaBKsv3O5VYCGhwi4IBeML0JBwfLH
JM8M+nlHaZTObQPK0O7uOHMA6V8oMKSxPupf0STrFIPVNMDl7pYJoWhehJhyaef6
92HD3o/DiU43aZMcNv6PPhgp/eAjvFTLBnEyAIZehrQl0bArhcaEr3bDHfuh9oWM
6wqY6NvBl3Ue93g32ryU3Ql2DU+xguL/PDlPMhZRHieTNMt+sraUj1fGHGzjZwC6
gL3vVj/XVY+Qb7Dcg4YwDm7e7yAXjKuwP/wCIcuEKWz6JRRBonNvN3tHXwBMrZVT
ZMYSWYQ0wvqvvigtWA+F/N0=
-----END CERTIFICATE-----"

issuer54="RapidSSL SHA256 CA"
issuer54Chain="-----BEGIN CERTIFICATE-----
MIIETTCCAzWgAwIBAgIDAjpxMA0GCSqGSIb3DQEBCwUAMEIxCzAJBgNVBAYTAlVT
MRYwFAYDVQQKEw1HZW9UcnVzdCBJbmMuMRswGQYDVQQDExJHZW9UcnVzdCBHbG9i
YWwgQ0EwHhcNMTMxMjExMjM0NTUxWhcNMjIwNTIwMjM0NTUxWjBCMQswCQYDVQQG
EwJVUzEWMBQGA1UEChMNR2VvVHJ1c3QgSW5jLjEbMBkGA1UEAxMSUmFwaWRTU0wg
U0hBMjU2IENBMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAu1jBEgEu
l9h9GKrIwuWF4hdsYC7JjTEFORoGmFbdVNcRjFlbPbFUrkshhTIWX1SG5tmx2GCJ
a1i+ctqgAEJ2sSdZTM3jutRc2aZ/uyt11UZEvexAXFm33Vmf8Wr3BvzWLxmKlRK6
msrVMNI4/Bk7WxU7NtBDTdFlodSLwWBBs9ZwF8w5wJwMoD23ESJOztmpetIqYpyg
C04q18NhWoXdXBC5VD0tA/hJ8LySt7ecMcfpuKqCCwW5Mc0IW7siC/acjopVHHZD
dvDibvDfqCl158ikh4tq8bsIyTYYZe5QQ7hdctUoOeFTPiUs2itP3YqeUFDgb5rE
1RkmiQF1cwmbOwIDAQABo4IBSjCCAUYwHwYDVR0jBBgwFoAUwHqYaI2J+6sFZAwR
fap9ZbjKzE4wHQYDVR0OBBYEFJfCJ1CewsnsDIgyyHyt4qYBT9pvMBIGA1UdEwEB
/wQIMAYBAf8CAQAwDgYDVR0PAQH/BAQDAgEGMDYGA1UdHwQvMC0wK6ApoCeGJWh0
dHA6Ly9nMS5zeW1jYi5jb20vY3Jscy9ndGdsb2JhbC5jcmwwLwYIKwYBBQUHAQEE
IzAhMB8GCCsGAQUFBzABhhNodHRwOi8vZzIuc3ltY2IuY29tMEwGA1UdIARFMEMw
QQYKYIZIAYb4RQEHNjAzMDEGCCsGAQUFBwIBFiVodHRwOi8vd3d3Lmdlb3RydXN0
LmNvbS9yZXNvdXJjZXMvY3BzMCkGA1UdEQQiMCCkHjAcMRowGAYDVQQDExFTeW1h
bnRlY1BLSS0xLTU2OTANBgkqhkiG9w0BAQsFAAOCAQEANevhiyBWlLp6vXmp9uP+
bji0MsGj21hWID59xzqxZ2nVeRQb9vrsYPJ5zQoMYIp0TKOTKqDwUX/N6fmS/Zar
RfViPT9gRlATPSATGC6URq7VIf5Dockj/lPEvxrYrDrK3maXI67T30pNcx9vMaJR
BBZqAOv5jUOB8FChH6bKOvMoPF9RrNcKRXdLDlJiG9g4UaCSLT+Qbsh+QJ8gRhVd
4FB84XavXu0R0y8TubglpK9YCa81tGJUheNI3rzSkHp6pIQNo0LyUcDUrVNlXWz4
Px8G8k/Ll6BKWcZ40egDuYVtLLrhX7atKz4lecWLVtXjCYDqwSfC2Q7sRwrp0Mr8
2A==
-----END CERTIFICATE-----"

issuer55="RapidSSL SHA256 CA - G2"
issuer55Chain="-----BEGIN CERTIFICATE-----
MIIEtTCCA52gAwIBAgIQSOmUQNQ2SRy4uII9CUOUxzANBgkqhkiG9w0BAQsFADCB
mDELMAkGA1UEBhMCVVMxFjAUBgNVBAoTDUdlb1RydXN0IEluYy4xOTA3BgNVBAsT
MChjKSAyMDA4IEdlb1RydXN0IEluYy4gLSBGb3IgYXV0aG9yaXplZCB1c2Ugb25s
eTE2MDQGA1UEAxMtR2VvVHJ1c3QgUHJpbWFyeSBDZXJ0aWZpY2F0aW9uIEF1dGhv
cml0eSAtIEczMB4XDTE0MDYxMDAwMDAwMFoXDTI0MDYwOTIzNTk1OVowRzELMAkG
A1UEBhMCVVMxFjAUBgNVBAoTDUdlb1RydXN0IEluYy4xIDAeBgNVBAMTF1JhcGlk
U1NMIFNIQTI1NiBDQSAtIEcyMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKC
AQEAxJVjKNBOMEWvi5c0FEX4XFhK+jOObpxgq/OG/zR0siu+oYzVoqNgekC54fwi
yme6YKrHmvkGf+73uoUFsAP/cq4VQUqYZNcXS1TvBcaYB5MnPk/cD8Z7i+fzBl6N
6LSuKbQeHi0WkNPqqueMO22vNln/xQr6x0y9NotkxEr1zjP5B75/RZCoCBSw0KVP
34KA2hvuwxOwmPUP+X52tea5XWi5XFCQiaQ2sXAW6rEQtWp23+G7/HjycpnPyaLU
c1R3v8A5d+WuEsV4WhlF1EEZ03z1b5lr14u8LQmdSxBhwNpSw68iQ8brN35jdDAN
anGO3l1bisjF15sp6K62JWGB6wIDAQABo4IBSTCCAUUwLgYIKwYBBQUHAQEEIjAg
MB4GCCsGAQUFBzABhhJodHRwOi8vZy5zeW1jZC5jb20wEgYDVR0TAQH/BAgwBgEB
/wIBADBMBgNVHSAERTBDMEEGCmCGSAGG+EUBBzYwMzAxBggrBgEFBQcCARYlaHR0
cDovL3d3dy5nZW90cnVzdC5jb20vcmVzb3VyY2VzL2NwczA2BgNVHR8ELzAtMCug
KaAnhiVodHRwOi8vZy5zeW1jYi5jb20vR2VvVHJ1c3RQQ0EtRzMuY3JsMA4GA1Ud
DwEB/wQEAwIBBjApBgNVHREEIjAgpB4wHDEaMBgGA1UEAxMRU3ltYW50ZWNQS0kt
MS02OTcwHQYDVR0OBBYEFEz0v+g7vsIk8xtHO7VuSI4Wq68SMB8GA1UdIwQYMBaA
FMR5yo6hTgMdHNxr2zFblD4/MH8tMA0GCSqGSIb3DQEBCwUAA4IBAQB6U7Xetu9S
o1+K9YnxQsxeRoiupQiHUd4PDwLrDIJ443N9cb1D6cqKP+AlkpszM3RJXgDZcxQc
C0Z2HIoNTYxsfkv3YNiBeKB40CViqxDKIugcGd1Sg2QF5Ydmrud6pDs+2HB6dqJn
OdTJ+uW3HkHiCTmIHBhVCsRBr7Lz8w9CFGF0gePah1qaTYvTyY+JZhMpEeT/4t+O
lgxaoaprm/38AztVDaaiJUgXH0Ko2mx+aW6g32fSbfQOahJ59XzIpTIcxDGy5ruo
a2qiimBpwFd9svIxDJhlMuwIWs7GmOkhlz8seSkD9faUK1Mx85NoV+HXTzrRYaFg
zrmrmK41VGOL
-----END CERTIFICATE-----"

issuer56="RapidSSL SHA256 CA - G3"
issuer56Chain="-----BEGIN CERTIFICATE-----
MIIEJTCCAw2gAwIBAgIDAjp3MA0GCSqGSIb3DQEBCwUAMEIxCzAJBgNVBAYTAlVT
MRYwFAYDVQQKEw1HZW9UcnVzdCBJbmMuMRswGQYDVQQDExJHZW9UcnVzdCBHbG9i
YWwgQ0EwHhcNMTQwODI5MjEzOTMyWhcNMjIwNTIwMjEzOTMyWjBHMQswCQYDVQQG
EwJVUzEWMBQGA1UEChMNR2VvVHJ1c3QgSW5jLjEgMB4GA1UEAxMXUmFwaWRTU0wg
U0hBMjU2IENBIC0gRzMwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCv
VJvZWF0eLFbG1eh/9H0WA//Qi1rkjqfdVC7UBMBdmJyNkA+8EGVf2prWRHzAn7Xp
SowLBkMEu/SW4ib2YQGRZjEiwzQ0Xz8/kS9EX9zHFLYDn4ZLDqP/oIACg8PTH2lS
1p1kD8mD5xvEcKyU58Okaiy9uJ5p2L4KjxZjWmhxgHsw3hUEv8zTvz5IBVV6s9cQ
DAP8m/0Ip4yM26eO8R5j3LMBL3+vV8M8SKeDaCGnL+enP/C1DPz1hNFTvA5yT2AM
QriYrRmIV9cE7Ie/fodOoyH5U/02mEiN1vi7SPIpyGTRzFRIU4uvt2UevykzKdkp
YEj4/5G8V1jlNS67abZZAgMBAAGjggEdMIIBGTAfBgNVHSMEGDAWgBTAephojYn7
qwVkDBF9qn1luMrMTjAdBgNVHQ4EFgQUw5zz/NNGCDS7zkZ/oHxb8+IIy1kwEgYD
VR0TAQH/BAgwBgEB/wIBADAOBgNVHQ8BAf8EBAMCAQYwNQYDVR0fBC4wLDAqoCig
JoYkaHR0cDovL2cuc3ltY2IuY29tL2NybHMvZ3RnbG9iYWwuY3JsMC4GCCsGAQUF
BwEBBCIwIDAeBggrBgEFBQcwAYYSaHR0cDovL2cuc3ltY2QuY29tMEwGA1UdIARF
MEMwQQYKYIZIAYb4RQEHNjAzMDEGCCsGAQUFBwIBFiVodHRwOi8vd3d3Lmdlb3Ry
dXN0LmNvbS9yZXNvdXJjZXMvY3BzMA0GCSqGSIb3DQEBCwUAA4IBAQCjWB7GQzKs
rC+TeLfqrlRARy1+eI1Q9vhmrNZPc9ZE768LzFvB9E+aj0l+YK/CJ8cW8fuTgZCp
fO9vfm5FlBaEvexJ8cQO9K8EWYOHDyw7l8NaEpt7BDV7o5UzCHuTcSJCs6nZb0+B
kvwHtnm8hEqddwnxxYny8LScVKoSew26T++TGezvfU5ho452nFnPjJSxhJf3GrkH
uLLGTxN5279PURt/aQ1RKsHWFf83UTRlUfQevjhq7A6rvz17OQV79PP7GqHQyH5O
ZI3NjGFVkP46yl0lD/gdo0p0Vk8aVUBwdSWmMy66S6VdU5oNMOGNX2Esr8zvsJmh
gP8L8mJMcCaY
-----END CERTIFICATE-----"

issuer57="RapidSSL SHA256 CA - G4"
issuer57Chain="-----BEGIN CERTIFICATE-----
MIIEpjCCA46gAwIBAgIQKByJKWYUQ4BCY1U6MkCuszANBgkqhkiG9w0BAQsFADCB
mDELMAkGA1UEBhMCVVMxFjAUBgNVBAoTDUdlb1RydXN0IEluYy4xOTA3BgNVBAsT
MChjKSAyMDA4IEdlb1RydXN0IEluYy4gLSBGb3IgYXV0aG9yaXplZCB1c2Ugb25s
eTE2MDQGA1UEAxMtR2VvVHJ1c3QgUHJpbWFyeSBDZXJ0aWZpY2F0aW9uIEF1dGhv
cml0eSAtIEczMB4XDTE1MDYzMDAwMDAwMFoXDTI1MDYyOTIzNTk1OVowRzELMAkG
A1UEBhMCVVMxFjAUBgNVBAoTDUdlb1RydXN0IEluYy4xIDAeBgNVBAMTF1JhcGlk
U1NMIFNIQTI1NiBDQSAtIEc0MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKC
AQEAwJ46D5qyutPS3BXs0DBUWTBNQFGuQnFx0o1Tc4H+uODElsWOfsLxt2NKz6ce
P6jnzlOg+i331ubOcBGm7uEDUtJo3j0IDYf9HNcLl2JtgjB2G0c6xPfO7R18jLcX
jlOAHh0PXYz5kOQEHgJ+y7BJ79pSJfv7Z+3dhHRZhA7z3nBmjeRSOPdTWjcTZws+
u6hYty7t/7deEXO5d0VSZ0auxNwkgYl2CsqhbGZzBIKq9XBsXxuaAHlG1n96Jhcw
zzlLLHTZiUR2ENDt94u7iQV1TQsNs9rpv/FqfSoR2x6fjOPEBmnhHYhFOdFuVdiq
t5tv6vTerBcRkl1Am4N7muL3qQIDAQABo4IBOjCCATYwLgYIKwYBBQUHAQEEIjAg
MB4GCCsGAQUFBzABhhJodHRwOi8vZy5zeW1jZC5jb20wEgYDVR0TAQH/BAgwBgEB
/wIBADBJBgNVHSAEQjBAMD4GBmeBDAECATA0MDIGCCsGAQUFBwIBFiZodHRwczov
L3d3dy5nZW90cnVzdC5jb20vcmVzb3VyY2VzL2NwczA2BgNVHR8ELzAtMCugKaAn
hiVodHRwOi8vZy5zeW1jYi5jb20vR2VvVHJ1c3RQQ0EtRzMuY3JsMB0GA1UdJQQW
MBQGCCsGAQUFBwMBBggrBgEFBQcDAjAOBgNVHQ8BAf8EBAMCAQYwHQYDVR0OBBYE
FPO1VgzECbC0zx+q+d0jVvB36KH5MB8GA1UdIwQYMBaAFMR5yo6hTgMdHNxr2zFb
lD4/MH8tMA0GCSqGSIb3DQEBCwUAA4IBAQDDftiDSwRMVSkqTxSdmm7ekHDBpCZM
iI54SO+9nLCg9fBm/P5ZJuF578i3YGSoi0fqL+CDmdpBGdfFvgX68pAR8Ar/bNwF
tNgGb6Rvjb4gK1Tb+aJFg5oepSGJNR18IFwX/QQuRdiyxvhCmfxUCE5LgF85N7qV
TqY3Cp6TXodb6ZDWqLZlCI1hSeuDIKldGxZgYmsvVPtaAg16J+JL4QUUwuTp+XDA
2fc0ZQ6ikUusKPK3CA+Yytc+cLbIC/GLnFH4xhBs0lNPYowRAD6I37/m0sxwve0l
nPvdJAq9WZFKQgM4EnEyiHagjny7Mu+IKhvUam9QuVJni6sw+h/94ySa
-----END CERTIFICATE-----"

issuer58="thawte ECC EV SSL CA"
issuer58Chain="-----BEGIN CERTIFICATE-----
MIIDgDCCAwagAwIBAgIQH/L8vGMmqr0oZpOZH0PsITAKBggqhkjOPQQDAzCBhDEL
MAkGA1UEBhMCVVMxFTATBgNVBAoTDHRoYXd0ZSwgSW5jLjE4MDYGA1UECxMvKGMp
IDIwMDcgdGhhd3RlLCBJbmMuIC0gRm9yIGF1dGhvcml6ZWQgdXNlIG9ubHkxJDAi
BgNVBAMTG3RoYXd0ZSBQcmltYXJ5IFJvb3QgQ0EgLSBHMjAeFw0xNjAxMDcwMDAw
MDBaFw0yNjAxMDYyMzU5NTlaMEMxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwx0aGF3
dGUsIEluYy4xHTAbBgNVBAMTFHRoYXd0ZSBFQ0MgRVYgU1NMIENBMFkwEwYHKoZI
zj0CAQYIKoZIzj0DAQcDQgAEmcXM1zsNS0E2+7pcpYHdwqumr+KIIt3jEJA6jBBm
1SoBGgZESt6OKROJBt2sZJhUl4oU0q5kINTS/bG+eYTTlqOCAZgwggGUMA4GA1Ud
DwEB/wQEAwIBBjAuBggrBgEFBQcBAQQiMCAwHgYIKwYBBQUHMAGGEmh0dHA6Ly90
LnN5bWNkLmNvbTASBgNVHRMBAf8ECDAGAQH/AgEAMHwGA1UdIAR1MHMwBwYFZ4EM
AQEwaAYLYIZIAYb4RQEHMAEwWTAmBggrBgEFBQcCARYaaHR0cHM6Ly93d3cudGhh
d3RlLmNvbS9jcHMwLwYIKwYBBQUHAgIwIxohaHR0cHM6Ly93d3cudGhhd3RlLmNv
bS9yZXBvc2l0b3J5MDQGA1UdHwQtMCswKaAnoCWGI2h0dHA6Ly90LnN5bWNiLmNv
bS9UaGF3dGVQQ0EtRzIuY3JsMB0GA1UdJQQWMBQGCCsGAQUFBwMBBggrBgEFBQcD
AjArBgNVHREEJDAipCAwHjEcMBoGA1UEAxMTU1lNQy1FQ0MtQ0EtcDI1Ni0zMTAd
BgNVHQ4EFgQUWzOvNaAaGTdCDVfmvL1rYyDClgEwHwYDVR0jBBgwFoAUmtgAMADn
a3+FGO6Lts6KDPgR4bswCgYIKoZIzj0EAwMDaAAwZQIwMMf+C0NMBVt58Of4YvVO
mVS0OYfzEiB4AOz8QF9pmEyaCAelGeOmq2pOLDEsQbKzAjEA2WTDVMhnnJI3NSnD
itmCtBQnW6NEAohvLUsB4iVehDAJK3mNY8FbYafl4LjFzA4V
-----END CERTIFICATE-----"

         log "Getting Intermediate Certificates for Issuer ${issuer}"
         if [ "${issuer}" == "${issuer1}" ]
         then
             echo "${issuer1Chain}" > $certChainFile
         elif [ "${issuer}" == "${issuer2}" ]
         then
             echo "${issuer2Chain}" > $certChainFile
             elif [ "${issuer}" == "${issuer3}" ]
         then
             echo "${issuer3Chain}" > $certChainFile
             elif [ "${issuer}" == "${issuer4}" ]
         then
             echo "${issuer4Chain}" > $certChainFile
         elif [ "${issuer}" == "${issuer5}" ]
         then
             echo "${issuer5Chain}" > $certChainFile
         elif [ "${issuer}" == "${issuer6}" ]
         then
             echo "${issuer6Chain}" > $certChainFile
         elif [ "${issuer}" == "${issuer7}" ]
         then
             echo "${issuer7Chain}" > $certChainFile
         elif [ "${issuer}" == "${issuer8}" ]
         then
             echo "${issuer8Chain}" > $certChainFile
         elif [ "${issuer}" == "${issuer9}" ]
         then
	     echo "${issuer9Chain}" > $certChainFile
         elif [ "${issuer}" == "${issuer10}" ]
         then
             echo "${issuer10Chain}" > $certChainFile
         elif [ "${issuer}" == "${issuer11}" ]
         then
             echo "${issuer11Chain}" > $certChainFile
         elif [ "${issuer}" == "${issuer12}" ]
         then
             echo "${issuer12Chain}" > $certChainFile
         elif [ "${issuer}" == "${issuer13}" ]
         then
             echo "${issuer13Chain}" > $certChainFile
         elif [ "${issuer}" == "${issuer14}" ]
         then
             echo "${issuer14Chain}" > $certChainFile
         elif [ "${issuer}" == "${issuer15}" ]
         then
             echo "${issuer15Chain}" > $certChainFile
         elif [ "${issuer}" == "${issuer16}" ]
         then
             echo "${issuer16Chain}" > $certChainFile
         elif [ "${issuer}" == "${issuer17}" ]
         then
             echo "${issuer17Chain}" > $certChainFile
          elif [ "${issuer}" == "${issuer18}" ]
          then
             echo "${issuer18Chain}" > $certChainFile
          elif [ "${issuer}" == "${issuer19}" ]
          then
             echo "${issuer19Chain}" > $certChainFile
         elif [ "${issuer}" == "${issuer20}" ]
         then
             echo "${issuer20Chain}" > $certChainFile
         elif [ "${issuer}" == "${issuer21}" ]
         then
             echo "${issuer21Chain}" > $certChainFile
         elif [ "${issuer}" == "${issuer22}" ]
         then
             echo "${issuer22Chain}" > $certChainFile
         elif [ "${issuer}" == "${issuer23}" ]
         then
             echo "${issuer23Chain}" > $certChainFile
         elif [ "${issuer}" == "${issuer24}" ]
         then
             echo "${issuer24Chain}" > $certChainFile
         elif [ "${issuer}" == "${issuer25}" ]
         then
             echo "${issuer25Chain}" > $certChainFile
         elif [ "${issuer}" == "${issuer26}" ]
         then
             echo "${issuer26Chain}" > $certChainFile
          elif [ "${issuer}" == "${issuer27}" ]
          then
             echo "${issuer27Chain}" > $certChainFile
         elif [ "${issuer}" == "${issuer28}" ]
         then
             echo "${issuer28Chain}" > $certChainFile
         elif [ "${issuer}" == "${issuer29}" ]
         then
             echo "${issuer29Chain}" > $certChainFile
         elif [ "${issuer}" == "${issuer30}" ]
         then
             echo "${issuer30Chain}" > $certChainFile
         elif [ "${issuer}" == "${issuer31}" ]
         then
             echo "${issuer31Chain}" > $certChainFile
         elif [ "${issuer}" == "${issuer32}" ]
         then
             echo "${issuer32Chain}" > $certChainFile
         elif [ "${issuer}" == "${issuer33}" ]
         then
             echo "${issuer33Chain}" > $certChainFile
         elif [ "${issuer}" == "${issuer34}" ]
         then
             echo "${issuer34Chain}" > $certChainFile
         elif [ "${issuer}" == "${issuer35}" ]
         then
             echo "${issuer35Chain}" > $certChainFile 
         elif [ "${issuer}" == "${issuer36}" ]
         then
             echo "${issuer36Chain}" > $certChainFile
         elif [ "${issuer}" == "${issuer37}" ]
         then
             echo "${issuer37Chain}" > $certChainFile
         elif [ "${issuer}" == "${issuer38}" ]
         then
             echo "${issuer38Chain}" > $certChainFile
         elif [ "${issuer}" == "${issuer39}" ]
         then
             echo "${issuer39Chain}" > $certChainFile 
		 elif [ "${issuer}" == "${issuer40}" ]
		 then
		     echo "${issuer40Chain}" > $certChainFile 
		 elif [ "${issuer}" == "${issuer41}" ]
		 then
		     echo "${issuer41Chain}" > $certChainFile 
		 elif [ "${issuer}" == "${issuer42}" ]
		 then
		     echo "${issuer42Chain}" > $certChainFile 
		 elif [ "${issuer}" == "${issuer43}" ]
		 then
		     echo "${issuer43Chain}" > $certChainFile 
		 elif [ "${issuer}" == "${issuer44}" ]
		 then
		     echo "${issuer44Chain}" > $certChainFile 
		 elif [ "${issuer}" == "${issuer45}" ]
		 then
		     echo "${issuer45Chain}" > $certChainFile 
		 elif [ "${issuer}" == "${issuer46}" ]
		 then
		     echo "${issuer46Chain}" > $certChainFile 
		 elif [ "${issuer}" == "${issuer47}" ]
		 then
		     echo "${issuer47Chain}" > $certChainFile 
		 elif [ "${issuer}" == "${issuer48}" ]
		 then
		     echo "${issuer48Chain}" > $certChainFile 
		 elif [ "${issuer}" == "${issuer49}" ]
		 then
		     echo "${issuer49Chain}" > $certChainFile 
		 elif [ "${issuer}" == "${issuer50}" ]
		 then
		     echo "${issuer50Chain}" > $certChainFile 
		 elif [ "${issuer}" == "${issuer51}" ]
		 then
		     echo "${issuer51Chain}" > $certChainFile 
		 elif [ "${issuer}" == "${issuer52}" ]
		 then
		     echo "${issuer52Chain}" > $certChainFile 
		 elif [ "${issuer}" == "${issuer53}" ]
		 then
		     echo "${issuer53Chain}" > $certChainFile 
		 elif [ "${issuer}" == "${issuer54}" ]
		 then
		     echo "${issuer54Chain}" > $certChainFile 
		 elif [ "${issuer}" == "${issuer55}" ]
		 then
		     echo "${issuer55Chain}" > $certChainFile 
		 elif [ "${issuer}" == "${issuer56}" ]
		 then
		     echo "${issuer56Chain}" > $certChainFile 
		 elif [ "${issuer}" == "${issuer57}" ]
		 then
		     echo "${issuer57Chain}" > $certChainFile 
		 elif [ "${issuer}" == "${issuer58}" ]
         then
             echo "${issuer58Chain}" > $certChainFile     
         else
             echo "You must use this tool with a ${brand} SSL Certificate".
             exit 1
         fi
}
#=========================================CERTIFICATE END====================================================

genCsr_preprocessing()
{

	echo
	echo "Enter a new passphrase. This protects the private key that you are"
	echo "about to create. You will need to put this password into Apache\'s"
	echo "configuration file. This field is required."
	echo
	requiredSecretPrompt "${BoldOn}Your passphrase is:${BoldOff} "
	passphrase=$result
	requiredSecretPrompt "${BoldOn}Re-enter your passphrase:${BoldOff} "
	passphraseVerify=$result

	if [ "${passphrase}" != "${passphraseVerify}" ];
	then
		echo -e "Passphrases do not match"
		log "Passphrases do not match"
		exit 1
	fi
	echo

	modifiedCommonName=${commonName//./_}
        csr="$HOME/${brand}/ssl/${modifiedCommonName}_${cipher}_csr.txt"
	privateKey="$HOME/${brand}/ssl/${modifiedCommonName}_${cipher}_private.key"
	


	#Backup old CSR and private key if they already exist
	timestamp=`date +"$backupDateTime"`

	if [ -e "$csr" ]
	then
		echo "Backing up $csr to ${csr}.${timestamp}.bak"
	 	log "Backing up $csr to ${csr}.${timestamp}.bak"
                mv "$csr" ${csr}.${timestamp}.bak
	fi

	if [ -e "$privateKey" ]
	then
		echo "Backing up $privateKey to ${privateKey}.${timestamp}.bak"
		log "Backing up $privateKey to ${privateKey}.${timestamp}.bak"
	 	mv "$privateKey" ${privateKey}.${timestamp}.bak
	fi
	
	if [ "${cipher}" == "ECC" ]
	then
		privateKeytempFile="$HOME/${brand}/ssl/${modifiedCommonName}_${cipher}_private_temp.key"
	fi
}

genCsr_RSA()
{
	echo "Writing new RSA CSR to \"$csr\""
	log "Writing new RSA CSR to $csr..."
	openssl req -out "$csr" -utf8 -nameopt -utf8 -subj "$subject" -new -newkey rsa:2048 -keyout "$privateKey" -passout pass:$passphrase >/dev/null 2>&1

	if [ -e "$csr" ]
	then
		echo "Success."
		log "Success."
	else
		echo "Failed."
		log "Failed."
	fi

	cat "$csr"
}
genCsr_DSA()
{
        echo "Writing new DSA CSR to \"$csr\""
	log "Writing new DSA CSR to $csr..."
	pathline="$( cd -P "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
	openssl gendsa $pathline/Pem-2048-256.pem  -out "$privateKey" -des3 -passout pass:$passphrase >/dev/null 2>&1
	openssl req -inform PEM -newkey dsa:$pathline/Pem-2048-256.pem -key "$privateKey" -sha256 -out "$csr" -utf8 -nameopt -utf8 -subj "$subject" -passin pass:"$passphrase" >/dev/null 2>&1

	if [ -e "$csr" ]
	then
		echo "Success."
		log "Success."
	else
		echo "Failed."
		log "Failed."
	fi

	cat "$csr"
}

installCert()
{
        getCertAndPrivateKey()
	{
              publicKey1=`openssl x509 -pubkey -noout -in $cert 2> /dev/null`
              cipher=$(echo ${cipher} | tr '[:upper:]' '[:lower:]')


		#test that publicKey1 returned is non empty
                if [ ! -n "$publicKey1" ]
		then
			echo "Public key is not found in specified certificate."
			log "Public key is not found in specified certificate."
			exit 1
		fi

		#Get the issuer name from the certificate
		issuer=`openssl x509 -in $cert -issuer -noout`
		issuer=${issuer#*CN=}
		issuer=${issuer%%/*}

		requiredFilePrompt "Enter the path for the private key that matches the certificate: "
		privateKey=$result
		echo
		if [ ! -f $privateKey ]
		then
			echo "The private key file does not exist."
			log "The private key file does not exist."
			exit 1
		fi

		requiredSecretPrompt "Enter the passphrase for the private key: "
		passphrase=$result
		echo

		
		if [[ "$cipher" == "ecc" ]]
	    then
		  publicKey2=`openssl ec -pubout -in $privateKey -passin pass:$passphrase 2> /dev/null`
		else
		  publicKey2=`openssl $cipher -pubout -in $privateKey -passin pass:$passphrase 2> /dev/null`
		fi

		if [ "$publicKey1" != "$publicKey2" ]
		then
			echo "The certificate does not contain the public key for the given private key"
			echo "or the passphrase is incorrect."
			log "The certificate does not contain the public key for the given private key"
			log "or the passphrase is incorrect."
			exit 1
		fi

		#Get the common name from privatekey as it can from the cert we cannot extract utf8 characters
		commonName=${privateKey##*/}
		commonName=${commonName%_*}
	}

	findSslConf()
	{
		sslFile="/etc/httpd/conf.d/ssl.conf"
                log "Reading into $sslFile..."

		if [ ! -e "$sslFile" ]
		then
			log "Empty file: $sslFile"
                        unset sslFile
                        return 1
		fi

		tmp=`cat $sslFile | grep "Listen 443" | wc -l`
		if [ "$tmp" -ne "1" ]
		then
			log "Listen 443 exists more than once in the $sslFile"
                        unset sslFile
			return 1
		fi

		keyFileLine=`cat $sslFile | grep -n -P "^[ \t#]*SSLCertificateKeyFile"`
		keyFileLine=${keyFileLine%:*}
		tmp=`cat /etc/httpd/conf.d/ssl.conf | grep -P "^[ \t#]*SSLCertificateKeyFile " | wc -l`
		if [ "$tmp" -ne "1" ]
		then
			log "SSLCertificateKeyFile does not exist exactly once in the $sslFile"
                        unset sslFile
			return 1
		fi

		certChainFileLine=`cat $sslFile | grep -n -P "^[ \t#]*SSLCertificateChainFile"`
		certChainFileLine=${certChainFileLine%:*}
		tmp=`cat $sslFile | grep -P "^[ \t#]*SSLCertificateChainFile" | wc -l`
		if [ "$tmp" -ne "1" ]
		then
                  if [[ "$apacheVersionGreaterThan_2_4_8" == "true" ]]  || [[ "$apacheVersionGreaterThan_2_4_8" == "equal" ]]
                  then
			           log "SSLCertificateChainFile is deprecated from 2.4.8 version"
                  else
			            log "SSLCertificateChainFile does not exist exactly once in the $sslFile"
                        unset sslFile
			            return 1
                  fi

         else 
                  if [[ "$apacheVersionGreaterThan_2_4_8" == "true" ]]  || [[ "$apacheVersionGreaterThan_2_4_8" == "equal" ]]
                  then
		                 log "SSLCertificateChainFile exist but is derprecated from 2.4.8 version "
                         unset sslFile
			             return 1
                  fi
		fi


		certFileLine=`cat $sslFile | grep -n -P "^[ \t#]*SSLCertificateFile"`
		certFileLine=${certFileLine%:*}
		tmp=`cat $sslFile | grep -P "^[ \t#]*SSLCertificateFile " | wc -l`
		if [ "$tmp" -ne "1" ]
		then
		    log "SSLCertificateFile does not exist exactly once in the $sslFile"
            unset sslFile
			return 1
		fi
	}

	#Backs up any existing intermediate certs and copies the new one into apache folder
	installIntermediateCert()
	{
		certChainFile="/etc/httpd/conf/ssl/${commonName}_intermediate.cer"
                if [ -e "${certChainFile}" ]
		then
			echo "Backing up previous intermediate certificate chain"
			log "Backing up previous intermediate certificate chain"
			mv "${certChainFile}" "${certChainFile}.`date +"${backupDateTime}"`.bak"
		fi
		getIntermediateCerts
	}

	#Backs up any existing key and copies the new key into apache folder
	installPrivateKey()
	{
                privateKeyFile="/etc/httpd/conf/ssl/${commonName}_private.key"
		if [ -e "${privateKeyFile}" ]
		then
			echo "Backing up the previous private key."
			log "Backing up the previous private key."
			mv "${privateKeyFile}" "${privateKeyFile}.`date +"${backupDateTime}"`.bak"
		fi

		log "Copying in new key..."
                cp "${privateKey}" "${privateKeyFile}"
	}

	#Backs up any existing cert and copies the new cert into apache folder
	installCertInApache()
	{
		certFile="/etc/httpd/conf/ssl/${commonName}.cer"
		if [ -e "${certFile}" ]
		then
			log "Backing up the previous certificate."
                        echo "Backing up the previous certificate."
			mv "${certFile}" "${certFile}.`date +"${backupDateTime}"`.bak"
		fi

		log "Copying in new certificate..."

                if [[ "$apacheVersionGreaterThan_2_4_8" == "true" ]]  || [[ "$apacheVersionGreaterThan_2_4_8" == "equal" ]]
                then
                     log "Apache version from 2.4.8 onwards needs cert and intermediate in one file"
                     cp $cert $certFile
                     cat $certChainFile >> $certFile
                else
                     cp $cert $certFile
                fi
	}

	updateSslConf()
	{
		echo "Backing up the $sslFile"
		log "Backing up old $sslFile"
		cp $sslFile /etc/httpd/conf.d/ssl.conf.`date +"${backupDateTime}"`.bak

		log "Updating lines for SSLCertificateKeyFile, SSLCertificateFile and SSLCertificateChainFile"
        sslConf=`cat $sslFile`
		sslConf=`echo "${sslConf}" | sed "${keyFileLine} s#.*#SSLCertificateKeyFile ${privateKeyFile////\/}#"`

        if [[ "$apacheVersionGreaterThan_2_4_8" == "true" ]]  || [[ "$apacheVersionGreaterThan_2_4_8" == "equal" ]]
        then
              log "Updating ssl.conf - Apache version from 2.4.8 onwards needs cert and intermediate in one file"
		      sslConf=`echo "${sslConf}" | sed "${certFileLine} s#.*#SSLCertificateFile ${certFile////\/}#"`
        else
		      sslConf=`echo "${sslConf}" | sed "${certFileLine} s#.*#SSLCertificateFile ${certFile////\/}#"`
		      sslConf=`echo "${sslConf}" | sed "${certChainFileLine} s#.*#SSLCertificateChainFile ${certChainFile////\/}#"`

        fi
		echo "${sslConf}" > /etc/httpd/conf.d/ssl.conf
	}

	writeSslConf()
	{
		#If the ssl.conf doesn\'t exist, we will create it. If it does, we will create a new one but
		#in the users directory. The user will have to manually configure apache.
		newSslConfFile="/etc/httpd/conf.d/ssl.conf"
		if [ -e "$newSslConfFile" -o  ! -d "/etc/httpd/conf.d" ]
		then
			log "Apache configuration not recognized."
                        echo "Apache configuration not recognized. SSL configuration "
			echo "file will be created in the user\'s home directory. Apache "
			echo "will have to be manually configured and restarted."

			newSslConfFile="$HOME/${brand}/ssl/ssl.conf"
		fi

		echo "Writing Apache SSL configuration to $newSslConfFile"
                log "Writing Apache SSL configuration to $newSslConfFile"

		echo "#Apache2 SSL configuration file" > $newSslConfFile
		echo "" >> $newSslConfFile
		echo "LoadModule ssl_module modules/mod_ssl.so" >> $newSslConfFile
		echo "Listen $port" >> $newSslConfFile
		echo "SSLPassPhraseDialog  builtin" >> $newSslConfFile
		echo "SSLSessionCache shmcb:/var/cache/mod_ssl/scache"'('"512000"')'"" >> $newSslConfFile
		echo "SSLSessionCacheTimeout  300" >> $newSslConfFile

        if [[ "$apacheVersionGreaterThan_2_2" == "false" ]]
        then
		    echo "SSLMutex default" >> $newSslConfFile
        fi

		echo "SSLRandomSeed startup file:/dev/urandom  256" >> $newSslConfFile
		echo "SSLRandomSeed connect builtin" >> $newSslConfFile
		echo "SSLCryptoDevice builtin" >> $newSslConfFile
		echo "<VirtualHost _default_:$port>" >> $newSslConfFile
		echo "  ErrorLog logs/ssl_error_log" >> $newSslConfFile
		echo "  TransferLog logs/ssl_access_log" >> $newSslConfFile
		echo "  CustomLog logs/ssl_request_log \"%t %h \\\"%r\\\" %b\"" >> $newSslConfFile
		echo "  LogLevel warn" >> $newSslConfFile
		echo "  SSLEngine on" >> $newSslConfFile
		echo "  SSLProtocol -ALL +TLSv1 +TLSv1.1 +TLSv1.2" >> $newSslConfFile
		echo "  SSLHonorCipherOrder  on" >> $newSslConfFile
		echo "  SSLCipherSuite EECDH+ECDSA+AESGCM:EECDH+aRSA+AESGCM:EECDH+ECDSA+SHA384:EECDH+ECDSA+SHA256:EECDH+aRSA+SHA384:EECDH+aRSA+SHA256:EECDH:EDH+aRSA:!aNULL:!eNULL:!LOW:!3DES:!MD5:!EXP:!PSK:!SRP:!DSS:!RC4" >> $newSslConfFile
		echo "  <IfModule mod_headers.c>" >> $newSslConfFile
        echo "        Header add Strict-Transport-Security \"max-age=15768000\" ">> $newSslConfFile
        echo "  </IfModule>" >> $newSslConfFile
		
        if [[ "$apacheVersionGreaterThan_2_4_8" == "true" ]]  || [[ "$apacheVersionGreaterThan_2_4_8" == "equal" ]]
        then
            log "Writing in new ssl.conf - Apache version from 2.4.8 onwards need cert and intermediate in one file "
		    echo "  SSLCertificateFile ${certFile}" >> $newSslConfFile
        else 
		    echo "  SSLCertificateFile ${certFile}" >> $newSslConfFile
		    echo "  SSLCertificateChainFile ${certChainFile}" >> $newSslConfFile

        fi

		echo "  SSLCertificateKeyFile ${privateKeyFile}" >> $newSslConfFile
		echo "  <Files ~ \"\\."'('"cgi|shtml|phtml|php3?"')'"$\">" >> $newSslConfFile
		echo "    SSLOptions +StdEnvVars" >> $newSslConfFile
		echo "  </Files>" >> $newSslConfFile
		echo "  <Directory "/var/www/cgi-bin">" >> $newSslConfFile
		echo "    SSLOptions +StdEnvVars" >> $newSslConfFile
		echo "  </Directory>" >> $newSslConfFile
		echo "  SetEnvIf User-Agent ".*MSIE.*" nokeepalive ssl-unclean-shutdown downgrade-1.0 force-response-1.0" >> $newSslConfFile
		echo "</VirtualHost>" >> $newSslConfFile
	}

	port=443

	checkHttpd
	getCertAndPrivateKey
    checkApacheVersionGreaterThan_2_2
    checkApacheVersionGreaterThan_2_4_8

	mkdir -p /etc/httpd/conf/ssl >/dev/null 2>&1
	if [ "$?" = 1 ]
	then
		echo "Unable to create the directory '/etc/httpd/conf/ssl'"
		log "Unable to create the directory /etc/httpd/conf/ssl"
		exit 1
	fi

	installIntermediateCert
	installPrivateKey
	installCertInApache

	findSslConf

        #SSL configuration not found for specified host
	if [ -z "${sslFile}" ]
	then
		log "SSL configuration not found for specified host, writing SSL Config."
                writeSslConf
	else
		log "SSL configuration found for specified host, updating SSL Config"
                updateSslConf
	fi

	echo
	echo "You must restart the Apache Web server to finish the certificate installation. When you "
	echo "restart Apache, you need the passphrase that you created during CSR generation."
	echo
}
clear
echo
echo
log
log "${brand} Certificate Assistant Log `date`"
checkOpenSSLInstalled
showEula

echo
	if [[ "$brand" == "Symantec" ]]
	then
		echo -e "${BoldOn}${UnderlineOn}Welcome to the ${brand} Certificate Assistant Version 5.0.${UnderlineOff}${BoldOff}"
	else 
		echo -e "${BoldOn}${UnderlineOn}Welcome to the ${brand} Certificate Assistant Version 4.0.${UnderlineOff}${BoldOff}"
	fi
echo
echo -e "${BoldOn}Do not abbreviate or use any of these symbols:${BoldOff}"
echo -e "${BoldOn}   ! @ # $ % ^ * "'('" "')'" ~ ? > < / \\ ${BoldOff}"
echo 
echo
echo "Log file for this session created at $logFile"
echo
echo
echo
echo -e "${BoldOn} 1. Generate a certificate signing request "'('"CSR"')'" ${BoldOff}"
echo -e "${BoldOn} 2. Automatically download and install my certificate ${BoldOff}"
echo -e "${BoldOn} 3. Install a certificate I already downloaded ${BoldOff}"
echo -e "${BoldOn} q. Quit ${BoldOff}"
echo
echo -n "Enter the task number: ";


while :
do
	read -s -n1 choice

	case $choice in
	1)
		echo 1
		log "Option chosen to generate a certificate signing request"
		getCipher
                getSubject1
		genCsr_preprocessing
		if [[ "$cipher" == "DSA" ]]
		then
		    log "generating DSA csr"
                    genCsr_DSA
		elif [[ "$cipher" == "ECC" ]]  && [[ "$brand" == "Symantec" ]]
		then
		    echo "generating ECC csr"	
		    log "generating ECC csr"
		    genCsr_ECC		  
                 else
                     echo "generating RSA csr"
                     genCsr_RSA
                fi
		break
		;;
     2)
        echo 2
		log "Automatically download and install my certificate."
                checkCurlInstalled
		getCertWithAutoDownload
		cipher=$(echo ${cipher} | tr '[:lower:]' '[:upper:]')
		echo "Certificate found with ${cipher} encryption algorithm"
		installCert
		break
		;;
	3)
		echo 3
		log "Install a certificate I already downloaded."
		getCert
		cipher=$(echo ${cipher} | tr '[:lower:]' '[:upper:]')
		echo "Certificate found with ${cipher} encryption algorithm"
		installCert
		break
		;;
	q)
		echo q
		log "Option chosen to quit SSLAssistant tool"
		exit 0
	esac
done


echo "done."